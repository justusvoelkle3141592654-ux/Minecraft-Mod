scoreboard players set @s start 0
execute unless score #gebaut br matches 1 run return run tellraw @s {"text":"Die Backrooms werden noch gebaut – bitte einen Moment warten.","color":"gray"}
execute unless dimension br:backrooms run function br:merken
function br:zuruecksetzen
clear @s *[custom_data~{wp:9}]
give @s carrot_on_a_stick[item_model="waffenpack:taschenlampe",custom_name={text:"Taschenlampe",color:"yellow",italic:false},unbreakable={},custom_data={wp:9},tooltip_display={hidden_components:["minecraft:unbreakable"]}]
effect give @s blindness 2 0 true
execute in br:backrooms run tp @s -118.5 65 -78.5 -45 0
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 1 0.5
tellraw @s {"text":"Du rutschst durch den Boden der Realität …","color":"gold","italic":true}
tellraw @s {"text":"Fünf Level und ein Finale. Die Wände sind unzerstörbar.","color":"gray"}
