scoreboard players set #h1 br 0
execute if block -10 66 -56 lever[powered=true] run scoreboard players add #h1 br 1
execute if block -34 66 -48 lever[powered=true] run scoreboard players add #h1 br 1
execute if block 14 66 -24 lever[powered=true] run scoreboard players add #h1 br 1
execute if score #lv br matches 1 if score #auf1 br matches 0 if score #h1 br matches 3.. run function br:level/1/oeffnen
execute if score #t br matches 0 if score #auf1 br matches 0 run title @a[tag=br_in1] actionbar [{"text":"Notstrom: ","color":"yellow"},{"score":{"name":"#h1","objective":"br"},"color":"white"},{"text":"/3","color":"white"}]
scoreboard players set #h3 br 0
execute if block -87 66 31 lever[powered=true] run scoreboard players add #h3 br 1
execute if score #lv br matches 3 if score #auf3 br matches 0 if score #h3 br matches 1.. run function br:level/3/oeffnen
scoreboard players set #h4 br 0
execute if block 11 66 65 lever[powered=true] run scoreboard players add #h4 br 1
execute if block 17 66 11 lever[powered=true] run scoreboard players add #h4 br 1
execute if block 15 66 49 lever[powered=true] run scoreboard players add #h4 br 1
execute if block 9 66 31 lever[powered=true] run scoreboard players add #h4 br 1
execute if score #lv br matches 4 if score #auf4 br matches 0 if score #h4 br matches 4.. run function br:level/4/oeffnen
execute if score #t br matches 0 if score #auf4 br matches 0 run title @a[tag=br_in4] actionbar [{"text":"Sicherungen: ","color":"yellow"},{"score":{"name":"#h4","objective":"br"},"color":"white"},{"text":"/4","color":"white"}]
