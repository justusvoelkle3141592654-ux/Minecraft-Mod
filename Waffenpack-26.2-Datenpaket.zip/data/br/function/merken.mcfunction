execute store result score @s br_rx run data get entity @s Pos[0]
execute store result score @s br_ry run data get entity @s Pos[1]
execute store result score @s br_rz run data get entity @s Pos[2]
scoreboard players set @s br_rd 0
execute if dimension minecraft:the_nether run scoreboard players set @s br_rd 1
execute if dimension minecraft:the_end run scoreboard players set @s br_rd 2
