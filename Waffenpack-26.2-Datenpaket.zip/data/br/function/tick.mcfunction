scoreboard players enable @a start
execute as @a[scores={start=1..}] at @s run function br:start
execute as @a[gamemode=survival] at @s if dimension br:backrooms run function br:abenteuer_an
execute as @a[tag=br_adv] at @s unless dimension br:backrooms run function br:abenteuer_aus
execute as @e[type=player,scores={br_tode=1..}] run function br:wiederbelebt
execute if score #gebaut br matches 1 in br:backrooms positioned 0 64 0 run function br:innen
