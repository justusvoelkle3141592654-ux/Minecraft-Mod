execute in br:backrooms unless loaded -124 64 -84 run return run schedule function br:bau/warten 1s
execute in br:backrooms unless loaded 96 64 -84 run return run schedule function br:bau/warten 1s
execute in br:backrooms unless loaded -124 64 75 run return run schedule function br:bau/warten 1s
execute in br:backrooms unless loaded 96 64 75 run return run schedule function br:bau/warten 1s
execute in br:backrooms unless loaded -14 64 -5 run return run schedule function br:bau/warten 1s
function br:bau/schritt
