execute in br:backrooms run forceload add -124 -84 96 75
scoreboard players set #bau br 0
tellraw @a {"text":"Die Backrooms werden gebaut …","color":"gray","italic":true}
schedule function br:bau/warten 2s
