fill -39 65 22 -35 68 22 air
fill -34 65 17 -34 68 21 air
fill -39 65 28 -35 68 28 air
fill -34 65 23 -34 68 27 air
fill -39 65 34 -35 68 34 air
fill -39 65 40 -35 68 40 air
fill -34 65 35 -34 68 39 air
fill -39 65 46 -35 68 46 air
fill -34 65 41 -34 68 45 air
fill -39 65 52 -35 68 52 air
fill -34 65 47 -34 68 51 air
fill -39 65 58 -35 68 58 air
fill -34 65 53 -34 68 57 air
fill -39 65 64 -35 68 64 air
fill -34 65 59 -34 68 63 air
fill -34 65 65 -34 68 69 air
fill -33 65 16 -29 68 16 air
fill -28 65 11 -28 68 15 air
fill -33 65 28 -29 68 28 air
fill -28 65 23 -28 68 27 air
fill -33 65 34 -29 68 34 air
fill -28 65 29 -28 68 33 air
fill -28 65 35 -28 68 39 air
fill -33 65 46 -29 68 46 air
fill -28 65 41 -28 68 45 air
fill -33 65 58 -29 68 58 air
fill -28 65 53 -28 68 57 air
fill -33 65 64 -29 68 64 air
fill -28 65 59 -28 68 63 air
fill -28 65 65 -28 68 69 air
fill -27 65 16 -23 68 16 air
fill -27 65 22 -23 68 22 air
fill -27 65 28 -23 68 28 air
fill -22 65 23 -22 68 27 air
fill -27 65 34 -23 68 34 air
fill -22 65 29 -22 68 33 air
fill -27 65 40 -23 68 40 air
fill -22 65 35 -22 68 39 air
fill -27 65 46 -23 68 46 air
fill -27 65 52 -23 68 52 air
fill -22 65 53 -22 68 57 air
fill -27 65 64 -23 68 64 air
fill -22 65 59 -22 68 63 air
fill -22 65 65 -22 68 69 air
fill -21 65 16 -17 68 16 air
fill -21 65 22 -17 68 22 air
fill -16 65 17 -16 68 21 air
fill -16 65 23 -16 68 27 air
fill -16 65 29 -16 68 33 air
fill -21 65 40 -17 68 40 air
fill -21 65 46 -17 68 46 air
fill -16 65 41 -16 68 45 air
fill -21 65 52 -17 68 52 air
fill -16 65 47 -16 68 51 air
fill -21 65 58 -17 68 58 air
fill -16 65 59 -16 68 63 air
fill -16 65 65 -16 68 69 air
fill -15 65 16 -11 68 16 air
fill -10 65 11 -10 68 15 air
fill -15 65 34 -11 68 34 air
fill -10 65 29 -10 68 33 air
fill -15 65 40 -11 68 40 air
fill -10 65 35 -10 68 39 air
fill -10 65 41 -10 68 45 air
fill -15 65 52 -11 68 52 air
fill -10 65 47 -10 68 51 air
fill -10 65 53 -10 68 57 air
fill -15 65 64 -11 68 64 air
fill -10 65 59 -10 68 63 air
fill -10 65 65 -10 68 69 air
fill -9 65 16 -5 68 16 air
fill -4 65 11 -4 68 15 air
fill -9 65 22 -5 68 22 air
fill -4 65 17 -4 68 21 air
fill -9 65 28 -5 68 28 air
fill -9 65 34 -5 68 34 air
fill -4 65 29 -4 68 33 air
fill -9 65 40 -5 68 40 air
fill -4 65 35 -4 68 39 air
fill -9 65 46 -5 68 46 air
fill -4 65 41 -4 68 45 air
fill -9 65 52 -5 68 52 air
fill -4 65 47 -4 68 51 air
fill -9 65 58 -5 68 58 air
fill -9 65 64 -5 68 64 air
fill -4 65 65 -4 68 69 air
fill -3 65 16 1 68 16 air
fill -3 65 22 1 68 22 air
fill 2 65 17 2 68 21 air
fill -3 65 28 1 68 28 air
fill 2 65 23 2 68 27 air
fill -3 65 34 1 68 34 air
fill 2 65 29 2 68 33 air
fill 2 65 35 2 68 39 air
fill 2 65 41 2 68 45 air
fill -3 65 52 1 68 52 air
fill 2 65 47 2 68 51 air
fill -3 65 58 1 68 58 air
fill 2 65 59 2 68 63 air
fill 2 65 65 2 68 69 air
fill 8 65 11 8 68 15 air
fill 8 65 17 8 68 21 air
fill 3 65 28 7 68 28 air
fill 8 65 23 8 68 27 air
fill 3 65 34 7 68 34 air
fill 3 65 40 7 68 40 air
fill 8 65 35 8 68 39 air
fill 3 65 46 7 68 46 air
fill 8 65 41 8 68 45 air
fill 3 65 52 7 68 52 air
fill 3 65 58 7 68 58 air
fill 8 65 53 8 68 57 air
fill 3 65 64 7 68 64 air
fill 8 65 59 8 68 63 air
fill 8 65 65 8 68 69 air
fill 9 65 16 13 68 16 air
fill 14 65 11 14 68 15 air
fill 14 65 17 14 68 21 air
fill 9 65 28 13 68 28 air
fill 14 65 23 14 68 27 air
fill 9 65 34 13 68 34 air
fill 9 65 40 13 68 40 air
fill 9 65 46 13 68 46 air
fill 14 65 41 14 68 45 air
fill 9 65 58 13 68 58 air
fill 14 65 53 14 68 57 air
fill 14 65 59 14 68 63 air
fill 14 65 65 14 68 69 air
fill 15 65 16 19 68 16 air
fill 15 65 28 19 68 28 air
fill 15 65 34 19 68 34 air
fill 15 65 40 19 68 40 air
fill 15 65 46 19 68 46 air
fill 15 65 52 19 68 52 air
fill 15 65 58 19 68 58 air
fill 15 65 64 19 68 64 air
setblock -37 69 13 structure_block[mode=corner]
setblock -37 68 13 light[level=15]
setblock -37 69 19 structure_block[mode=corner]
setblock -37 68 19 light[level=15]
setblock -37 69 25 structure_block[mode=corner]
setblock -37 68 25 light[level=15]
fill -39 65 24 -39 65 26 dark_oak_slab[type=top]
fill -39 65 23 -38 66 23 light_gray_wool
fill -39 65 27 -38 66 27 light_gray_wool
setblock -37 69 31 structure_block[mode=corner]
setblock -37 68 31 light[level=15]
fill -38 65 29 -36 65 29 dark_oak_slab[type=top]
fill -39 65 29 -39 66 30 light_gray_wool
fill -35 65 29 -35 66 30 light_gray_wool
setblock -37 69 43 structure_block[mode=corner]
setblock -37 68 43 light[level=15]
fill -35 65 42 -35 65 44 dark_oak_slab[type=top]
fill -35 65 41 -36 66 41 light_gray_wool
fill -35 65 45 -36 66 45 light_gray_wool
setblock -37 69 49 structure_block[mode=corner]
setblock -37 68 49 light[level=15]
fill -39 65 48 -39 65 50 dark_oak_slab[type=top]
fill -39 65 47 -38 66 47 light_gray_wool
fill -39 65 51 -38 66 51 light_gray_wool
fill -38 65 57 -36 65 57 dark_oak_slab[type=top]
fill -39 65 57 -39 66 56 light_gray_wool
fill -35 65 57 -35 66 56 light_gray_wool
setblock -37 69 61 structure_block[mode=corner]
setblock -37 68 61 light[level=15]
fill -35 65 60 -35 65 62 dark_oak_slab[type=top]
fill -35 65 59 -36 66 59 light_gray_wool
fill -35 65 63 -36 66 63 light_gray_wool
setblock -37 69 67 structure_block[mode=corner]
setblock -37 68 67 light[level=15]
fill -39 65 66 -39 65 68 dark_oak_slab[type=top]
fill -39 65 65 -38 66 65 light_gray_wool
fill -39 65 69 -38 66 69 light_gray_wool
fill -32 65 11 -30 65 11 dark_oak_slab[type=top]
fill -33 65 11 -33 66 12 light_gray_wool
fill -29 65 11 -29 66 12 light_gray_wool
setblock -31 69 19 structure_block[mode=corner]
setblock -31 68 19 light[level=15]
fill -29 65 18 -29 65 20 dark_oak_slab[type=top]
fill -29 65 17 -30 66 17 light_gray_wool
fill -29 65 21 -30 66 21 light_gray_wool
setblock -31 69 25 structure_block[mode=corner]
setblock -31 68 25 light[level=15]
fill -32 65 27 -30 65 27 dark_oak_slab[type=top]
fill -33 65 27 -33 66 26 light_gray_wool
fill -29 65 27 -29 66 26 light_gray_wool
setblock -31 69 31 structure_block[mode=corner]
setblock -31 68 31 light[level=15]
setblock -31 69 37 structure_block[mode=corner]
setblock -31 68 37 light[level=15]
fill -32 65 35 -30 65 35 dark_oak_slab[type=top]
fill -33 65 35 -33 66 36 light_gray_wool
fill -29 65 35 -29 66 36 light_gray_wool
setblock -31 69 43 structure_block[mode=corner]
setblock -31 68 43 light[level=15]
fill -33 65 42 -33 65 44 dark_oak_slab[type=top]
fill -33 65 41 -32 66 41 light_gray_wool
fill -33 65 45 -32 66 45 light_gray_wool
setblock -31 69 49 structure_block[mode=corner]
setblock -31 68 49 light[level=15]
fill -33 65 48 -33 65 50 dark_oak_slab[type=top]
fill -33 65 47 -32 66 47 light_gray_wool
fill -33 65 51 -32 66 51 light_gray_wool
fill -32 65 57 -30 65 57 dark_oak_slab[type=top]
fill -33 65 57 -33 66 56 light_gray_wool
fill -29 65 57 -29 66 56 light_gray_wool
setblock -31 69 61 structure_block[mode=corner]
setblock -31 68 61 light[level=15]
fill -29 65 60 -29 65 62 dark_oak_slab[type=top]
fill -29 65 59 -30 66 59 light_gray_wool
fill -29 65 63 -30 66 63 light_gray_wool
setblock -31 69 67 structure_block[mode=corner]
setblock -31 68 67 light[level=15]
fill -33 65 66 -33 65 68 dark_oak_slab[type=top]
fill -33 65 65 -32 66 65 light_gray_wool
fill -33 65 69 -32 66 69 light_gray_wool
setblock -25 69 13 structure_block[mode=corner]
setblock -25 68 13 light[level=15]
setblock -25 69 19 structure_block[mode=corner]
setblock -25 68 19 light[level=15]
fill -26 65 27 -24 65 27 dark_oak_slab[type=top]
fill -27 65 27 -27 66 26 light_gray_wool
fill -23 65 27 -23 66 26 light_gray_wool
setblock -25 69 31 structure_block[mode=corner]
setblock -25 68 31 light[level=15]
fill -26 65 33 -24 65 33 dark_oak_slab[type=top]
fill -27 65 33 -27 66 32 light_gray_wool
fill -23 65 33 -23 66 32 light_gray_wool
fill -27 65 36 -27 65 38 dark_oak_slab[type=top]
fill -27 65 35 -26 66 35 light_gray_wool
fill -27 65 39 -26 66 39 light_gray_wool
setblock -25 69 43 structure_block[mode=corner]
setblock -25 68 43 light[level=15]
setblock -25 69 61 structure_block[mode=corner]
setblock -25 68 61 light[level=15]
setblock -25 69 67 structure_block[mode=corner]
setblock -25 68 67 light[level=15]
fill -27 65 66 -27 65 68 dark_oak_slab[type=top]
fill -27 65 65 -26 66 65 light_gray_wool
fill -27 65 69 -26 66 69 light_gray_wool
setblock -19 69 13 structure_block[mode=corner]
setblock -19 68 13 light[level=15]
setblock -19 69 19 structure_block[mode=corner]
setblock -19 68 19 light[level=15]
fill -20 65 17 -18 65 17 dark_oak_slab[type=top]
fill -21 65 17 -21 66 18 light_gray_wool
fill -17 65 17 -17 66 18 light_gray_wool
setblock -19 69 25 structure_block[mode=corner]
setblock -19 68 25 light[level=15]
fill -17 65 24 -17 65 26 dark_oak_slab[type=top]
