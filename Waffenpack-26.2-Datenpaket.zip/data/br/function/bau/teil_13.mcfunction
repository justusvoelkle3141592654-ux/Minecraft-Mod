summon item_display -38.5 65.85 67.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -30.5 65.85 11.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -28.5 65.85 19.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -30.5 65.85 27.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -30.5 65.85 35.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -32.5 65.85 43.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -32.5 65.85 49.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -30.5 65.85 57.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -28.5 65.85 61.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -32.5 65.85 67.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -24.5 65.85 27.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -24.5 65.85 33.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -26.5 65.85 37.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -26.5 65.85 67.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -18.5 65.85 17.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -16.5 65.85 25.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -18.5 65.85 29.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -20.5 65.85 37.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -18.5 65.85 41.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -16.5 65.85 55.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -14.5 65.85 13.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -10.5 65.85 25.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -12.5 65.85 29.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -10.5 65.85 43.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -12.5 65.85 51.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -14.5 65.85 55.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -14.5 65.85 61.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -6.5 65.85 35.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -6.5 65.85 45.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -4.5 65.85 49.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -8.5 65.85 55.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -8.5 65.85 61.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -0.5 65.85 15.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -2.5 65.85 19.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -2.5 65.85 31.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -2.5 65.85 43.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -0.5 65.85 51.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -2.5 65.85 55.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -0.5 65.85 63.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -2.5 65.85 67.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 5.5 65.85 15.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 5.5 65.85 21.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 5.5 65.85 27.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 5.5 65.85 33.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 7.5 65.85 37.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 7.5 65.85 49.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 3.5 65.85 55.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 5.5 65.85 63.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 5.5 65.85 65.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 9.5 65.85 13.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 13.5 65.85 19.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 11.5 65.85 41.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 9.5 65.85 55.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 11.5 65.85 59.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 17.5 65.85 27.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 15.5 65.85 31.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 19.5 65.85 37.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 17.5 65.85 41.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 17.5 65.85 53.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display 15.5 65.85 61.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
fill 39 63 9 75 63 45 reinforced_deepslate
fill 39 78 9 75 78 45 reinforced_deepslate
fill 39 63 9 75 78 9 reinforced_deepslate
fill 39 63 45 75 78 45 reinforced_deepslate
fill 39 63 9 39 78 45 reinforced_deepslate
fill 75 63 9 75 78 45 reinforced_deepslate
fill 40 64 10 74 77 44 deepslate_tiles
fill 57 64 10 57 64 10 sculk
fill 57 65 10 57 76 10 air
fill 52 64 11 62 64 11 sculk
fill 52 65 11 62 76 11 air
fill 49 64 12 65 64 12 sculk
fill 49 65 12 65 76 12 air
fill 48 64 13 66 64 13 sculk
fill 48 65 13 66 76 13 air
fill 47 64 14 67 64 14 sculk
fill 47 65 14 67 76 14 air
fill 45 64 15 69 64 15 sculk
fill 45 65 15 69 76 15 air
fill 45 64 16 69 64 16 sculk
fill 45 65 16 69 76 16 air
fill 44 64 17 70 64 17 sculk
fill 44 65 17 70 76 17 air
fill 43 64 18 71 64 18 sculk
fill 43 65 18 71 76 18 air
fill 42 64 19 72 64 19 sculk
fill 42 65 19 72 76 19 air
fill 42 64 20 72 64 20 sculk
fill 42 65 20 72 76 20 air
fill 42 64 21 72 64 21 sculk
fill 42 65 21 72 76 21 air
fill 41 64 22 73 64 22 sculk
fill 41 65 22 73 76 22 air
fill 41 64 23 73 64 23 sculk
fill 41 65 23 73 76 23 air
fill 41 64 24 73 64 24 sculk
fill 41 65 24 73 76 24 air
fill 41 64 25 73 64 25 sculk
fill 41 65 25 73 76 25 air
fill 41 64 26 73 64 26 sculk
fill 41 65 26 73 76 26 air
fill 40 64 27 74 64 27 sculk
fill 40 65 27 74 76 27 air
fill 41 64 28 73 64 28 sculk
fill 41 65 28 73 76 28 air
fill 41 64 29 73 64 29 sculk
fill 41 65 29 73 76 29 air
fill 41 64 30 73 64 30 sculk
fill 41 65 30 73 76 30 air
fill 41 64 31 73 64 31 sculk
fill 41 65 31 73 76 31 air
fill 41 64 32 73 64 32 sculk
fill 41 65 32 73 76 32 air
fill 42 64 33 72 64 33 sculk
fill 42 65 33 72 76 33 air
fill 42 64 34 72 64 34 sculk
fill 42 65 34 72 76 34 air
fill 42 64 35 72 64 35 sculk
fill 42 65 35 72 76 35 air
fill 43 64 36 71 64 36 sculk
fill 43 65 36 71 76 36 air
fill 44 64 37 70 64 37 sculk
fill 44 65 37 70 76 37 air
fill 45 64 38 69 64 38 sculk
fill 45 65 38 69 76 38 air
fill 45 64 39 69 64 39 sculk
fill 45 65 39 69 76 39 air
fill 47 64 40 67 64 40 sculk
fill 47 65 40 67 76 40 air
fill 48 64 41 66 64 41 sculk
fill 48 65 41 66 76 41 air
fill 49 64 42 65 64 42 sculk
fill 49 65 42 65 76 42 air
fill 52 64 43 62 64 43 sculk
fill 52 65 43 62 76 43 air
fill 57 64 44 57 64 44 sculk
fill 57 65 44 57 76 44 air
setblock 44 68 39 sculk
setblock 75 71 26 sculk
setblock 41 76 19 sculk
setblock 53 69 44 sculk
setblock 44 76 39 sculk
setblock 58 65 9 sculk
setblock 60 75 10 sculk
setblock 75 65 27 sculk
setblock 41 67 34 sculk
setblock 75 76 26 sculk
setblock 50 69 43 sculk
setblock 47 74 12 sculk
setblock 42 66 18 sculk
setblock 61 65 10 sculk
setblock 41 69 34 sculk
setblock 67 68 12 sculk
setblock 73 70 35 sculk
setblock 55 67 10 sculk
setblock 40 65 21 sculk
setblock 70 67 39 sculk
setblock 50 67 11 sculk
setblock 74 70 33 sculk
setblock 60 65 44 sculk
setblock 43 67 16 sculk
setblock 41 65 34 sculk
setblock 51 67 44 sculk
setblock 71 66 38 sculk
setblock 42 75 37 sculk
setblock 47 71 12 sculk
setblock 59 66 44 sculk
setblock 69 72 40 sculk
setblock 74 71 21 sculk
setblock 41 76 35 sculk
setblock 54 65 44 sculk
setblock 70 75 15 sculk
setblock 40 67 31 sculk
setblock 68 66 40 sculk
setblock 53 76 10 sculk
setblock 68 66 14 sculk
setblock 75 76 26 sculk
setblock 69 71 40 sculk
setblock 47 76 12 sculk
setblock 72 73 36 sculk
setblock 42 66 36 sculk
setblock 74 68 23 sculk
setblock 60 70 44 sculk
setblock 55 75 9 sculk
setblock 54 72 10 sculk
setblock 72 75 36 sculk
setblock 54 68 44 sculk
setblock 73 68 19 sculk
setblock 54 76 44 sculk
setblock 49 74 43 sculk
setblock 44 69 39 sculk
setblock 57 76 9 sculk
setblock 72 73 36 sculk
setblock 66 65 42 sculk
setblock 60 72 44 sculk
setblock 48 66 12 sculk
setblock 75 73 26 sculk
setblock 41 67 20 sculk
setblock 39 66 28 sculk
setblock 59 75 44 sculk
setblock 54 72 10 sculk
setblock 43 76 17 sculk
setblock 63 72 43 sculk
setblock 43 70 38 sculk
setblock 71 70 16 sculk
setblock 74 74 30 sculk
setblock 52 67 10 sculk
setblock 46 73 14 sculk
setblock 40 67 25 sculk
setblock 42 66 36 sculk
setblock 74 75 32 sculk
setblock 42 70 17 sculk
setblock 61 71 44 sculk
setblock 73 69 19 sculk
setblock 53 69 44 sculk
setblock 68 74 13 sculk
setblock 59 66 44 sculk
setblock 69 69 14 sculk
setblock 44 71 15 sculk
setblock 51 72 44 sculk
setblock 51 68 11 sculk
setblock 71 72 37 sculk
setblock 42 68 17 sculk
setblock 39 72 29 sculk
setblock 52 68 44 sculk
setblock 39 74 28 sculk
setblock 65 65 11 sculk
setblock 43 76 16 sculk
setblock 64 73 11 sculk
setblock 74 75 30 sculk
setblock 63 72 44 sculk
setblock 49 70 43 sculk
setblock 42 71 19 sculk
setblock 69 68 14 sculk
setblock 66 74 42 sculk
setblock 39 67 25 sculk
setblock 74 74 30 sculk
setblock 40 65 24 sculk
setblock 59 69 45 sculk
setblock 44 73 15 sculk
setblock 59 76 9 sculk
setblock 57 76 45 sculk
setblock 64 73 43 sculk
setblock 49 73 43 sculk
setblock 50 72 11 sculk
setblock 73 73 34 sculk
setblock 54 68 10 sculk
setblock 45 69 40 sculk
setblock 39 75 29 sculk
setblock 63 72 10 sculk
