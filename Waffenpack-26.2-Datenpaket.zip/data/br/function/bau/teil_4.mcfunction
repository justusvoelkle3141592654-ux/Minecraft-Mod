setblock -14 64 -22 water
setblock -13 64 -74 water
setblock -24 64 -77 water
setblock -35 64 -36 water
setblock -11 64 -76 water
setblock -23 64 -61 water
setblock 7 64 -41 water
setblock 14 64 -53 water
setblock -37 72 -77 structure_block[mode=corner]
setblock -37 71 -77 light[level=15]
setblock -37 72 -71 structure_block[mode=corner]
setblock -37 71 -71 light[level=15]
setblock -37 72 -65 structure_block[mode=corner]
setblock -37 71 -65 light[level=15]
setblock -37 72 -59 structure_block[mode=corner]
setblock -37 71 -59 light[level=15]
setblock -37 72 -53 structure_block[mode=corner]
setblock -37 71 -53 light[level=15]
setblock -37 72 -47 structure_block[mode=corner]
setblock -37 71 -47 light[level=15]
setblock -37 72 -35 structure_block[mode=corner]
setblock -37 71 -35 light[level=15]
setblock -37 72 -29 structure_block[mode=corner]
setblock -37 71 -29 light[level=15]
setblock -37 72 -23 structure_block[mode=corner]
setblock -37 71 -23 light[level=15]
setblock -31 72 -59 structure_block[mode=corner]
setblock -31 71 -59 light[level=15]
setblock -31 72 -47 structure_block[mode=corner]
setblock -31 71 -47 light[level=15]
setblock -31 72 -35 structure_block[mode=corner]
setblock -31 71 -35 light[level=15]
setblock -31 72 -29 structure_block[mode=corner]
setblock -31 71 -29 light[level=15]
setblock -31 72 -23 structure_block[mode=corner]
setblock -31 71 -23 light[level=15]
setblock -25 72 -71 structure_block[mode=corner]
setblock -25 71 -71 light[level=15]
setblock -25 72 -65 structure_block[mode=corner]
setblock -25 71 -65 light[level=15]
setblock -25 72 -41 structure_block[mode=corner]
setblock -25 71 -41 light[level=15]
setblock -25 72 -35 structure_block[mode=corner]
setblock -25 71 -35 light[level=15]
setblock -25 72 -29 structure_block[mode=corner]
setblock -25 71 -29 light[level=15]
setblock -25 72 -23 structure_block[mode=corner]
setblock -25 71 -23 light[level=15]
setblock -19 72 -77 structure_block[mode=corner]
setblock -19 71 -77 light[level=15]
setblock -19 72 -71 structure_block[mode=corner]
setblock -19 71 -71 light[level=15]
setblock -19 72 -65 structure_block[mode=corner]
setblock -19 71 -65 light[level=15]
setblock -19 72 -59 structure_block[mode=corner]
setblock -19 71 -59 light[level=15]
setblock -19 72 -41 structure_block[mode=corner]
setblock -19 71 -41 light[level=15]
setblock -19 72 -35 structure_block[mode=corner]
setblock -19 71 -35 light[level=15]
setblock -13 72 -77 structure_block[mode=corner]
setblock -13 71 -77 light[level=15]
setblock -13 72 -71 structure_block[mode=corner]
setblock -13 71 -71 light[level=15]
setblock -13 72 -65 structure_block[mode=corner]
setblock -13 71 -65 light[level=15]
setblock -13 72 -59 structure_block[mode=corner]
setblock -13 71 -59 light[level=15]
setblock -13 72 -53 structure_block[mode=corner]
setblock -13 71 -53 light[level=15]
setblock -13 72 -41 structure_block[mode=corner]
setblock -13 71 -41 light[level=15]
setblock -13 72 -35 structure_block[mode=corner]
setblock -13 71 -35 light[level=15]
setblock -13 72 -23 structure_block[mode=corner]
setblock -13 71 -23 light[level=15]
setblock -7 72 -77 structure_block[mode=corner]
setblock -7 71 -77 light[level=15]
setblock -7 72 -71 structure_block[mode=corner]
setblock -7 71 -71 light[level=15]
setblock -7 72 -65 structure_block[mode=corner]
setblock -7 71 -65 light[level=15]
setblock -7 72 -59 structure_block[mode=corner]
setblock -7 71 -59 light[level=15]
setblock -7 72 -53 structure_block[mode=corner]
setblock -7 71 -53 light[level=15]
setblock -7 72 -41 structure_block[mode=corner]
setblock -7 71 -41 light[level=15]
setblock -7 72 -35 structure_block[mode=corner]
setblock -7 71 -35 light[level=15]
setblock -7 72 -29 structure_block[mode=corner]
setblock -7 71 -29 light[level=15]
setblock -7 72 -23 structure_block[mode=corner]
setblock -7 71 -23 light[level=15]
setblock -1 72 -77 structure_block[mode=corner]
setblock -1 71 -77 light[level=15]
setblock -1 72 -71 structure_block[mode=corner]
setblock -1 71 -71 light[level=15]
setblock -1 72 -65 structure_block[mode=corner]
setblock -1 71 -65 light[level=15]
setblock -1 72 -59 structure_block[mode=corner]
setblock -1 71 -59 light[level=15]
setblock -1 72 -47 structure_block[mode=corner]
setblock -1 71 -47 light[level=15]
setblock -1 72 -23 structure_block[mode=corner]
setblock -1 71 -23 light[level=15]
setblock 5 72 -77 structure_block[mode=corner]
setblock 5 71 -77 light[level=15]
setblock 5 72 -71 structure_block[mode=corner]
setblock 5 71 -71 light[level=15]
setblock 5 72 -65 structure_block[mode=corner]
setblock 5 71 -65 light[level=15]
setblock 5 72 -53 structure_block[mode=corner]
setblock 5 71 -53 light[level=15]
setblock 5 72 -47 structure_block[mode=corner]
setblock 5 71 -47 light[level=15]
setblock 5 72 -41 structure_block[mode=corner]
setblock 5 71 -41 light[level=15]
setblock 5 72 -35 structure_block[mode=corner]
setblock 5 71 -35 light[level=15]
setblock 5 72 -29 structure_block[mode=corner]
setblock 5 71 -29 light[level=15]
setblock 5 72 -23 structure_block[mode=corner]
setblock 5 71 -23 light[level=15]
setblock 11 72 -71 structure_block[mode=corner]
setblock 11 71 -71 light[level=15]
setblock 11 72 -65 structure_block[mode=corner]
setblock 11 71 -65 light[level=15]
setblock 11 72 -47 structure_block[mode=corner]
setblock 11 71 -47 light[level=15]
setblock 11 72 -41 structure_block[mode=corner]
setblock 11 71 -41 light[level=15]
setblock 11 72 -35 structure_block[mode=corner]
setblock 11 71 -35 light[level=15]
setblock 11 72 -29 structure_block[mode=corner]
setblock 11 71 -29 light[level=15]
setblock 11 72 -23 structure_block[mode=corner]
setblock 11 71 -23 light[level=15]
setblock 17 72 -77 structure_block[mode=corner]
setblock 17 71 -77 light[level=15]
setblock 17 72 -47 structure_block[mode=corner]
setblock 17 71 -47 light[level=15]
setblock 17 72 -41 structure_block[mode=corner]
setblock 17 71 -41 light[level=15]
setblock 17 72 -35 structure_block[mode=corner]
setblock 17 71 -35 light[level=15]
fill 9 65 -47 11 67 -45 air
fill 9 65 -31 11 67 -29 air
fill -23 65 -63 -21 67 -61 air
fill -7 65 -63 -5 67 -61 air
fill 9 65 -63 11 67 -61 air
fill -23 65 -55 -21 67 -53 air
fill -23 65 -71 -21 67 -69 air
fill 1 65 -63 3 67 -61 air
fill -31 65 -47 -29 67 -45 air
fill 1 65 -39 3 67 -37 air
fill -15 65 -55 -13 67 -53 air
fill -31 65 -55 -29 67 -53 air
fill -31 65 -63 -29 67 -61 air
fill -15 65 -47 -13 67 -45 air
fill -11 65 -56 -8 67 -55 air
setblock -9 66 -56 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"NOTSTROM",color:"dark_red",bold:true},"Hebel umlegen",""]}}
setblock -10 72 -55 structure_block[mode=corner]
setblock -10 71 -55 light[level=15]
fill -35 65 -48 -32 67 -47 air
setblock -33 66 -48 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"NOTSTROM",color:"dark_red",bold:true},"Hebel umlegen",""]}}
setblock -34 72 -47 structure_block[mode=corner]
setblock -34 71 -47 light[level=15]
fill 13 65 -24 16 67 -23 air
setblock 15 66 -24 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"NOTSTROM",color:"dark_red",bold:true},"Hebel umlegen",""]}}
setblock 14 72 -23 structure_block[mode=corner]
setblock 14 71 -23 light[level=15]
fill 15 65 -22 19 67 -20 air
fill 16 65 -20 16 68 -20 smooth_stone
fill 18 65 -20 18 68 -20 smooth_stone
fill 16 68 -20 18 68 -20 smooth_stone
setblock 17 68 -21 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"AUFZUG",color:"dark_red",bold:true},"→ Level 2",{text:"(kein Strom)",color:"gray"}]}}
setblock 17 72 -21 structure_block[mode=corner]
setblock 17 71 -21 light[level=15]
fill 17 65 -20 17 67 -20 iron_block
setblock -10 66 -56 lever[face=wall,facing=south,powered=false]
setblock -34 66 -48 lever[face=wall,facing=south,powered=false]
setblock 14 66 -24 lever[face=wall,facing=south,powered=false]
fill 39 63 -81 92 63 -28 reinforced_deepslate
fill 39 70 -81 92 70 -28 reinforced_deepslate
fill 39 63 -81 92 70 -81 reinforced_deepslate
fill 39 63 -28 92 70 -28 reinforced_deepslate
fill 39 63 -81 39 70 -28 reinforced_deepslate
fill 92 63 -81 92 70 -28 reinforced_deepslate
fill 40 64 -80 91 64 -29 polished_deepslate
fill 40 69 -80 91 69 -29 deepslate_tiles
fill 40 65 -80 91 68 -29 reinforced_deepslate
fill 41 65 -79 42 68 -78 air
fill 41 65 -76 42 68 -75 air
fill 41 65 -73 42 68 -72 air
fill 41 65 -70 42 68 -69 air
fill 41 65 -67 42 68 -66 air
fill 41 65 -64 42 68 -63 air
fill 41 65 -61 42 68 -60 air
fill 41 65 -58 42 68 -57 air
fill 41 65 -55 42 68 -54 air
fill 41 65 -52 42 68 -51 air
fill 41 65 -49 42 68 -48 air
fill 41 65 -46 42 68 -45 air
fill 41 65 -43 42 68 -42 air
fill 41 65 -40 42 68 -39 air
fill 41 65 -37 42 68 -36 air
fill 41 65 -34 42 68 -33 air
fill 41 65 -31 42 68 -30 air
fill 44 65 -79 45 68 -78 air
fill 44 65 -76 45 68 -75 air
fill 44 65 -73 45 68 -72 air
fill 44 65 -70 45 68 -69 air
fill 44 65 -67 45 68 -66 air
fill 44 65 -64 45 68 -63 air
fill 44 65 -61 45 68 -60 air
fill 44 65 -58 45 68 -57 air
fill 44 65 -55 45 68 -54 air
fill 44 65 -52 45 68 -51 air
fill 44 65 -49 45 68 -48 air
fill 44 65 -46 45 68 -45 air
fill 44 65 -43 45 68 -42 air
fill 44 65 -40 45 68 -39 air
fill 44 65 -37 45 68 -36 air
fill 44 65 -34 45 68 -33 air
fill 44 65 -31 45 68 -30 air
fill 47 65 -79 48 68 -78 air
fill 47 65 -76 48 68 -75 air
fill 47 65 -73 48 68 -72 air
fill 47 65 -70 48 68 -69 air
fill 47 65 -67 48 68 -66 air
fill 47 65 -64 48 68 -63 air
fill 47 65 -61 48 68 -60 air
fill 47 65 -58 48 68 -57 air
fill 47 65 -55 48 68 -54 air
fill 47 65 -52 48 68 -51 air
fill 47 65 -49 48 68 -48 air
fill 47 65 -46 48 68 -45 air
fill 47 65 -43 48 68 -42 air
fill 47 65 -40 48 68 -39 air
fill 47 65 -37 48 68 -36 air
fill 47 65 -34 48 68 -33 air
fill 47 65 -31 48 68 -30 air
fill 50 65 -79 51 68 -78 air
fill 50 65 -76 51 68 -75 air
fill 50 65 -73 51 68 -72 air
fill 50 65 -70 51 68 -69 air
fill 50 65 -67 51 68 -66 air
fill 50 65 -64 51 68 -63 air
fill 50 65 -61 51 68 -60 air
