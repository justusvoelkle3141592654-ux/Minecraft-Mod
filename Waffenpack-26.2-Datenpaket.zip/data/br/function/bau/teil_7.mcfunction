fill 85 65 -64 85 68 -63 air
fill 83 65 -59 84 68 -59 air
fill 83 65 -56 84 68 -56 air
fill 85 65 -58 85 68 -57 air
fill 83 65 -50 84 68 -50 air
fill 85 65 -52 85 68 -51 air
fill 85 65 -49 85 68 -48 air
fill 85 65 -46 85 68 -45 air
fill 85 65 -43 85 68 -42 air
fill 83 65 -38 84 68 -38 air
fill 85 65 -37 85 68 -36 air
fill 83 65 -32 84 68 -32 air
fill 85 65 -34 85 68 -33 air
fill 85 65 -31 85 68 -30 air
fill 86 65 -77 87 68 -77 air
fill 88 65 -79 88 68 -78 air
fill 88 65 -76 88 68 -75 air
fill 86 65 -71 87 68 -71 air
fill 88 65 -73 88 68 -72 air
fill 86 65 -68 87 68 -68 air
fill 86 65 -62 87 68 -62 air
fill 88 65 -61 88 68 -60 air
fill 88 65 -58 88 68 -57 air
fill 86 65 -53 87 68 -53 air
fill 88 65 -55 88 68 -54 air
fill 88 65 -52 88 68 -51 air
fill 88 65 -49 88 68 -48 air
fill 88 65 -46 88 68 -45 air
fill 86 65 -41 87 68 -41 air
fill 88 65 -40 88 68 -39 air
fill 86 65 -35 87 68 -35 air
fill 88 65 -31 88 68 -30 air
fill 89 65 -74 90 68 -74 air
fill 89 65 -71 90 68 -71 air
fill 89 65 -68 90 68 -68 air
fill 89 65 -65 90 68 -65 air
fill 89 65 -59 90 68 -59 air
fill 89 65 -56 90 68 -56 air
fill 89 65 -50 90 68 -50 air
fill 89 65 -47 90 68 -47 air
fill 89 65 -41 90 68 -41 air
fill 89 65 -38 90 68 -38 air
fill 89 65 -35 90 68 -35 air
fill 89 65 -32 90 68 -32 air
fill 40 67 -80 91 67 -29 waxed_exposed_cut_copper replace reinforced_deepslate
fill 40 69 -78 91 69 -78 waxed_oxidized_cut_copper
fill 40 69 -72 91 69 -72 waxed_oxidized_cut_copper
fill 40 69 -66 91 69 -66 waxed_oxidized_cut_copper
fill 40 69 -60 91 69 -60 waxed_oxidized_cut_copper
fill 40 69 -54 91 69 -54 waxed_oxidized_cut_copper
fill 40 69 -48 91 69 -48 waxed_oxidized_cut_copper
fill 40 69 -42 91 69 -42 waxed_oxidized_cut_copper
fill 40 69 -36 91 69 -36 waxed_oxidized_cut_copper
fill 40 69 -30 91 69 -30 waxed_oxidized_cut_copper
setblock 42 65 -61 redstone_torch
setblock 41 65 -46 redstone_torch
setblock 44 65 -73 redstone_torch
setblock 44 65 -33 redstone_torch
setblock 48 65 -64 redstone_torch
setblock 47 65 -52 redstone_torch
setblock 48 65 -46 redstone_torch
setblock 47 65 -39 redstone_torch
setblock 48 65 -36 redstone_torch
setblock 50 65 -57 redstone_torch
setblock 50 65 -52 redstone_torch
setblock 50 65 -46 redstone_torch
setblock 54 65 -78 redstone_torch
setblock 54 65 -75 redstone_torch
setblock 53 65 -73 redstone_torch
setblock 53 65 -52 redstone_torch
setblock 53 65 -48 redstone_torch
setblock 54 65 -43 redstone_torch
setblock 57 65 -73 redstone_torch
setblock 56 65 -67 redstone_torch
setblock 56 65 -52 redstone_torch
setblock 56 65 -46 redstone_torch
setblock 59 65 -78 redstone_torch
setblock 59 65 -76 redstone_torch
setblock 59 65 -72 redstone_torch
setblock 59 65 -66 redstone_torch
setblock 59 65 -57 redstone_torch
setblock 60 65 -48 redstone_torch
setblock 60 65 -30 redstone_torch
setblock 63 65 -78 redstone_torch
setblock 62 65 -64 redstone_torch
setblock 62 65 -58 redstone_torch
setblock 63 65 -51 redstone_torch
setblock 66 65 -75 redstone_torch
setblock 65 65 -64 redstone_torch
setblock 66 65 -54 redstone_torch
setblock 66 65 -51 redstone_torch
setblock 65 65 -45 redstone_torch
setblock 65 65 -36 redstone_torch
setblock 65 65 -31 redstone_torch
setblock 68 65 -72 redstone_torch
setblock 69 65 -51 redstone_torch
setblock 69 65 -43 redstone_torch
setblock 68 65 -30 redstone_torch
setblock 72 65 -70 redstone_torch
setblock 72 65 -61 redstone_torch
setblock 72 65 -30 redstone_torch
setblock 75 65 -79 redstone_torch
setblock 74 65 -72 redstone_torch
setblock 75 65 -48 redstone_torch
setblock 74 65 -39 redstone_torch
setblock 78 65 -78 redstone_torch
setblock 77 65 -66 redstone_torch
setblock 77 65 -55 redstone_torch
setblock 77 65 -43 redstone_torch
setblock 78 65 -40 redstone_torch
setblock 77 65 -37 redstone_torch
setblock 81 65 -54 redstone_torch
setblock 83 65 -73 redstone_torch
setblock 83 65 -61 redstone_torch
setblock 83 65 -58 redstone_torch
setblock 83 65 -54 redstone_torch
setblock 84 65 -46 redstone_torch
setblock 84 65 -39 redstone_torch
setblock 86 65 -63 redstone_torch
setblock 87 65 -58 redstone_torch
setblock 87 65 -51 redstone_torch
setblock 87 65 -39 redstone_torch
setblock 90 65 -79 redstone_torch
setblock 90 65 -64 redstone_torch
setblock 89 65 -37 redstone_torch
setblock 83 67 -34 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"WARTUNGSSCHACHT",color:"gold"},"→ Level 3",""]}}
setblock 84 65 -33 redstone_torch
setblock 50 69 -76 waxed_exposed_copper_grate
setblock 59 69 -73 waxed_exposed_copper_grate
setblock 44 69 -61 waxed_exposed_copper_grate
setblock 53 69 -58 waxed_exposed_copper_grate
setblock 68 69 -70 waxed_exposed_copper_grate
setblock 77 69 -67 waxed_exposed_copper_grate
setblock 62 69 -55 waxed_exposed_copper_grate
setblock 47 69 -43 waxed_exposed_copper_grate
setblock 80 69 -49 waxed_exposed_copper_grate
setblock 83 65 -34 end_gateway{exit_portal:[I;-118,65,12],exact_teleport:1b,Age:1000L}
fill -121 63 9 -59 63 71 reinforced_deepslate
fill -121 71 9 -59 71 71 reinforced_deepslate
fill -121 63 9 -59 71 9 reinforced_deepslate
fill -121 63 71 -59 71 71 reinforced_deepslate
fill -121 63 9 -121 71 71 reinforced_deepslate
fill -59 63 9 -59 71 71 reinforced_deepslate
fill -120 64 10 -60 64 70 test_block[mode=log]
fill -120 70 10 -60 70 70 smooth_quartz
fill -120 65 10 -60 69 70 test_block[mode=start]
fill -119 65 11 -61 67 13 air
fill -119 65 23 -61 67 25 air
fill -119 65 35 -61 67 37 air
fill -119 65 47 -61 67 49 air
fill -119 65 59 -61 67 61 air
fill -64 65 14 -62 67 22 air
fill -118 65 26 -116 67 34 air
fill -64 65 38 -62 67 46 air
fill -118 65 50 -116 67 58 air
fill -119 65 15 -116 67 17 air
fill -114 65 15 -111 67 17 air
fill -109 65 15 -106 67 17 air
fill -104 65 15 -101 67 17 air
fill -99 65 15 -96 67 17 air
fill -94 65 15 -91 67 17 air
fill -89 65 15 -86 67 17 air
fill -84 65 15 -81 67 17 air
fill -79 65 15 -76 67 17 air
fill -74 65 15 -71 67 17 air
fill -69 65 15 -66 67 17 air
fill -119 65 19 -116 67 21 air
fill -114 65 19 -111 67 21 air
fill -109 65 19 -106 67 21 air
fill -104 65 19 -101 67 21 air
fill -99 65 19 -96 67 21 air
fill -94 65 19 -91 67 21 air
fill -89 65 19 -86 67 21 air
fill -84 65 19 -81 67 21 air
fill -79 65 19 -76 67 21 air
fill -74 65 19 -71 67 21 air
fill -69 65 19 -66 67 21 air
fill -114 65 27 -111 67 29 air
fill -109 65 27 -106 67 29 air
fill -104 65 27 -101 67 29 air
fill -99 65 27 -96 67 29 air
fill -94 65 27 -91 67 29 air
fill -89 65 27 -86 67 29 air
fill -84 65 27 -81 67 29 air
fill -79 65 27 -76 67 29 air
fill -74 65 27 -71 67 29 air
fill -69 65 27 -66 67 29 air
fill -64 65 27 -61 67 29 air
fill -114 65 31 -111 67 33 air
fill -109 65 31 -106 67 33 air
fill -104 65 31 -101 67 33 air
fill -99 65 31 -96 67 33 air
fill -94 65 31 -91 67 33 air
fill -89 65 31 -86 67 33 air
fill -84 65 31 -81 67 33 air
fill -79 65 31 -76 67 33 air
fill -74 65 31 -71 67 33 air
fill -69 65 31 -66 67 33 air
fill -64 65 31 -61 67 33 air
fill -119 65 39 -116 67 41 air
fill -114 65 39 -111 67 41 air
fill -109 65 39 -106 67 41 air
fill -104 65 39 -101 67 41 air
fill -99 65 39 -96 67 41 air
fill -94 65 39 -91 67 41 air
fill -89 65 39 -86 67 41 air
fill -84 65 39 -81 67 41 air
fill -79 65 39 -76 67 41 air
fill -74 65 39 -71 67 41 air
fill -69 65 39 -66 67 41 air
fill -119 65 43 -116 67 45 air
fill -114 65 43 -111 67 45 air
fill -109 65 43 -106 67 45 air
fill -104 65 43 -101 67 45 air
fill -99 65 43 -96 67 45 air
fill -94 65 43 -91 67 45 air
fill -89 65 43 -86 67 45 air
fill -84 65 43 -81 67 45 air
fill -79 65 43 -76 67 45 air
fill -74 65 43 -71 67 45 air
fill -69 65 43 -66 67 45 air
fill -114 65 51 -111 67 53 air
fill -109 65 51 -106 67 53 air
fill -104 65 51 -101 67 53 air
fill -99 65 51 -96 67 53 air
fill -94 65 51 -91 67 53 air
fill -89 65 51 -86 67 53 air
fill -84 65 51 -81 67 53 air
fill -79 65 51 -76 67 53 air
fill -74 65 51 -71 67 53 air
fill -69 65 51 -66 67 53 air
fill -64 65 51 -61 67 53 air
fill -114 65 55 -111 67 57 air
fill -109 65 55 -106 67 57 air
fill -104 65 55 -101 67 57 air
fill -99 65 55 -96 67 57 air
fill -94 65 55 -91 67 57 air
fill -89 65 55 -86 67 57 air
fill -84 65 55 -81 67 57 air
fill -79 65 55 -76 67 57 air
fill -74 65 55 -71 67 57 air
fill -69 65 55 -66 67 57 air
fill -64 65 55 -61 67 57 air
fill -119 65 63 -116 67 67 air
fill -114 65 63 -111 67 67 air
fill -109 65 63 -106 67 67 air
fill -104 65 63 -101 67 67 air
fill -99 65 63 -96 67 67 air
fill -94 65 63 -91 67 67 air
fill -89 65 63 -86 67 67 air
