setblock -78 70 -78 structure_block[mode=corner]
setblock -78 69 -78 light[level=15]
setblock -78 70 -74 structure_block[mode=corner]
setblock -78 69 -74 light[level=15]
setblock -78 70 -66 structure_block[mode=corner]
setblock -78 69 -66 light[level=15]
setblock -78 70 -62 structure_block[mode=corner]
setblock -78 69 -62 light[level=15]
setblock -78 70 -58 structure_block[mode=corner]
setblock -78 69 -58 light[level=15]
setblock -78 70 -54 structure_block[mode=corner]
setblock -78 69 -54 light[level=15]
setblock -78 70 -50 structure_block[mode=corner]
setblock -78 69 -50 light[level=15]
setblock -78 70 -46 structure_block[mode=corner]
setblock -78 69 -46 light[level=15]
setblock -78 70 -42 structure_block[mode=corner]
setblock -78 69 -42 light[level=15]
setblock -78 70 -38 structure_block[mode=corner]
setblock -78 69 -38 light[level=15]
setblock -78 70 -34 structure_block[mode=corner]
setblock -78 69 -34 light[level=15]
setblock -78 70 -30 structure_block[mode=corner]
setblock -78 69 -30 light[level=15]
setblock -78 70 -26 structure_block[mode=corner]
setblock -78 69 -26 light[level=15]
setblock -78 70 -22 structure_block[mode=corner]
setblock -78 69 -22 light[level=15]
setblock -74 70 -74 structure_block[mode=corner]
setblock -74 69 -74 light[level=15]
setblock -74 70 -70 structure_block[mode=corner]
setblock -74 69 -70 light[level=15]
setblock -74 70 -66 structure_block[mode=corner]
setblock -74 69 -66 light[level=15]
setblock -74 70 -62 structure_block[mode=corner]
setblock -74 69 -62 light[level=15]
setblock -74 70 -58 structure_block[mode=corner]
setblock -74 69 -58 light[level=15]
setblock -74 70 -54 structure_block[mode=corner]
setblock -74 69 -54 light[level=15]
setblock -74 70 -50 structure_block[mode=corner]
setblock -74 69 -50 light[level=15]
setblock -74 70 -46 structure_block[mode=corner]
setblock -74 69 -46 light[level=15]
setblock -74 70 -42 structure_block[mode=corner]
setblock -74 69 -42 light[level=15]
setblock -74 70 -38 structure_block[mode=corner]
setblock -74 69 -38 light[level=15]
setblock -74 70 -34 structure_block[mode=corner]
setblock -74 69 -34 light[level=15]
setblock -74 70 -30 structure_block[mode=corner]
setblock -74 69 -30 light[level=15]
setblock -74 70 -22 structure_block[mode=corner]
setblock -74 69 -22 light[level=15]
setblock -70 70 -78 structure_block[mode=corner]
setblock -70 69 -78 light[level=15]
setblock -70 70 -70 structure_block[mode=corner]
setblock -70 69 -70 light[level=15]
setblock -70 70 -62 structure_block[mode=corner]
setblock -70 69 -62 light[level=15]
setblock -70 70 -58 structure_block[mode=corner]
setblock -70 69 -58 light[level=15]
setblock -70 70 -54 structure_block[mode=corner]
setblock -70 69 -54 light[level=15]
setblock -70 70 -50 structure_block[mode=corner]
setblock -70 69 -50 light[level=15]
setblock -70 70 -42 structure_block[mode=corner]
setblock -70 69 -42 light[level=15]
setblock -70 70 -38 structure_block[mode=corner]
setblock -70 69 -38 light[level=15]
setblock -70 70 -34 structure_block[mode=corner]
setblock -70 69 -34 light[level=15]
setblock -70 70 -30 structure_block[mode=corner]
setblock -70 69 -30 light[level=15]
setblock -70 70 -22 structure_block[mode=corner]
setblock -70 69 -22 light[level=15]
setblock -66 70 -74 structure_block[mode=corner]
setblock -66 69 -74 light[level=15]
setblock -66 70 -66 structure_block[mode=corner]
setblock -66 69 -66 light[level=15]
setblock -66 70 -62 structure_block[mode=corner]
setblock -66 69 -62 light[level=15]
setblock -66 70 -54 structure_block[mode=corner]
setblock -66 69 -54 light[level=15]
setblock -66 70 -50 structure_block[mode=corner]
setblock -66 69 -50 light[level=15]
setblock -66 70 -46 structure_block[mode=corner]
setblock -66 69 -46 light[level=15]
setblock -66 70 -42 structure_block[mode=corner]
setblock -66 69 -42 light[level=15]
setblock -66 70 -38 structure_block[mode=corner]
setblock -66 69 -38 light[level=15]
setblock -66 70 -34 structure_block[mode=corner]
setblock -66 69 -34 light[level=15]
setblock -66 70 -26 structure_block[mode=corner]
setblock -66 69 -26 light[level=15]
setblock -62 70 -74 structure_block[mode=corner]
setblock -62 69 -74 light[level=15]
setblock -62 70 -70 structure_block[mode=corner]
setblock -62 69 -70 light[level=15]
setblock -62 70 -66 structure_block[mode=corner]
setblock -62 69 -66 light[level=15]
setblock -62 70 -58 structure_block[mode=corner]
setblock -62 69 -58 light[level=15]
setblock -62 70 -54 structure_block[mode=corner]
setblock -62 69 -54 light[level=15]
setblock -62 70 -50 structure_block[mode=corner]
setblock -62 69 -50 light[level=15]
setblock -62 70 -46 structure_block[mode=corner]
setblock -62 69 -46 light[level=15]
setblock -62 70 -42 structure_block[mode=corner]
setblock -62 69 -42 light[level=15]
setblock -62 70 -38 structure_block[mode=corner]
setblock -62 69 -38 light[level=15]
setblock -62 70 -34 structure_block[mode=corner]
setblock -62 69 -34 light[level=15]
setblock -62 70 -22 structure_block[mode=corner]
setblock -62 69 -22 light[level=15]
setblock -66 67 -21 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"NOTAUSGANG",color:"dark_green",bold:true},"→ Level 1",""]}}
setblock -66 70 -22 structure_block[mode=corner]
setblock -66 69 -22 light[level=15]
setblock -66 67 -39 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"NOTAUSGANG",color:"dark_green",bold:true},"→ Level 1",""]}}
setblock -78 67 -43 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"NOTAUSGANG",color:"dark_green",bold:true},"→ Level 1",""]}}
setblock -66 65 -22 end_gateway{exit_portal:[I;-38,65,-78],exact_teleport:1b,Age:1000L}
setblock -66 65 -38 end_gateway{exit_portal:[I;-118,65,-78],exact_teleport:1b,Age:1000L}
setblock -78 65 -42 end_gateway{exit_portal:[I;-118,65,-78],exact_teleport:1b,Age:1000L}
fill -41 63 -81 21 63 -19 reinforced_deepslate
fill -41 73 -81 21 73 -19 reinforced_deepslate
fill -41 63 -81 21 73 -81 reinforced_deepslate
fill -41 63 -19 21 73 -19 reinforced_deepslate
fill -41 63 -81 -41 73 -19 reinforced_deepslate
fill 21 63 -81 21 73 -19 reinforced_deepslate
fill -40 64 -80 20 64 -20 polished_andesite
fill -40 72 -80 20 72 -20 smooth_stone
fill -40 65 -80 20 71 -20 air
fill -41 65 -81 21 71 -81 light_gray_concrete
fill -41 65 -19 21 71 -19 light_gray_concrete
fill -41 65 -81 -41 71 -19 light_gray_concrete
fill 21 65 -81 21 71 -19 light_gray_concrete
fill -34 65 -74 -33 71 -73 smooth_stone
fill -34 65 -66 -33 71 -65 smooth_stone
fill -34 65 -58 -33 71 -57 smooth_stone
fill -34 65 -50 -33 71 -49 smooth_stone
fill -34 65 -42 -33 71 -41 smooth_stone
fill -34 65 -34 -33 71 -33 smooth_stone
fill -34 65 -26 -33 71 -25 smooth_stone
fill -26 65 -74 -25 71 -73 smooth_stone
fill -26 65 -66 -25 71 -65 smooth_stone
fill -26 65 -58 -25 71 -57 smooth_stone
fill -26 65 -50 -25 71 -49 smooth_stone
fill -26 65 -42 -25 71 -41 smooth_stone
fill -26 65 -34 -25 71 -33 smooth_stone
fill -26 65 -26 -25 71 -25 smooth_stone
fill -18 65 -74 -17 71 -73 smooth_stone
fill -18 65 -66 -17 71 -65 smooth_stone
fill -18 65 -58 -17 71 -57 smooth_stone
fill -18 65 -50 -17 71 -49 smooth_stone
fill -18 65 -42 -17 71 -41 smooth_stone
fill -18 65 -34 -17 71 -33 smooth_stone
fill -18 65 -26 -17 71 -25 smooth_stone
fill -10 65 -74 -9 71 -73 smooth_stone
fill -10 65 -66 -9 71 -65 smooth_stone
fill -10 65 -58 -9 71 -57 smooth_stone
fill -10 65 -50 -9 71 -49 smooth_stone
fill -10 65 -42 -9 71 -41 smooth_stone
fill -10 65 -34 -9 71 -33 smooth_stone
fill -10 65 -26 -9 71 -25 smooth_stone
fill -2 65 -74 -1 71 -73 smooth_stone
fill -2 65 -66 -1 71 -65 smooth_stone
fill -2 65 -58 -1 71 -57 smooth_stone
fill -2 65 -50 -1 71 -49 smooth_stone
fill -2 65 -42 -1 71 -41 smooth_stone
fill -2 65 -34 -1 71 -33 smooth_stone
fill -2 65 -26 -1 71 -25 smooth_stone
fill 6 65 -74 7 71 -73 smooth_stone
fill 6 65 -66 7 71 -65 smooth_stone
fill 6 65 -58 7 71 -57 smooth_stone
fill 6 65 -50 7 71 -49 smooth_stone
fill 6 65 -42 7 71 -41 smooth_stone
fill 6 65 -34 7 71 -33 smooth_stone
fill 6 65 -26 7 71 -25 smooth_stone
fill 14 65 -74 15 71 -73 smooth_stone
fill 14 65 -66 15 71 -65 smooth_stone
fill 14 65 -58 15 71 -57 smooth_stone
fill 14 65 -50 15 71 -49 smooth_stone
fill 14 65 -42 15 71 -41 smooth_stone
fill 14 65 -34 15 71 -33 smooth_stone
fill 14 65 -26 15 71 -25 smooth_stone
fill -6 65 -32 2 68 -32 light_gray_concrete
fill -19 65 -42 -9 68 -42 light_gray_concrete
fill 1 65 -57 7 68 -57 light_gray_concrete
fill 5 65 -45 11 68 -45 light_gray_concrete
fill -18 65 -58 -7 68 -58 light_gray_concrete
fill -6 65 -33 3 68 -33 light_gray_concrete
fill -11 65 -38 -2 68 -38 light_gray_concrete
fill 9 65 -49 9 68 -43 light_gray_concrete
fill -27 65 -65 -21 68 -65 light_gray_concrete
fill 3 65 -51 12 68 -51 light_gray_concrete
fill -3 65 -65 -3 67 -65 jigsaw[orientation=north_up]
fill -4 65 -59 -4 65 -59 jigsaw[orientation=north_up]
fill 9 65 -32 9 65 -31 jigsaw[orientation=north_up]
fill 1 65 -50 1 66 -50 jigsaw[orientation=north_up]
fill 0 65 -48 1 66 -47 jigsaw[orientation=north_up]
fill -2 65 -50 -1 66 -49 jigsaw[orientation=north_up]
fill -17 65 -73 -17 65 -72 jigsaw[orientation=north_up]
fill -34 65 -43 -34 67 -43 jigsaw[orientation=north_up]
fill 2 65 -36 3 67 -36 jigsaw[orientation=north_up]
fill -23 65 -32 -23 67 -31 jigsaw[orientation=north_up]
fill -13 65 -52 -12 65 -52 jigsaw[orientation=north_up]
fill -24 65 -70 -24 66 -69 jigsaw[orientation=north_up]
fill -24 65 -31 -24 67 -31 jigsaw[orientation=north_up]
fill -8 65 -64 -8 66 -63 jigsaw[orientation=north_up]
fill -2 65 -50 -2 65 -50 jigsaw[orientation=north_up]
fill 1 65 -70 2 66 -69 jigsaw[orientation=north_up]
fill -31 65 -56 -31 66 -55 jigsaw[orientation=north_up]
fill -32 65 -48 -32 65 -47 jigsaw[orientation=north_up]
fill -30 65 -53 -30 65 -52 jigsaw[orientation=north_up]
fill -31 65 -58 -31 67 -57 jigsaw[orientation=north_up]
fill -33 65 -61 -32 65 -60 jigsaw[orientation=north_up]
fill 4 65 -47 5 67 -46 jigsaw[orientation=north_up]
fill -15 65 -66 -14 65 -66 jigsaw[orientation=north_up]
fill -10 65 -31 -10 67 -31 jigsaw[orientation=north_up]
fill -18 65 -37 -17 67 -37 jigsaw[orientation=north_up]
fill 3 65 -48 4 67 -47 jigsaw[orientation=north_up]
fill 14 65 -66 14 65 -66 jigsaw[orientation=north_up]
fill -9 65 -68 -9 65 -67 jigsaw[orientation=north_up]
fill -25 65 -70 -25 67 -69 jigsaw[orientation=north_up]
fill -26 65 -55 -25 66 -54 jigsaw[orientation=north_up]
fill -20 65 -35 -20 65 -35 jigsaw[orientation=north_up]
fill -10 65 -62 -10 67 -62 jigsaw[orientation=north_up]
fill -34 65 -50 -33 65 -49 jigsaw[orientation=north_up]
fill 14 65 -38 14 67 -38 jigsaw[orientation=north_up]
fill -18 65 -30 -17 67 -30 jigsaw[orientation=north_up]
fill -19 65 -50 -19 66 -49 jigsaw[orientation=north_up]
fill -2 65 -39 -1 67 -39 jigsaw[orientation=north_up]
fill 0 65 -36 0 67 -35 jigsaw[orientation=north_up]
fill -1 65 -55 0 67 -55 jigsaw[orientation=north_up]
fill -30 65 -35 -29 65 -34 jigsaw[orientation=north_up]
setblock -34 64 -58 water
setblock 4 64 -52 water
setblock -32 64 -23 water
setblock -34 64 -37 water
setblock -34 64 -38 water
setblock 14 64 -27 water
setblock 10 64 -50 water
setblock -6 64 -39 water
setblock -37 64 -35 water
setblock 3 64 -33 water
setblock -10 64 -48 water
setblock -5 64 -46 water
