setblock -112 65 38 dark_oak_door[facing=south,half=lower]
setblock -112 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 303",color:"gold"},"",""]}}
fill -107 65 38 -107 66 38 air
setblock -107 66 38 dark_oak_door[facing=south,half=upper]
setblock -107 65 38 dark_oak_door[facing=south,half=lower]
setblock -107 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 305",color:"gold"},"",""]}}
setblock -106 65 41 chest[facing=north]{Items:[{Slot:6b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:22b,id:"minecraft:arrow",count:16}]}
fill -102 65 38 -102 66 38 air
setblock -102 66 38 dark_oak_door[facing=south,half=upper]
setblock -102 65 38 dark_oak_door[facing=south,half=lower]
setblock -102 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 307",color:"gold"},"",""]}}
setblock -103 67 40 end_rod[facing=up]
setblock -103 66 40 light[level=12]
fill -97 65 38 -97 66 38 air
setblock -97 66 38 dark_oak_door[facing=south,half=upper]
setblock -97 65 38 dark_oak_door[facing=south,half=lower]
setblock -97 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 309",color:"gold"},"",""]}}
setblock -98 67 40 end_rod[facing=up]
setblock -98 66 40 light[level=12]
fill -92 65 38 -92 66 38 air
setblock -92 66 38 dark_oak_door[facing=south,half=upper]
setblock -92 65 38 dark_oak_door[facing=south,half=lower]
setblock -92 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 311",color:"gold"},"",""]}}
setblock -93 67 40 end_rod[facing=up]
setblock -93 66 40 light[level=12]
fill -87 65 38 -87 66 38 air
setblock -87 66 38 dark_oak_door[facing=south,half=upper]
setblock -87 65 38 dark_oak_door[facing=south,half=lower]
setblock -87 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 313",color:"gold"},"",""]}}
setblock -88 67 40 end_rod[facing=up]
setblock -88 66 40 light[level=12]
fill -82 65 38 -82 66 38 air
setblock -82 66 38 dark_oak_door[facing=south,half=upper]
setblock -82 65 38 dark_oak_door[facing=south,half=lower]
setblock -82 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 315",color:"gold"},"",""]}}
fill -77 65 38 -77 66 38 air
setblock -77 66 38 dark_oak_door[facing=south,half=upper]
setblock -77 65 38 dark_oak_door[facing=south,half=lower]
setblock -77 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 317",color:"gold"},"",""]}}
fill -72 65 38 -72 66 38 air
setblock -72 66 38 dark_oak_door[facing=south,half=upper]
setblock -72 65 38 dark_oak_door[facing=south,half=lower]
setblock -72 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 319",color:"gold"},"",""]}}
setblock -73 67 40 end_rod[facing=up]
setblock -73 66 40 light[level=12]
fill -67 65 38 -67 66 38 air
setblock -67 66 38 dark_oak_door[facing=south,half=upper]
setblock -67 65 38 dark_oak_door[facing=south,half=lower]
setblock -67 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 321",color:"gold"},"",""]}}
setblock -68 67 40 end_rod[facing=up]
setblock -68 66 40 light[level=12]
fill -117 65 46 -117 66 46 air
setblock -117 66 46 dark_oak_door[facing=north,half=upper]
setblock -117 65 46 dark_oak_door[facing=north,half=lower]
setblock -117 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 302",color:"gold"},"",""]}}
setblock -118 67 44 end_rod[facing=up]
setblock -118 66 44 light[level=12]
fill -112 65 46 -112 66 46 air
setblock -112 66 46 dark_oak_door[facing=north,half=upper]
setblock -112 65 46 dark_oak_door[facing=north,half=lower]
setblock -112 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 304",color:"gold"},"",""]}}
setblock -113 67 44 end_rod[facing=up]
setblock -113 66 44 light[level=12]
fill -107 65 46 -107 66 46 air
setblock -107 66 46 dark_oak_door[facing=north,half=upper]
setblock -107 65 46 dark_oak_door[facing=north,half=lower]
setblock -107 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 306",color:"gold"},"",""]}}
setblock -106 65 43 chest[facing=south]{Items:[{Slot:6b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:22b,id:"minecraft:arrow",count:16}]}
fill -102 65 46 -102 66 46 air
setblock -102 66 46 dark_oak_door[facing=north,half=upper]
setblock -102 65 46 dark_oak_door[facing=north,half=lower]
setblock -102 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 308",color:"gold"},"",""]}}
setblock -101 65 43 chest[facing=south]{Items:[{Slot:9b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:23b,id:"minecraft:arrow",count:16}]}
fill -97 65 46 -97 66 46 air
setblock -97 66 46 dark_oak_door[facing=north,half=upper]
setblock -97 65 46 dark_oak_door[facing=north,half=lower]
setblock -97 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 310",color:"gold"},"",""]}}
fill -92 65 46 -92 66 46 air
setblock -92 66 46 dark_oak_door[facing=north,half=upper]
setblock -92 65 46 dark_oak_door[facing=north,half=lower]
setblock -92 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 312",color:"gold"},"",""]}}
setblock -93 67 44 end_rod[facing=up]
setblock -93 66 44 light[level=12]
fill -87 65 46 -87 66 46 air
setblock -87 66 46 dark_oak_door[facing=north,half=upper]
setblock -87 65 46 dark_oak_door[facing=north,half=lower]
setblock -87 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 314",color:"gold"},"",""]}}
setblock -86 65 43 chest[facing=south]{Items:[{Slot:11b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:21b,id:"minecraft:arrow",count:16}]}
fill -82 65 46 -82 66 46 air
setblock -82 66 46 dark_oak_door[facing=north,half=upper]
setblock -82 65 46 dark_oak_door[facing=north,half=lower]
setblock -82 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 316",color:"gold"},"",""]}}
setblock -83 67 44 end_rod[facing=up]
setblock -83 66 44 light[level=12]
fill -77 65 46 -77 66 46 air
setblock -77 66 46 dark_oak_door[facing=north,half=upper]
setblock -77 65 46 dark_oak_door[facing=north,half=lower]
setblock -77 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 318",color:"gold"},"",""]}}
setblock -76 65 43 chest[facing=south]{Items:[{Slot:8b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:14b,id:"minecraft:arrow",count:16}]}
fill -72 65 46 -72 66 46 air
setblock -72 66 46 dark_oak_door[facing=north,half=upper]
setblock -72 65 46 dark_oak_door[facing=north,half=lower]
setblock -72 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 320",color:"gold"},"",""]}}
fill -67 65 46 -67 66 46 air
setblock -67 66 46 dark_oak_door[facing=north,half=upper]
setblock -67 65 46 dark_oak_door[facing=north,half=lower]
setblock -67 67 47 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 322",color:"gold"},"",""]}}
fill -112 65 50 -112 66 50 air
setblock -112 66 50 dark_oak_door[facing=south,half=upper]
setblock -112 65 50 dark_oak_door[facing=south,half=lower]
setblock -112 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 403",color:"gold"},"",""]}}
setblock -113 67 52 end_rod[facing=up]
setblock -113 66 52 light[level=12]
fill -107 65 50 -107 66 50 air
setblock -107 66 50 dark_oak_door[facing=south,half=upper]
setblock -107 65 50 dark_oak_door[facing=south,half=lower]
setblock -107 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 405",color:"gold"},"",""]}}
fill -102 65 50 -102 66 50 air
setblock -102 66 50 dark_oak_door[facing=south,half=upper]
setblock -102 65 50 dark_oak_door[facing=south,half=lower]
setblock -102 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 407",color:"gold"},"",""]}}
setblock -101 65 53 chest[facing=north]{Items:[{Slot:5b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:25b,id:"minecraft:arrow",count:16}]}
fill -97 65 50 -97 66 50 air
setblock -97 66 50 dark_oak_door[facing=south,half=upper]
setblock -97 65 50 dark_oak_door[facing=south,half=lower]
setblock -97 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 409",color:"gold"},"",""]}}
setblock -96 65 53 chest[facing=north]{Items:[{Slot:7b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:26b,id:"minecraft:arrow",count:16}]}
fill -92 65 50 -92 66 50 air
setblock -92 66 50 dark_oak_door[facing=south,half=upper]
setblock -92 65 50 dark_oak_door[facing=south,half=lower]
setblock -92 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 411",color:"gold"},"",""]}}
setblock -91 65 53 chest[facing=north]{Items:[{Slot:10b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:20b,id:"minecraft:arrow",count:16}]}
fill -87 65 50 -87 66 50 air
setblock -87 66 50 dark_oak_door[facing=south,half=upper]
setblock -87 65 50 dark_oak_door[facing=south,half=lower]
setblock -87 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 413",color:"gold"},"",""]}}
setblock -88 67 52 end_rod[facing=up]
setblock -88 66 52 light[level=12]
fill -82 65 50 -82 66 50 air
setblock -82 66 50 dark_oak_door[facing=south,half=upper]
setblock -82 65 50 dark_oak_door[facing=south,half=lower]
setblock -82 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 415",color:"gold"},"",""]}}
setblock -81 65 53 chest[facing=north]{Items:[{Slot:4b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:21b,id:"minecraft:arrow",count:16}]}
fill -77 65 50 -77 66 50 air
setblock -77 66 50 dark_oak_door[facing=south,half=upper]
setblock -77 65 50 dark_oak_door[facing=south,half=lower]
setblock -77 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 417",color:"gold"},"",""]}}
setblock -78 67 52 end_rod[facing=up]
setblock -78 66 52 light[level=12]
fill -72 65 50 -72 66 50 air
setblock -72 66 50 dark_oak_door[facing=south,half=upper]
setblock -72 65 50 dark_oak_door[facing=south,half=lower]
setblock -72 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 419",color:"gold"},"",""]}}
setblock -73 67 52 end_rod[facing=up]
setblock -73 66 52 light[level=12]
fill -67 65 50 -67 66 50 air
setblock -67 66 50 dark_oak_door[facing=south,half=upper]
setblock -67 65 50 dark_oak_door[facing=south,half=lower]
setblock -67 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 421",color:"gold"},"",""]}}
setblock -68 67 52 end_rod[facing=up]
setblock -68 66 52 light[level=12]
fill -62 65 50 -62 66 50 air
setblock -62 66 50 dark_oak_door[facing=south,half=upper]
setblock -62 65 50 dark_oak_door[facing=south,half=lower]
setblock -62 67 49 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 423",color:"gold"},"",""]}}
setblock -61 65 53 chest[facing=north]{Items:[{Slot:6b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:25b,id:"minecraft:arrow",count:16}]}
fill -112 65 58 -112 66 58 air
setblock -112 66 58 dark_oak_door[facing=north,half=upper]
setblock -112 65 58 dark_oak_door[facing=north,half=lower]
setblock -112 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 404",color:"gold"},"",""]}}
setblock -111 65 55 chest[facing=south]{Items:[{Slot:8b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:22b,id:"minecraft:arrow",count:16}]}
fill -107 65 58 -107 66 58 air
setblock -107 66 58 dark_oak_door[facing=north,half=upper]
setblock -107 65 58 dark_oak_door[facing=north,half=lower]
setblock -107 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 406",color:"gold"},"",""]}}
setblock -108 67 56 end_rod[facing=up]
setblock -108 66 56 light[level=12]
fill -102 65 58 -102 66 58 air
setblock -102 66 58 dark_oak_door[facing=north,half=upper]
setblock -102 65 58 dark_oak_door[facing=north,half=lower]
setblock -102 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 408",color:"gold"},"",""]}}
setblock -103 67 56 end_rod[facing=up]
setblock -103 66 56 light[level=12]
fill -97 65 58 -97 66 58 air
setblock -97 66 58 dark_oak_door[facing=north,half=upper]
setblock -97 65 58 dark_oak_door[facing=north,half=lower]
setblock -97 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 410",color:"gold"},"",""]}}
setblock -98 67 56 end_rod[facing=up]
setblock -98 66 56 light[level=12]
fill -92 65 58 -92 66 58 air
setblock -92 66 58 dark_oak_door[facing=north,half=upper]
setblock -92 65 58 dark_oak_door[facing=north,half=lower]
setblock -92 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 412",color:"gold"},"",""]}}
setblock -93 67 56 end_rod[facing=up]
setblock -93 66 56 light[level=12]
fill -87 65 58 -87 66 58 air
setblock -87 66 58 dark_oak_door[facing=north,half=upper]
setblock -87 65 58 dark_oak_door[facing=north,half=lower]
setblock -87 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 414",color:"gold"},"",""]}}
fill -82 65 58 -82 66 58 air
setblock -82 66 58 dark_oak_door[facing=north,half=upper]
setblock -82 65 58 dark_oak_door[facing=north,half=lower]
setblock -82 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 416",color:"gold"},"",""]}}
fill -77 65 58 -77 66 58 air
setblock -77 66 58 dark_oak_door[facing=north,half=upper]
setblock -77 65 58 dark_oak_door[facing=north,half=lower]
setblock -77 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 418",color:"gold"},"",""]}}
fill -72 65 58 -72 66 58 air
setblock -72 66 58 dark_oak_door[facing=north,half=upper]
setblock -72 65 58 dark_oak_door[facing=north,half=lower]
setblock -72 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 420",color:"gold"},"",""]}}
setblock -73 67 56 end_rod[facing=up]
setblock -73 66 56 light[level=12]
fill -67 65 58 -67 66 58 air
setblock -67 66 58 dark_oak_door[facing=north,half=upper]
setblock -67 65 58 dark_oak_door[facing=north,half=lower]
setblock -67 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 422",color:"gold"},"",""]}}
setblock -68 67 56 end_rod[facing=up]
setblock -68 66 56 light[level=12]
fill -62 65 58 -62 66 58 air
setblock -62 66 58 dark_oak_door[facing=north,half=upper]
setblock -62 65 58 dark_oak_door[facing=north,half=lower]
setblock -62 67 59 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 424",color:"gold"},"",""]}}
setblock -61 65 55 chest[facing=south]{Items:[{Slot:10b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:26b,id:"minecraft:arrow",count:16}]}
fill -117 65 62 -117 66 62 air
setblock -117 66 62 dark_oak_door[facing=south,half=upper]
setblock -117 65 62 dark_oak_door[facing=south,half=lower]
setblock -117 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 501",color:"gold"},"",""]}}
fill -112 65 62 -112 66 62 air
setblock -112 66 62 dark_oak_door[facing=south,half=upper]
setblock -112 65 62 dark_oak_door[facing=south,half=lower]
setblock -112 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 503",color:"gold"},"",""]}}
setblock -113 67 65 end_rod[facing=up]
setblock -113 66 65 light[level=12]
fill -107 65 62 -107 66 62 air
setblock -107 66 62 dark_oak_door[facing=south,half=upper]
setblock -107 65 62 dark_oak_door[facing=south,half=lower]
setblock -107 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 505",color:"gold"},"",""]}}
setblock -108 67 65 end_rod[facing=up]
setblock -108 66 65 light[level=12]
fill -102 65 62 -102 66 62 air
setblock -102 66 62 dark_oak_door[facing=south,half=upper]
setblock -102 65 62 dark_oak_door[facing=south,half=lower]
setblock -102 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 507",color:"gold"},"",""]}}
fill -97 65 62 -97 66 62 air
setblock -97 66 62 dark_oak_door[facing=south,half=upper]
setblock -97 65 62 dark_oak_door[facing=south,half=lower]
setblock -97 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 509",color:"gold"},"",""]}}
fill -92 65 62 -92 66 62 air
setblock -92 66 62 dark_oak_door[facing=south,half=upper]
