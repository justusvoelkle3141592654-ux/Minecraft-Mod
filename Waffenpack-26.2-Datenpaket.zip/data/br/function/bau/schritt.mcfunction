scoreboard players add #bau br 1
execute if score #bau br matches 1 in br:backrooms run function br:bau/teil_0
execute if score #bau br matches 2 in br:backrooms run function br:bau/teil_1
execute if score #bau br matches 3 in br:backrooms run function br:bau/teil_2
execute if score #bau br matches 4 in br:backrooms run function br:bau/teil_3
execute if score #bau br matches 5 in br:backrooms run function br:bau/teil_4
execute if score #bau br matches 6 in br:backrooms run function br:bau/teil_5
execute if score #bau br matches 7 in br:backrooms run function br:bau/teil_6
execute if score #bau br matches 8 in br:backrooms run function br:bau/teil_7
execute if score #bau br matches 9 in br:backrooms run function br:bau/teil_8
execute if score #bau br matches 10 in br:backrooms run function br:bau/teil_9
execute if score #bau br matches 11 in br:backrooms run function br:bau/teil_10
execute if score #bau br matches 12 in br:backrooms run function br:bau/teil_11
execute if score #bau br matches 13 in br:backrooms run function br:bau/teil_12
execute if score #bau br matches 14 in br:backrooms run function br:bau/teil_13
execute if score #bau br matches 15 in br:backrooms run function br:bau/teil_14
execute if score #bau br matches 16 in br:backrooms run function br:bau/teil_15
execute if score #bau br matches ..15 run return run schedule function br:bau/schritt 1t
scoreboard players set #gebaut br 1
tellraw @a {"text":"Die Backrooms sind bereit. Klicke [START] oder tippe /trigger start.","color":"gold"}
