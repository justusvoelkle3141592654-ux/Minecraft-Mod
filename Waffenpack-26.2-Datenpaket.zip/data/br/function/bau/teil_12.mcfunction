fill -17 65 23 -18 66 23 light_gray_wool
fill -17 65 27 -18 66 27 light_gray_wool
setblock -19 69 31 structure_block[mode=corner]
setblock -19 68 31 light[level=15]
fill -20 65 29 -18 65 29 dark_oak_slab[type=top]
fill -21 65 29 -21 66 30 light_gray_wool
fill -17 65 29 -17 66 30 light_gray_wool
setblock -19 69 37 structure_block[mode=corner]
setblock -19 68 37 light[level=15]
fill -21 65 36 -21 65 38 dark_oak_slab[type=top]
fill -21 65 35 -20 66 35 light_gray_wool
fill -21 65 39 -20 66 39 light_gray_wool
fill -20 65 41 -18 65 41 dark_oak_slab[type=top]
fill -21 65 41 -21 66 42 light_gray_wool
fill -17 65 41 -17 66 42 light_gray_wool
setblock -19 69 49 structure_block[mode=corner]
setblock -19 68 49 light[level=15]
setblock -19 69 55 structure_block[mode=corner]
setblock -19 68 55 light[level=15]
fill -17 65 54 -17 65 56 dark_oak_slab[type=top]
fill -17 65 53 -18 66 53 light_gray_wool
fill -17 65 57 -18 66 57 light_gray_wool
setblock -19 69 61 structure_block[mode=corner]
setblock -19 68 61 light[level=15]
setblock -13 69 13 structure_block[mode=corner]
setblock -13 68 13 light[level=15]
fill -15 65 12 -15 65 14 dark_oak_slab[type=top]
fill -15 65 11 -14 66 11 light_gray_wool
fill -15 65 15 -14 66 15 light_gray_wool
setblock -13 69 19 structure_block[mode=corner]
setblock -13 68 19 light[level=15]
setblock -13 69 25 structure_block[mode=corner]
setblock -13 68 25 light[level=15]
fill -11 65 24 -11 65 26 dark_oak_slab[type=top]
fill -11 65 23 -12 66 23 light_gray_wool
fill -11 65 27 -12 66 27 light_gray_wool
setblock -13 69 31 structure_block[mode=corner]
setblock -13 68 31 light[level=15]
fill -14 65 29 -12 65 29 dark_oak_slab[type=top]
fill -15 65 29 -15 66 30 light_gray_wool
fill -11 65 29 -11 66 30 light_gray_wool
setblock -13 69 37 structure_block[mode=corner]
setblock -13 68 37 light[level=15]
setblock -13 69 43 structure_block[mode=corner]
setblock -13 68 43 light[level=15]
fill -11 65 42 -11 65 44 dark_oak_slab[type=top]
fill -11 65 41 -12 66 41 light_gray_wool
fill -11 65 45 -12 66 45 light_gray_wool
setblock -13 69 49 structure_block[mode=corner]
setblock -13 68 49 light[level=15]
fill -14 65 51 -12 65 51 dark_oak_slab[type=top]
fill -15 65 51 -15 66 50 light_gray_wool
fill -11 65 51 -11 66 50 light_gray_wool
setblock -13 69 55 structure_block[mode=corner]
setblock -13 68 55 light[level=15]
fill -15 65 54 -15 65 56 dark_oak_slab[type=top]
fill -15 65 53 -14 66 53 light_gray_wool
fill -15 65 57 -14 66 57 light_gray_wool
setblock -13 69 61 structure_block[mode=corner]
setblock -13 68 61 light[level=15]
fill -15 65 60 -15 65 62 dark_oak_slab[type=top]
fill -15 65 59 -14 66 59 light_gray_wool
fill -15 65 63 -14 66 63 light_gray_wool
setblock -13 69 67 structure_block[mode=corner]
setblock -13 68 67 light[level=15]
setblock -7 69 19 structure_block[mode=corner]
setblock -7 68 19 light[level=15]
setblock -7 69 31 structure_block[mode=corner]
setblock -7 68 31 light[level=15]
setblock -7 69 37 structure_block[mode=corner]
setblock -7 68 37 light[level=15]
fill -8 65 35 -6 65 35 dark_oak_slab[type=top]
fill -9 65 35 -9 66 36 light_gray_wool
fill -5 65 35 -5 66 36 light_gray_wool
setblock -7 69 43 structure_block[mode=corner]
setblock -7 68 43 light[level=15]
fill -8 65 45 -6 65 45 dark_oak_slab[type=top]
fill -9 65 45 -9 66 44 light_gray_wool
fill -5 65 45 -5 66 44 light_gray_wool
setblock -7 69 49 structure_block[mode=corner]
setblock -7 68 49 light[level=15]
fill -5 65 48 -5 65 50 dark_oak_slab[type=top]
fill -5 65 47 -6 66 47 light_gray_wool
fill -5 65 51 -6 66 51 light_gray_wool
fill -9 65 54 -9 65 56 dark_oak_slab[type=top]
fill -9 65 53 -8 66 53 light_gray_wool
fill -9 65 57 -8 66 57 light_gray_wool
fill -9 65 60 -9 65 62 dark_oak_slab[type=top]
fill -9 65 59 -8 66 59 light_gray_wool
fill -9 65 63 -8 66 63 light_gray_wool
setblock -7 69 67 structure_block[mode=corner]
setblock -7 68 67 light[level=15]
setblock -1 69 13 structure_block[mode=corner]
setblock -1 68 13 light[level=15]
fill -2 65 15 0 65 15 dark_oak_slab[type=top]
fill -3 65 15 -3 66 14 light_gray_wool
fill 1 65 15 1 66 14 light_gray_wool
setblock -1 69 19 structure_block[mode=corner]
setblock -1 68 19 light[level=15]
fill -3 65 18 -3 65 20 dark_oak_slab[type=top]
fill -3 65 17 -2 66 17 light_gray_wool
fill -3 65 21 -2 66 21 light_gray_wool
setblock -1 69 25 structure_block[mode=corner]
setblock -1 68 25 light[level=15]
fill -3 65 30 -3 65 32 dark_oak_slab[type=top]
fill -3 65 29 -2 66 29 light_gray_wool
fill -3 65 33 -2 66 33 light_gray_wool
setblock -1 69 37 structure_block[mode=corner]
setblock -1 68 37 light[level=15]
setblock -1 69 43 structure_block[mode=corner]
setblock -1 68 43 light[level=15]
fill -3 65 42 -3 65 44 dark_oak_slab[type=top]
fill -3 65 41 -2 66 41 light_gray_wool
fill -3 65 45 -2 66 45 light_gray_wool
fill -2 65 51 0 65 51 dark_oak_slab[type=top]
fill -3 65 51 -3 66 50 light_gray_wool
fill 1 65 51 1 66 50 light_gray_wool
setblock -1 69 55 structure_block[mode=corner]
setblock -1 68 55 light[level=15]
fill -3 65 54 -3 65 56 dark_oak_slab[type=top]
fill -3 65 53 -2 66 53 light_gray_wool
fill -3 65 57 -2 66 57 light_gray_wool
fill -2 65 63 0 65 63 dark_oak_slab[type=top]
fill -3 65 63 -3 66 62 light_gray_wool
fill 1 65 63 1 66 62 light_gray_wool
setblock -1 69 67 structure_block[mode=corner]
setblock -1 68 67 light[level=15]
fill -3 65 66 -3 65 68 dark_oak_slab[type=top]
fill -3 65 65 -2 66 65 light_gray_wool
fill -3 65 69 -2 66 69 light_gray_wool
fill 4 65 15 6 65 15 dark_oak_slab[type=top]
fill 3 65 15 3 66 14 light_gray_wool
fill 7 65 15 7 66 14 light_gray_wool
setblock 5 69 19 structure_block[mode=corner]
setblock 5 68 19 light[level=15]
fill 4 65 21 6 65 21 dark_oak_slab[type=top]
fill 3 65 21 3 66 20 light_gray_wool
fill 7 65 21 7 66 20 light_gray_wool
setblock 5 69 25 structure_block[mode=corner]
setblock 5 68 25 light[level=15]
fill 4 65 27 6 65 27 dark_oak_slab[type=top]
fill 3 65 27 3 66 26 light_gray_wool
fill 7 65 27 7 66 26 light_gray_wool
setblock 5 69 31 structure_block[mode=corner]
setblock 5 68 31 light[level=15]
fill 4 65 33 6 65 33 dark_oak_slab[type=top]
fill 3 65 33 3 66 32 light_gray_wool
fill 7 65 33 7 66 32 light_gray_wool
fill 7 65 36 7 65 38 dark_oak_slab[type=top]
fill 7 65 35 6 66 35 light_gray_wool
fill 7 65 39 6 66 39 light_gray_wool
setblock 5 69 43 structure_block[mode=corner]
setblock 5 68 43 light[level=15]
setblock 5 69 49 structure_block[mode=corner]
setblock 5 68 49 light[level=15]
fill 7 65 48 7 65 50 dark_oak_slab[type=top]
fill 7 65 47 6 66 47 light_gray_wool
fill 7 65 51 6 66 51 light_gray_wool
setblock 5 69 55 structure_block[mode=corner]
setblock 5 68 55 light[level=15]
fill 3 65 54 3 65 56 dark_oak_slab[type=top]
fill 3 65 53 4 66 53 light_gray_wool
fill 3 65 57 4 66 57 light_gray_wool
setblock 5 69 61 structure_block[mode=corner]
setblock 5 68 61 light[level=15]
fill 4 65 63 6 65 63 dark_oak_slab[type=top]
fill 3 65 63 3 66 62 light_gray_wool
fill 7 65 63 7 66 62 light_gray_wool
setblock 5 69 67 structure_block[mode=corner]
setblock 5 68 67 light[level=15]
fill 4 65 65 6 65 65 dark_oak_slab[type=top]
fill 3 65 65 3 66 66 light_gray_wool
fill 7 65 65 7 66 66 light_gray_wool
setblock 11 69 13 structure_block[mode=corner]
setblock 11 68 13 light[level=15]
fill 9 65 12 9 65 14 dark_oak_slab[type=top]
fill 9 65 11 10 66 11 light_gray_wool
fill 9 65 15 10 66 15 light_gray_wool
setblock 11 69 19 structure_block[mode=corner]
setblock 11 68 19 light[level=15]
fill 13 65 18 13 65 20 dark_oak_slab[type=top]
fill 13 65 17 12 66 17 light_gray_wool
fill 13 65 21 12 66 21 light_gray_wool
setblock 11 69 31 structure_block[mode=corner]
setblock 11 68 31 light[level=15]
setblock 11 69 37 structure_block[mode=corner]
setblock 11 68 37 light[level=15]
setblock 11 69 43 structure_block[mode=corner]
setblock 11 68 43 light[level=15]
fill 10 65 41 12 65 41 dark_oak_slab[type=top]
fill 9 65 41 9 66 42 light_gray_wool
fill 13 65 41 13 66 42 light_gray_wool
setblock 11 69 49 structure_block[mode=corner]
setblock 11 68 49 light[level=15]
setblock 11 69 55 structure_block[mode=corner]
setblock 11 68 55 light[level=15]
fill 9 65 54 9 65 56 dark_oak_slab[type=top]
fill 9 65 53 10 66 53 light_gray_wool
fill 9 65 57 10 66 57 light_gray_wool
setblock 11 69 61 structure_block[mode=corner]
setblock 11 68 61 light[level=15]
fill 10 65 59 12 65 59 dark_oak_slab[type=top]
fill 9 65 59 9 66 60 light_gray_wool
fill 13 65 59 13 66 60 light_gray_wool
setblock 11 69 67 structure_block[mode=corner]
setblock 11 68 67 light[level=15]
setblock 17 69 13 structure_block[mode=corner]
setblock 17 68 13 light[level=15]
setblock 17 69 25 structure_block[mode=corner]
setblock 17 68 25 light[level=15]
fill 16 65 27 18 65 27 dark_oak_slab[type=top]
fill 15 65 27 15 66 26 light_gray_wool
fill 19 65 27 19 66 26 light_gray_wool
fill 15 65 30 15 65 32 dark_oak_slab[type=top]
fill 15 65 29 16 66 29 light_gray_wool
fill 15 65 33 16 66 33 light_gray_wool
setblock 17 69 37 structure_block[mode=corner]
setblock 17 68 37 light[level=15]
fill 19 65 36 19 65 38 dark_oak_slab[type=top]
fill 19 65 35 18 66 35 light_gray_wool
fill 19 65 39 18 66 39 light_gray_wool
fill 16 65 41 18 65 41 dark_oak_slab[type=top]
fill 15 65 41 15 66 42 light_gray_wool
fill 19 65 41 19 66 42 light_gray_wool
setblock 17 69 49 structure_block[mode=corner]
setblock 17 68 49 light[level=15]
setblock 17 69 55 structure_block[mode=corner]
setblock 17 68 55 light[level=15]
fill 16 65 53 18 65 53 dark_oak_slab[type=top]
fill 15 65 53 15 66 54 light_gray_wool
fill 19 65 53 19 66 54 light_gray_wool
fill 15 65 60 15 65 62 dark_oak_slab[type=top]
fill 15 65 59 16 66 59 light_gray_wool
fill 15 65 63 16 66 63 light_gray_wool
setblock 11 66 65 lever[face=wall,facing=south,powered=false]
setblock 11 67 65 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"SICHERUNG",color:"dark_red",bold:true},"einschalten",""]}}
setblock 17 66 11 lever[face=wall,facing=south,powered=false]
setblock 17 67 11 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"SICHERUNG",color:"dark_red",bold:true},"einschalten",""]}}
setblock 15 66 49 lever[face=wall,facing=east,powered=false]
setblock 15 67 49 dark_oak_wall_sign[facing=east]{front_text:{messages:["",{text:"SICHERUNG",color:"dark_red",bold:true},"einschalten",""]}}
setblock 9 66 31 lever[face=wall,facing=east,powered=false]
setblock 9 67 31 dark_oak_wall_sign[facing=east]{front_text:{messages:["",{text:"SICHERUNG",color:"dark_red",bold:true},"einschalten",""]}}
setblock 17 67 69 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"AUFZUG",color:"dark_aqua",bold:true},"→ ???",{text:"4 Sicherungen nötig",color:"gray"}]}}
fill 17 65 67 17 66 67 iron_block
summon item_display -38.5 65.85 25.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -36.5 65.85 29.5 {Tags:["br_sys"],Rotation:[180f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -34.5 65.85 43.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -38.5 65.85 49.5 {Tags:["br_sys"],Rotation:[90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -36.5 65.85 57.5 {Tags:["br_sys"],Rotation:[0f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
summon item_display -34.5 65.85 61.5 {Tags:["br_sys"],Rotation:[-90f,0f],item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:monitor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.8f,0.8f,0.8f]},brightness:{sky:0,block:12}}
