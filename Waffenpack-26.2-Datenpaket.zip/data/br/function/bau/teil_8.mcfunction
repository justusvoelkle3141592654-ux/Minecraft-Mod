fill -84 65 63 -81 67 67 air
fill -79 65 63 -76 67 67 air
fill -74 65 63 -71 67 67 air
fill -69 65 63 -66 67 67 air
fill -64 65 63 -61 67 67 air
fill -120 65 10 -60 65 70 dark_oak_planks replace test_block[mode=start]
fill -117 65 14 -117 66 14 air
setblock -117 66 14 dark_oak_door[facing=south,half=upper]
setblock -117 65 14 dark_oak_door[facing=south,half=lower]
setblock -117 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 101",color:"gold"},"",""]}}
setblock -118 67 16 end_rod[facing=up]
setblock -118 66 16 light[level=12]
fill -112 65 14 -112 66 14 air
setblock -112 66 14 dark_oak_door[facing=south,half=upper]
setblock -112 65 14 dark_oak_door[facing=south,half=lower]
setblock -112 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 103",color:"gold"},"",""]}}
setblock -113 67 16 end_rod[facing=up]
setblock -113 66 16 light[level=12]
fill -107 65 14 -107 66 14 air
setblock -107 66 14 dark_oak_door[facing=south,half=upper]
setblock -107 65 14 dark_oak_door[facing=south,half=lower]
setblock -107 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 105",color:"gold"},"",""]}}
setblock -106 65 17 chest[facing=north]{Items:[{Slot:3b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:22b,id:"minecraft:arrow",count:16}]}
fill -102 65 14 -102 66 14 air
setblock -102 66 14 dark_oak_door[facing=south,half=upper]
setblock -102 65 14 dark_oak_door[facing=south,half=lower]
setblock -102 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 107",color:"gold"},"",""]}}
setblock -101 65 17 chest[facing=north]{Items:[{Slot:6b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:22b,id:"minecraft:arrow",count:16}]}
fill -97 65 14 -97 66 14 air
setblock -97 66 14 dark_oak_door[facing=south,half=upper]
setblock -97 65 14 dark_oak_door[facing=south,half=lower]
setblock -97 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 109",color:"gold"},"",""]}}
setblock -98 67 16 end_rod[facing=up]
setblock -98 66 16 light[level=12]
fill -92 65 14 -92 66 14 air
setblock -92 66 14 dark_oak_door[facing=south,half=upper]
setblock -92 65 14 dark_oak_door[facing=south,half=lower]
setblock -92 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 111",color:"gold"},"",""]}}
setblock -93 67 16 end_rod[facing=up]
setblock -93 66 16 light[level=12]
fill -87 65 14 -87 66 14 air
setblock -87 66 14 dark_oak_door[facing=south,half=upper]
setblock -87 65 14 dark_oak_door[facing=south,half=lower]
setblock -87 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 113",color:"gold"},"",""]}}
fill -82 65 14 -82 66 14 air
setblock -82 66 14 dark_oak_door[facing=south,half=upper]
setblock -82 65 14 dark_oak_door[facing=south,half=lower]
setblock -82 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 115",color:"gold"},"",""]}}
setblock -83 67 16 end_rod[facing=up]
setblock -83 66 16 light[level=12]
fill -77 65 14 -77 66 14 air
setblock -77 66 14 dark_oak_door[facing=south,half=upper]
setblock -77 65 14 dark_oak_door[facing=south,half=lower]
setblock -77 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 117",color:"gold"},"",""]}}
setblock -78 67 16 end_rod[facing=up]
setblock -78 66 16 light[level=12]
fill -72 65 14 -72 66 14 air
setblock -72 66 14 dark_oak_door[facing=south,half=upper]
setblock -72 65 14 dark_oak_door[facing=south,half=lower]
setblock -72 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 119",color:"gold"},"",""]}}
fill -67 65 14 -67 66 14 air
setblock -67 66 14 dark_oak_door[facing=south,half=upper]
setblock -67 65 14 dark_oak_door[facing=south,half=lower]
setblock -67 67 13 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 121",color:"gold"},"",""]}}
setblock -68 67 16 end_rod[facing=up]
setblock -68 66 16 light[level=12]
fill -117 65 22 -117 66 22 air
setblock -117 66 22 dark_oak_door[facing=north,half=upper]
setblock -117 65 22 dark_oak_door[facing=north,half=lower]
setblock -117 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 102",color:"gold"},"",""]}}
fill -112 65 22 -112 66 22 air
setblock -112 66 22 dark_oak_door[facing=north,half=upper]
setblock -112 65 22 dark_oak_door[facing=north,half=lower]
setblock -112 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 104",color:"gold"},"",""]}}
setblock -113 67 20 end_rod[facing=up]
setblock -113 66 20 light[level=12]
fill -107 65 22 -107 66 22 air
setblock -107 66 22 dark_oak_door[facing=north,half=upper]
setblock -107 65 22 dark_oak_door[facing=north,half=lower]
setblock -107 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 106",color:"gold"},"",""]}}
setblock -108 67 20 end_rod[facing=up]
setblock -108 66 20 light[level=12]
fill -102 65 22 -102 66 22 air
setblock -102 66 22 dark_oak_door[facing=north,half=upper]
setblock -102 65 22 dark_oak_door[facing=north,half=lower]
setblock -102 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 108",color:"gold"},"",""]}}
setblock -101 65 19 chest[facing=south]{Items:[{Slot:4b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:14b,id:"minecraft:arrow",count:16}]}
fill -97 65 22 -97 66 22 air
setblock -97 66 22 dark_oak_door[facing=north,half=upper]
setblock -97 65 22 dark_oak_door[facing=north,half=lower]
setblock -97 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 110",color:"gold"},"",""]}}
fill -92 65 22 -92 66 22 air
setblock -92 66 22 dark_oak_door[facing=north,half=upper]
setblock -92 65 22 dark_oak_door[facing=north,half=lower]
setblock -92 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 112",color:"gold"},"",""]}}
setblock -93 67 20 end_rod[facing=up]
setblock -93 66 20 light[level=12]
fill -87 65 22 -87 66 22 air
setblock -87 66 22 dark_oak_door[facing=north,half=upper]
setblock -87 65 22 dark_oak_door[facing=north,half=lower]
setblock -87 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 114",color:"gold"},"",""]}}
setblock -86 65 19 chest[facing=south]{Items:[{Slot:9b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:18b,id:"minecraft:arrow",count:16}]}
fill -82 65 22 -82 66 22 air
setblock -82 66 22 dark_oak_door[facing=north,half=upper]
setblock -82 65 22 dark_oak_door[facing=north,half=lower]
setblock -82 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 116",color:"gold"},"",""]}}
fill -77 65 22 -77 66 22 air
setblock -77 66 22 dark_oak_door[facing=north,half=upper]
setblock -77 65 22 dark_oak_door[facing=north,half=lower]
setblock -77 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 118",color:"gold"},"",""]}}
setblock -78 67 20 end_rod[facing=up]
setblock -78 66 20 light[level=12]
fill -72 65 22 -72 66 22 air
setblock -72 66 22 dark_oak_door[facing=north,half=upper]
setblock -72 65 22 dark_oak_door[facing=north,half=lower]
setblock -72 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 120",color:"gold"},"",""]}}
setblock -73 67 20 end_rod[facing=up]
setblock -73 66 20 light[level=12]
fill -67 65 22 -67 66 22 air
setblock -67 66 22 dark_oak_door[facing=north,half=upper]
setblock -67 65 22 dark_oak_door[facing=north,half=lower]
setblock -67 67 23 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 122",color:"gold"},"",""]}}
setblock -68 67 20 end_rod[facing=up]
setblock -68 66 20 light[level=12]
fill -112 65 26 -112 66 26 air
setblock -112 66 26 dark_oak_door[facing=south,half=upper]
setblock -112 65 26 dark_oak_door[facing=south,half=lower]
setblock -112 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 203",color:"gold"},"",""]}}
setblock -111 65 29 chest[facing=north]{Items:[{Slot:12b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:14b,id:"minecraft:arrow",count:16}]}
fill -107 65 26 -107 66 26 air
setblock -107 66 26 dark_oak_door[facing=south,half=upper]
setblock -107 65 26 dark_oak_door[facing=south,half=lower]
setblock -107 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 205",color:"gold"},"",""]}}
fill -102 65 26 -102 66 26 air
setblock -102 66 26 dark_oak_door[facing=south,half=upper]
setblock -102 65 26 dark_oak_door[facing=south,half=lower]
setblock -102 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 207",color:"gold"},"",""]}}
setblock -103 67 28 end_rod[facing=up]
setblock -103 66 28 light[level=12]
fill -97 65 26 -97 66 26 air
setblock -97 66 26 dark_oak_door[facing=south,half=upper]
setblock -97 65 26 dark_oak_door[facing=south,half=lower]
setblock -97 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 209",color:"gold"},"",""]}}
fill -92 65 26 -92 66 26 air
setblock -92 66 26 dark_oak_door[facing=south,half=upper]
setblock -92 65 26 dark_oak_door[facing=south,half=lower]
setblock -92 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 211",color:"gold"},"",""]}}
setblock -93 67 28 end_rod[facing=up]
setblock -93 66 28 light[level=12]
fill -87 65 26 -87 66 26 air
setblock -87 66 26 dark_oak_door[facing=south,half=upper]
setblock -87 65 26 dark_oak_door[facing=south,half=lower]
setblock -87 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 213",color:"gold"},"",""]}}
setblock -88 67 28 end_rod[facing=up]
setblock -88 66 28 light[level=12]
fill -82 65 26 -82 66 26 air
setblock -82 66 26 dark_oak_door[facing=south,half=upper]
setblock -82 65 26 dark_oak_door[facing=south,half=lower]
setblock -82 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 215",color:"gold"},"",""]}}
setblock -83 67 28 end_rod[facing=up]
setblock -83 66 28 light[level=12]
fill -77 65 26 -77 66 26 air
setblock -77 66 26 dark_oak_door[facing=south,half=upper]
setblock -77 65 26 dark_oak_door[facing=south,half=lower]
setblock -77 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 217",color:"gold"},"",""]}}
setblock -78 67 28 end_rod[facing=up]
setblock -78 66 28 light[level=12]
fill -72 65 26 -72 66 26 air
setblock -72 66 26 dark_oak_door[facing=south,half=upper]
setblock -72 65 26 dark_oak_door[facing=south,half=lower]
setblock -72 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 219",color:"gold"},"",""]}}
setblock -73 67 28 end_rod[facing=up]
setblock -73 66 28 light[level=12]
fill -67 65 26 -67 66 26 air
setblock -67 66 26 dark_oak_door[facing=south,half=upper]
setblock -67 65 26 dark_oak_door[facing=south,half=lower]
setblock -67 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 221",color:"gold"},"",""]}}
setblock -68 67 28 end_rod[facing=up]
setblock -68 66 28 light[level=12]
fill -62 65 26 -62 66 26 air
setblock -62 66 26 dark_oak_door[facing=south,half=upper]
setblock -62 65 26 dark_oak_door[facing=south,half=lower]
setblock -62 67 25 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 223",color:"gold"},"",""]}}
setblock -61 65 29 chest[facing=north]{Items:[{Slot:7b,id:"minecraft:enchanted_golden_apple",count:2},{Slot:14b,id:"minecraft:arrow",count:16}]}
fill -112 65 34 -112 66 34 air
setblock -112 66 34 dark_oak_door[facing=north,half=upper]
setblock -112 65 34 dark_oak_door[facing=north,half=lower]
setblock -112 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 204",color:"gold"},"",""]}}
setblock -113 67 32 end_rod[facing=up]
setblock -113 66 32 light[level=12]
fill -107 65 34 -107 66 34 air
setblock -107 66 34 dark_oak_door[facing=north,half=upper]
setblock -107 65 34 dark_oak_door[facing=north,half=lower]
setblock -107 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 206",color:"gold"},"",""]}}
setblock -108 67 32 end_rod[facing=up]
setblock -108 66 32 light[level=12]
fill -102 65 34 -102 66 34 air
setblock -102 66 34 dark_oak_door[facing=north,half=upper]
setblock -102 65 34 dark_oak_door[facing=north,half=lower]
setblock -102 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 208",color:"gold"},"",""]}}
setblock -103 67 32 end_rod[facing=up]
setblock -103 66 32 light[level=12]
fill -97 65 34 -97 66 34 air
setblock -97 66 34 dark_oak_door[facing=north,half=upper]
setblock -97 65 34 dark_oak_door[facing=north,half=lower]
setblock -97 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 210",color:"gold"},"",""]}}
setblock -98 67 32 end_rod[facing=up]
setblock -98 66 32 light[level=12]
fill -92 65 34 -92 66 34 air
setblock -92 66 34 dark_oak_door[facing=north,half=upper]
setblock -92 65 34 dark_oak_door[facing=north,half=lower]
setblock -92 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 212",color:"gold"},"",""]}}
fill -87 65 34 -87 66 34 air
setblock -87 66 34 dark_oak_door[facing=north,half=upper]
setblock -87 65 34 dark_oak_door[facing=north,half=lower]
setblock -87 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 214",color:"gold"},"",""]}}
fill -82 65 34 -82 66 34 air
setblock -82 66 34 dark_oak_door[facing=north,half=upper]
setblock -82 65 34 dark_oak_door[facing=north,half=lower]
setblock -82 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 216",color:"gold"},"",""]}}
setblock -83 67 32 end_rod[facing=up]
setblock -83 66 32 light[level=12]
fill -77 65 34 -77 66 34 air
setblock -77 66 34 dark_oak_door[facing=north,half=upper]
setblock -77 65 34 dark_oak_door[facing=north,half=lower]
setblock -77 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 218",color:"gold"},"",""]}}
setblock -78 67 32 end_rod[facing=up]
setblock -78 66 32 light[level=12]
fill -72 65 34 -72 66 34 air
setblock -72 66 34 dark_oak_door[facing=north,half=upper]
setblock -72 65 34 dark_oak_door[facing=north,half=lower]
setblock -72 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 220",color:"gold"},"",""]}}
setblock -73 67 32 end_rod[facing=up]
setblock -73 66 32 light[level=12]
fill -67 65 34 -67 66 34 air
setblock -67 66 34 dark_oak_door[facing=north,half=upper]
setblock -67 65 34 dark_oak_door[facing=north,half=lower]
setblock -67 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 222",color:"gold"},"",""]}}
setblock -68 67 32 end_rod[facing=up]
setblock -68 66 32 light[level=12]
fill -62 65 34 -62 66 34 air
setblock -62 66 34 dark_oak_door[facing=north,half=upper]
setblock -62 65 34 dark_oak_door[facing=north,half=lower]
setblock -62 67 35 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"Zimmer 224",color:"gold"},"",""]}}
fill -117 65 38 -117 66 38 air
setblock -117 66 38 dark_oak_door[facing=south,half=upper]
setblock -117 65 38 dark_oak_door[facing=south,half=lower]
setblock -117 67 37 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 301",color:"gold"},"",""]}}
fill -112 65 38 -112 66 38 air
setblock -112 66 38 dark_oak_door[facing=south,half=upper]
