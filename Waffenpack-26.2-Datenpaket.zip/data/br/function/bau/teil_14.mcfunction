setblock 75 69 29 sculk
setblock 71 71 38 sculk
setblock 63 73 10 sculk
setblock 66 70 12 sculk
setblock 48 76 12 sculk
setblock 45 67 40 sculk
setblock 72 70 36 sculk
setblock 43 67 38 sculk
setblock 69 67 14 sculk
setblock 55 66 45 sculk
setblock 73 65 34 sculk
setblock 50 70 43 sculk
setblock 49 65 43 sculk
setblock 63 71 44 sculk
setblock 74 76 24 sculk
setblock 70 65 39 sculk
setblock 72 76 18 sculk
setblock 54 69 44 sculk
setblock 47 67 42 sculk
setblock 57 72 9 sculk
setblock 59 71 10 sculk
setblock 39 69 29 sculk
setblock 48 74 12 sculk
setblock 40 69 23 sculk
setblock 41 67 19 sculk
setblock 71 68 17 sculk
setblock 63 65 10 sculk
setblock 57 73 9 sculk
setblock 74 75 33 sculk
setblock 49 69 43 sculk
setblock 57 69 45 sculk
setblock 55 66 44 sculk
setblock 73 69 34 sculk
setblock 75 69 26 sculk
setblock 67 73 42 sculk
setblock 40 76 22 sculk
setblock 75 75 28 sculk
setblock 74 70 22 sculk
setblock 73 71 19 sculk
setblock 43 75 17 sculk
setblock 40 75 32 sculk
setblock 60 68 44 sculk
setblock 73 74 34 sculk
setblock 45 67 40 sculk
setblock 39 76 28 sculk
setblock 72 74 36 sculk
setblock 41 72 20 sculk
setblock 63 77 20 sculk
setblock 68 77 26 sculk
setblock 53 77 22 sculk
setblock 69 77 34 sculk
setblock 67 77 20 sculk
setblock 53 77 15 sculk
setblock 72 77 23 sculk
setblock 57 77 27 sculk
setblock 65 77 25 sculk
setblock 51 77 29 sculk
setblock 57 77 27 sculk
setblock 50 77 21 sculk
setblock 69 77 34 sculk
setblock 68 77 20 sculk
setblock 52 77 26 sculk
setblock 52 77 28 sculk
setblock 71 77 23 sculk
setblock 63 77 23 sculk
setblock 47 77 27 sculk
setblock 57 77 29 sculk
setblock 61 77 27 sculk
setblock 57 77 34 sculk
setblock 64 77 31 sculk
setblock 64 77 38 sculk
setblock 68 77 33 sculk
setblock 56 77 39 sculk
setblock 61 77 13 sculk
setblock 64 77 41 sculk
setblock 60 77 31 sculk
setblock 64 77 27 sculk
setblock 64 77 31 sculk
setblock 68 77 22 sculk
setblock 57 77 26 sculk
setblock 62 77 27 sculk
setblock 59 77 27 sculk
setblock 53 77 41 sculk
setblock 57 77 25 sculk
setblock 49 77 29 sculk
setblock 57 77 30 sculk
setblock 64 77 31 sculk
setblock 53 77 29 sculk
setblock 52 77 27 sculk
setblock 48 77 35 sculk
setblock 57 77 28 sculk
setblock 53 77 28 sculk
setblock 44 77 29 sculk
setblock 69 77 23 sculk
setblock 60 77 26 sculk
setblock 56 77 28 sculk
setblock 56 77 31 sculk
setblock 57 77 32 sculk
setblock 64 77 24 sculk
setblock 63 77 23 sculk
setblock 57 77 17 sculk
setblock 45 77 19 sculk
setblock 51 77 23 sculk
setblock 57 77 28 sculk
setblock 52 77 29 sculk
setblock 67 77 38 sculk
setblock 64 77 27 sculk
setblock 57 77 33 sculk
setblock 64 77 14 sculk
setblock 48 77 33 sculk
setblock 60 77 25 sculk
setblock 52 77 31 sculk
setblock 59 77 23 sculk
setblock 59 77 26 sculk
setblock 53 77 18 sculk
setblock 62 77 28 sculk
setblock 60 77 22 sculk
setblock 64 77 29 sculk
setblock 50 77 26 sculk
setblock 44 77 34 sculk
setblock 54 77 21 sculk
setblock 46 77 31 sculk
setblock 57 77 34 sculk
setblock 57 77 26 sculk
setblock 57 77 27 sculk
setblock 51 77 16 sculk
setblock 52 77 19 sculk
setblock 64 64 28 sculk_catalyst
setblock 64 65 28 light[level=8]
setblock 50 64 28 sculk_catalyst
setblock 50 65 28 light[level=8]
setblock 57 64 35 sculk_catalyst
setblock 57 65 35 light[level=8]
setblock 57 64 31 sculk_catalyst
setblock 57 65 31 light[level=8]
setblock 54 64 26 sculk_catalyst
setblock 54 65 26 light[level=8]
setblock 50 64 30 sculk_catalyst
setblock 50 65 30 light[level=8]
setblock 61 64 17 sculk_catalyst
setblock 61 65 17 light[level=8]
setblock 54 64 28 sculk_catalyst
setblock 54 65 28 light[level=8]
setblock 55 64 16 sculk_catalyst
setblock 55 65 16 light[level=8]
setblock 48 64 16 sculk_catalyst
setblock 48 65 16 light[level=8]
setblock 49 64 27 sculk_catalyst
setblock 49 65 27 light[level=8]
setblock 52 64 26 sculk_catalyst
setblock 52 65 26 light[level=8]
setblock 53 65 23 sculk_shrieker[can_summon=false]
setblock 52 65 18 sculk_shrieker[can_summon=false]
setblock 55 65 21 sculk_shrieker[can_summon=false]
setblock 54 65 14 sculk_shrieker[can_summon=false]
setblock 68 65 26 sculk_shrieker[can_summon=false]
setblock 63 65 36 sculk_shrieker[can_summon=false]
setblock 63 65 39 sculk_shrieker[can_summon=false]
setblock 62 65 28 sculk_shrieker[can_summon=false]
setblock 44 65 36 soul_lantern
setblock 71 65 35 soul_lantern
setblock 72 65 22 soul_lantern
setblock 71 65 20 soul_lantern
setblock 56 65 43 soul_lantern
setblock 68 65 15 soul_lantern
setblock 48 65 40 soul_lantern
setblock 64 65 12 soul_lantern
setblock 68 65 38 soul_lantern
setblock 72 65 21 soul_lantern
setblock 42 65 32 soul_lantern
setblock 58 65 43 soul_lantern
setblock 42 65 32 soul_lantern
setblock 73 65 27 soul_lantern
setblock 55 64 25 sculk_catalyst
setblock 55 64 26 sculk_catalyst
setblock 55 64 27 sculk_catalyst
setblock 55 64 28 sculk_catalyst
setblock 55 64 29 sculk_catalyst
setblock 56 64 25 sculk_catalyst
setblock 56 64 29 sculk_catalyst
setblock 57 64 25 sculk_catalyst
setblock 57 64 29 sculk_catalyst
setblock 58 64 25 sculk_catalyst
setblock 58 64 29 sculk_catalyst
setblock 59 64 25 sculk_catalyst
setblock 59 64 26 sculk_catalyst
setblock 59 64 27 sculk_catalyst
setblock 59 64 28 sculk_catalyst
setblock 59 64 29 sculk_catalyst
summon marker -93.5 65 -37.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -69.5 65 -73.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -109.5 65 -29.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -101.5 65 -41.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -93.5 65 -53.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -97.5 65 -77.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -81.5 65 -73.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -97.5 65 -41.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -105.5 65 -49.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -85.5 65 -45.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -65.5 65 -21.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker -101.5 65 -69.5 {Tags:["br_sys","br_sp","br_sp0"]}
summon marker 10.5 65 -45.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker 10.5 65 -29.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker -21.5 65 -61.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker -5.5 65 -61.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker 10.5 65 -61.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker -21.5 65 -53.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker -21.5 65 -69.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker 2.5 65 -61.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker -29.5 65 -45.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker 2.5 65 -37.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker -13.5 65 -53.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker -29.5 65 -53.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker -29.5 65 -61.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker -13.5 65 -45.5 {Tags:["br_sys","br_sp","br_sp1"]}
summon marker 77.5 65 -66.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 56.5 65 -66.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 80.5 65 -33.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 56.5 65 -33.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 80.5 65 -66.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 44.5 65 -60.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 53.5 65 -54.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 77.5 65 -45.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 89.5 65 -42.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 50.5 65 -51.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 89.5 65 -75.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker 50.5 65 -45.5 {Tags:["br_sys","br_sp","br_sp2"]}
summon marker -93.5 65 48.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -111.5 65 36.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -66.5 65 12.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -66.5 65 48.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -75.5 65 24.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -102.5 65 48.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -84.5 65 60.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -93.5 65 36.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -66.5 65 60.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -93.5 65 24.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -66.5 65 36.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -102.5 65 60.5 {Tags:["br_sys","br_sp","br_sp3"]}
summon marker -18.5 65 31.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker -0.5 65 43.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker -6.5 65 67.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker -30.5 65 55.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker -18.5 65 25.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker -18.5 65 43.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker -36.5 65 61.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker 5.5 65 67.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker -12.5 65 43.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker -36.5 65 43.5 {Tags:["br_sys","br_sp","br_sp4"]}
summon marker 11.5 65 61.5 {Tags:["br_sys","br_sp","br_sp4"]}
