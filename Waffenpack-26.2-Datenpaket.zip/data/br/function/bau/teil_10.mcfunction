setblock -92 65 62 dark_oak_door[facing=south,half=lower]
setblock -92 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 511",color:"gold"},"",""]}}
setblock -93 67 65 end_rod[facing=up]
setblock -93 66 65 light[level=12]
fill -87 65 62 -87 66 62 air
setblock -87 66 62 dark_oak_door[facing=south,half=upper]
setblock -87 65 62 dark_oak_door[facing=south,half=lower]
setblock -87 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 513",color:"gold"},"",""]}}
setblock -88 67 65 end_rod[facing=up]
setblock -88 66 65 light[level=12]
fill -82 65 62 -82 66 62 air
setblock -82 66 62 dark_oak_door[facing=south,half=upper]
setblock -82 65 62 dark_oak_door[facing=south,half=lower]
setblock -82 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 515",color:"gold"},"",""]}}
fill -77 65 62 -77 66 62 air
setblock -77 66 62 dark_oak_door[facing=south,half=upper]
setblock -77 65 62 dark_oak_door[facing=south,half=lower]
setblock -77 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 517",color:"gold"},"",""]}}
fill -72 65 62 -72 66 62 air
setblock -72 66 62 dark_oak_door[facing=south,half=upper]
setblock -72 65 62 dark_oak_door[facing=south,half=lower]
setblock -72 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 519",color:"gold"},"",""]}}
fill -67 65 62 -67 66 62 air
setblock -67 66 62 dark_oak_door[facing=south,half=upper]
setblock -67 65 62 dark_oak_door[facing=south,half=lower]
setblock -67 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 521",color:"gold"},"",""]}}
setblock -68 67 65 end_rod[facing=up]
setblock -68 66 65 light[level=12]
fill -62 65 62 -62 66 62 air
setblock -88 66 31 dark_oak_wall_sign[facing=south]{front_text:{messages:["",{text:"HAUPTSCHALTER",color:"dark_red"},"öffnet Zimmer 237",""]}}
setblock -87 67 32 end_rod[facing=up]
setblock -86 66 32 light[level=13]
setblock -87 66 31 lever[face=wall,facing=south,powered=false]
setblock -62 67 61 dark_oak_wall_sign[facing=north]{front_text:{messages:["",{text:"Zimmer 237",color:"red",bold:true},"AUSGANG",{text:"verschlossen",color:"gray"}]}}
setblock -62 66 62 iron_door[facing=south,half=upper,open=false]
setblock -62 65 62 iron_door[facing=south,half=lower,open=false]
setblock -61 67 66 end_rod[facing=up]
setblock -63 66 66 light[level=12]
setblock -117 67 11 wall_torch[facing=south]
setblock -111 67 11 wall_torch[facing=south]
setblock -105 67 11 wall_torch[facing=south]
setblock -99 67 11 wall_torch[facing=south]
setblock -93 67 11 wall_torch[facing=south]
setblock -87 67 11 wall_torch[facing=south]
setblock -81 67 11 wall_torch[facing=south]
setblock -75 67 11 wall_torch[facing=south]
setblock -69 67 11 wall_torch[facing=south]
setblock -63 67 11 wall_torch[facing=south]
setblock -117 67 23 wall_torch[facing=south]
setblock -111 67 23 wall_torch[facing=south]
setblock -105 67 23 wall_torch[facing=south]
setblock -99 67 23 wall_torch[facing=south]
setblock -93 67 23 wall_torch[facing=south]
setblock -87 67 23 wall_torch[facing=south]
setblock -81 67 23 wall_torch[facing=south]
setblock -75 67 23 wall_torch[facing=south]
setblock -69 67 23 wall_torch[facing=south]
setblock -63 67 23 wall_torch[facing=south]
setblock -117 67 35 wall_torch[facing=south]
setblock -111 67 35 wall_torch[facing=south]
setblock -105 67 35 wall_torch[facing=south]
setblock -99 67 35 wall_torch[facing=south]
setblock -93 67 35 wall_torch[facing=south]
setblock -87 67 35 wall_torch[facing=south]
setblock -81 67 35 wall_torch[facing=south]
setblock -75 67 35 wall_torch[facing=south]
setblock -69 67 35 wall_torch[facing=south]
setblock -63 67 35 wall_torch[facing=south]
setblock -117 67 47 wall_torch[facing=south]
setblock -111 67 47 wall_torch[facing=south]
setblock -105 67 47 wall_torch[facing=south]
setblock -99 67 47 wall_torch[facing=south]
setblock -93 67 47 wall_torch[facing=south]
setblock -87 67 47 wall_torch[facing=south]
setblock -81 67 47 wall_torch[facing=south]
setblock -75 67 47 wall_torch[facing=south]
setblock -69 67 47 wall_torch[facing=south]
setblock -63 67 47 wall_torch[facing=south]
setblock -117 67 59 wall_torch[facing=south]
setblock -111 67 59 wall_torch[facing=south]
setblock -105 67 59 wall_torch[facing=south]
setblock -99 67 59 wall_torch[facing=south]
setblock -93 67 59 wall_torch[facing=south]
setblock -87 67 59 wall_torch[facing=south]
setblock -81 67 59 wall_torch[facing=south]
setblock -75 67 59 wall_torch[facing=south]
setblock -69 67 59 wall_torch[facing=south]
setblock -63 67 59 wall_torch[facing=south]
setblock -114 68 12 structure_block[mode=corner]
setblock -114 67 12 light[level=15]
setblock -102 68 12 structure_block[mode=corner]
setblock -102 67 12 light[level=15]
setblock -90 68 12 structure_block[mode=corner]
setblock -90 67 12 light[level=15]
setblock -78 68 12 structure_block[mode=corner]
setblock -78 67 12 light[level=15]
setblock -66 68 12 structure_block[mode=corner]
setblock -66 67 12 light[level=15]
setblock -114 68 24 structure_block[mode=corner]
setblock -114 67 24 light[level=15]
setblock -102 68 24 structure_block[mode=corner]
setblock -102 67 24 light[level=15]
setblock -90 68 24 structure_block[mode=corner]
setblock -90 67 24 light[level=15]
setblock -78 68 24 structure_block[mode=corner]
setblock -78 67 24 light[level=15]
setblock -66 68 24 structure_block[mode=corner]
setblock -66 67 24 light[level=15]
setblock -114 68 36 structure_block[mode=corner]
setblock -114 67 36 light[level=15]
setblock -102 68 36 structure_block[mode=corner]
setblock -102 67 36 light[level=15]
setblock -90 68 36 structure_block[mode=corner]
setblock -90 67 36 light[level=15]
setblock -78 68 36 structure_block[mode=corner]
setblock -78 67 36 light[level=15]
setblock -66 68 36 structure_block[mode=corner]
setblock -66 67 36 light[level=15]
setblock -114 68 48 structure_block[mode=corner]
setblock -114 67 48 light[level=15]
setblock -102 68 48 structure_block[mode=corner]
setblock -102 67 48 light[level=15]
setblock -90 68 48 structure_block[mode=corner]
setblock -90 67 48 light[level=15]
setblock -78 68 48 structure_block[mode=corner]
setblock -78 67 48 light[level=15]
setblock -66 68 48 structure_block[mode=corner]
setblock -66 67 48 light[level=15]
setblock -114 68 60 structure_block[mode=corner]
setblock -114 67 60 light[level=15]
setblock -102 68 60 structure_block[mode=corner]
setblock -102 67 60 light[level=15]
setblock -90 68 60 structure_block[mode=corner]
setblock -90 67 60 light[level=15]
setblock -78 68 60 structure_block[mode=corner]
setblock -78 67 60 light[level=15]
setblock -66 68 60 structure_block[mode=corner]
setblock -66 67 60 light[level=15]
setblock -62 65 66 end_gateway{exit_portal:[I;-37,65,13],exact_teleport:1b,Age:1000L}
fill -41 63 9 21 63 71 reinforced_deepslate
fill -41 70 9 21 70 71 reinforced_deepslate
fill -41 63 9 21 70 9 reinforced_deepslate
fill -41 63 71 21 70 71 reinforced_deepslate
fill -41 63 9 -41 70 71 reinforced_deepslate
fill 21 63 9 21 70 71 reinforced_deepslate
fill -40 64 10 20 64 70 test_block[mode=accept]
fill -40 69 10 20 69 70 structure_block[mode=load]
fill -40 65 10 20 68 70 test_block[mode=fail]
fill -39 65 11 -35 68 15 air
fill -39 65 17 -35 68 21 air
fill -39 65 23 -35 68 27 air
fill -39 65 29 -35 68 33 air
fill -39 65 35 -35 68 39 air
fill -39 65 41 -35 68 45 air
fill -39 65 47 -35 68 51 air
fill -39 65 53 -35 68 57 air
fill -39 65 59 -35 68 63 air
fill -39 65 65 -35 68 69 air
fill -33 65 11 -29 68 15 air
fill -33 65 17 -29 68 21 air
fill -33 65 23 -29 68 27 air
fill -33 65 29 -29 68 33 air
fill -33 65 35 -29 68 39 air
fill -33 65 41 -29 68 45 air
fill -33 65 47 -29 68 51 air
fill -33 65 53 -29 68 57 air
fill -33 65 59 -29 68 63 air
fill -33 65 65 -29 68 69 air
fill -27 65 11 -23 68 15 air
fill -27 65 17 -23 68 21 air
fill -27 65 23 -23 68 27 air
fill -27 65 29 -23 68 33 air
fill -27 65 35 -23 68 39 air
fill -27 65 41 -23 68 45 air
fill -27 65 47 -23 68 51 air
fill -27 65 53 -23 68 57 air
fill -27 65 59 -23 68 63 air
fill -27 65 65 -23 68 69 air
fill -21 65 11 -17 68 15 air
fill -21 65 17 -17 68 21 air
fill -21 65 23 -17 68 27 air
fill -21 65 29 -17 68 33 air
fill -21 65 35 -17 68 39 air
fill -21 65 41 -17 68 45 air
fill -21 65 47 -17 68 51 air
fill -21 65 53 -17 68 57 air
fill -21 65 59 -17 68 63 air
fill -21 65 65 -17 68 69 air
fill -15 65 11 -11 68 15 air
fill -15 65 17 -11 68 21 air
fill -15 65 23 -11 68 27 air
fill -15 65 29 -11 68 33 air
fill -15 65 35 -11 68 39 air
fill -15 65 41 -11 68 45 air
fill -15 65 47 -11 68 51 air
fill -15 65 53 -11 68 57 air
fill -15 65 59 -11 68 63 air
fill -15 65 65 -11 68 69 air
fill -9 65 11 -5 68 15 air
fill -9 65 17 -5 68 21 air
fill -9 65 23 -5 68 27 air
fill -9 65 29 -5 68 33 air
fill -9 65 35 -5 68 39 air
fill -9 65 41 -5 68 45 air
fill -9 65 47 -5 68 51 air
fill -9 65 53 -5 68 57 air
fill -9 65 59 -5 68 63 air
fill -9 65 65 -5 68 69 air
fill -3 65 11 1 68 15 air
fill -3 65 17 1 68 21 air
fill -3 65 23 1 68 27 air
fill -3 65 29 1 68 33 air
fill -3 65 35 1 68 39 air
fill -3 65 41 1 68 45 air
fill -3 65 47 1 68 51 air
fill -3 65 53 1 68 57 air
fill -3 65 59 1 68 63 air
fill -3 65 65 1 68 69 air
fill 3 65 11 7 68 15 air
fill 3 65 17 7 68 21 air
fill 3 65 23 7 68 27 air
fill 3 65 29 7 68 33 air
fill 3 65 35 7 68 39 air
fill 3 65 41 7 68 45 air
fill 3 65 47 7 68 51 air
fill 3 65 53 7 68 57 air
fill 3 65 59 7 68 63 air
fill 3 65 65 7 68 69 air
fill 9 65 11 13 68 15 air
fill 9 65 17 13 68 21 air
fill 9 65 23 13 68 27 air
fill 9 65 29 13 68 33 air
fill 9 65 35 13 68 39 air
fill 9 65 41 13 68 45 air
fill 9 65 47 13 68 51 air
fill 9 65 53 13 68 57 air
fill 9 65 59 13 68 63 air
fill 9 65 65 13 68 69 air
fill 15 65 11 19 68 15 air
fill 15 65 17 19 68 21 air
fill 15 65 23 19 68 27 air
fill 15 65 29 19 68 33 air
fill 15 65 35 19 68 39 air
fill 15 65 41 19 68 45 air
fill 15 65 47 19 68 51 air
fill 15 65 53 19 68 57 air
fill 15 65 59 19 68 63 air
fill 15 65 65 19 68 69 air
fill -39 65 16 -35 68 16 air
fill -34 65 11 -34 68 15 air
