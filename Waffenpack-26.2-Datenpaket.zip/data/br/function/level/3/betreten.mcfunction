scoreboard players set #f3 br 1
title @a[tag=br_in3] times 10 80 25
title @a[tag=br_in3] subtitle {"text":"Das Hotel – finde den Hauptschalter","color":"gray","italic":true}
title @a[tag=br_in3] title {"text":"LEVEL 3","color":"gold","bold":true}
playsound minecraft:entity.witch.ambient ambient @a[tag=br_in3] ~ ~ ~ 1 0.6
execute as @a[tag=br_in3] run spawnpoint @s -118 65 12
kill @e[tag=br_mob,x=-120,y=64,z=10,dx=60,dy=6,dz=60]
setblock -87 66 31 lever[face=wall,facing=south,powered=false]
setblock -62 66 62 iron_door[facing=south,half=upper,open=false]
setblock -62 65 62 iron_door[facing=south,half=lower,open=false]
scoreboard players set #auf3 br 0
schedule function br:level/3/monster 3s
