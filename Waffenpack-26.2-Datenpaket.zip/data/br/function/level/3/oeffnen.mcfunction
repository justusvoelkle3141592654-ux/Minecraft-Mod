setblock -62 66 62 iron_door[facing=south,half=upper,open=true]
setblock -62 65 62 iron_door[facing=south,half=lower,open=true]
playsound minecraft:block.iron_door.open block @a -62 65 62 2 0.8
scoreboard players set #auf3 br 1
execute as @a[tag=br_in3] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
tellraw @a[tag=br_in3] {"text":"Ein Schloss klickt – Zimmer 237 ist offen.","color":"green"}
