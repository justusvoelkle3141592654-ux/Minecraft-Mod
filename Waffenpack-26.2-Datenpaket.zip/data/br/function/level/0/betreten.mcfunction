scoreboard players set #f0 br 1
title @a[tag=br_in0] times 10 80 25
title @a[tag=br_in0] subtitle {"text":"Die gelben Räume – finde den Notausgang","color":"gray","italic":true}
title @a[tag=br_in0] title {"text":"LEVEL 0","color":"yellow","bold":true}
playsound minecraft:block.portal.ambient ambient @a[tag=br_in0] ~ ~ ~ 1 0.6
execute as @a[tag=br_in0] run spawnpoint @s -118 65 -78
kill @e[tag=br_mob,x=-120,y=64,z=-80,dx=60,dy=6,dz=60]
schedule function br:level/0/monster 3s
