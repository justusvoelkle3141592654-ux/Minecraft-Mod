scoreboard players set #f1 br 1
title @a[tag=br_in1] times 10 80 25
title @a[tag=br_in1] subtitle {"text":"Die Lagerhalle – Notstrom einschalten","color":"gray","italic":true}
title @a[tag=br_in1] title {"text":"LEVEL 1","color":"gray","bold":true}
playsound minecraft:ambient.cave ambient @a[tag=br_in1] ~ ~ ~ 1 0.6
execute as @a[tag=br_in1] run spawnpoint @s -38 65 -78
kill @e[tag=br_mob,x=-40,y=64,z=-80,dx=60,dy=8,dz=60]
setblock -10 66 -56 lever[face=wall,facing=south,powered=false]
setblock -34 66 -48 lever[face=wall,facing=south,powered=false]
setblock 14 66 -24 lever[face=wall,facing=south,powered=false]
fill 17 65 -20 17 67 -20 iron_block
scoreboard players set #auf1 br 0
schedule function br:level/1/monster 3s
