fill 17 66 -20 17 67 -20 air
setblock 17 65 -20 end_gateway{exit_portal:[I;41,65,-79],exact_teleport:1b,Age:1000L}
scoreboard players set #auf1 br 1
execute as @a[tag=br_in1] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
tellraw @a[tag=br_in1] {"text":"Notstrom an – der Aufzug fährt!","color":"green"}
