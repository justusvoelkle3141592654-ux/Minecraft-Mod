scoreboard players set #f2 br 1
title @a[tag=br_in2] times 10 80 25
title @a[tag=br_in2] subtitle {"text":"Die Rohrtunnel – nimm die Taschenlampe","color":"gray","italic":true}
title @a[tag=br_in2] title {"text":"LEVEL 2","color":"dark_red","bold":true}
playsound minecraft:block.fire.extinguish ambient @a[tag=br_in2] ~ ~ ~ 1 0.6
execute as @a[tag=br_in2] run spawnpoint @s 41 65 -79
kill @e[tag=br_mob,x=40,y=64,z=-80,dx=51,dy=5,dz=51]
schedule function br:level/2/monster 3s
