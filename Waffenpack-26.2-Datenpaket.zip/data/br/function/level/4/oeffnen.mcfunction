fill 17 66 67 17 66 67 air
setblock 17 65 67 end_gateway{exit_portal:[I;57,65,41],exact_teleport:1b,Age:1000L}
scoreboard players set #auf4 br 1
execute as @a[tag=br_in4] at @s run playsound minecraft:block.note_block.pling master @s ~ ~ ~ 1 1.5
tellraw @a[tag=br_in4] {"text":"Alle Sicherungen drin – der Aufzug fährt!","color":"green"}
