scoreboard players set #f4 br 1
title @a[tag=br_in4] times 10 80 25
title @a[tag=br_in4] subtitle {"text":"Das Büro – 4 Sicherungen einschalten","color":"gray","italic":true}
title @a[tag=br_in4] title {"text":"LEVEL 4","color":"aqua","bold":true}
playsound minecraft:block.note_block.bell ambient @a[tag=br_in4] ~ ~ ~ 1 0.6
execute as @a[tag=br_in4] run spawnpoint @s -37 65 13
kill @e[tag=br_mob,x=-40,y=64,z=10,dx=60,dy=5,dz=60]
setblock 11 66 65 lever[face=wall,facing=south,powered=false]
setblock 17 66 11 lever[face=wall,facing=south,powered=false]
setblock 15 66 49 lever[face=wall,facing=east,powered=false]
setblock 9 66 31 lever[face=wall,facing=east,powered=false]
fill 17 65 67 17 66 67 iron_block
scoreboard players set #auf4 br 0
schedule function br:level/4/monster 3s
