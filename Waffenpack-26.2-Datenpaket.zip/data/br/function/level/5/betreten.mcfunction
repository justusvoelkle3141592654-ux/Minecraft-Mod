scoreboard players set #f5 br 1
title @a[tag=br_in5] times 10 80 25
title @a[tag=br_in5] subtitle {"text":"Deep Dark – sei leise …","color":"gray","italic":true}
title @a[tag=br_in5] title {"text":"FINALE","color":"dark_aqua","bold":true}
playsound minecraft:entity.warden.ambient ambient @a[tag=br_in5] ~ ~ ~ 1 0.6
execute as @a[tag=br_in5] run spawnpoint @s 57 65 41
kill @e[tag=br_mob,x=40,y=64,z=10,dx=34,dy=13,dz=34]
scoreboard players set #wauf br 1
scoreboard players set #wsp br 0
scoreboard players set #sieg br 0
setblock 57 65 27 air
