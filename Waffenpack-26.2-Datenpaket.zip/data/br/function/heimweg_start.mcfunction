effect give @s blindness 1 0 true
playsound minecraft:entity.enderman.teleport player @s ~ ~ ~ 1 1
function br:heimweg
execute at @s run spawnpoint @s ~ ~ ~
