scoreboard players remove #wl br 1
execute if score #wl br matches 1.. run return run function br:warden_nochmal
scoreboard players set #sieg br 1
title @a[tag=br_in5] times 10 80 25
title @a[tag=br_in5] subtitle {"text":"Du bist aus den Backrooms entkommen","color":"gray","italic":true}
title @a[tag=br_in5] title {"text":"GESCHAFFT!","color":"gold","bold":true}
execute as @a[tag=br_in5] at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 1 1
summon firework_rocket 60 65 27 {LifeTime:25,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",colors:[I;3394764,16777215],fade_colors:[I;65535],has_twinkle:true}]}}}}
summon firework_rocket 54 65 27 {LifeTime:30,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",colors:[I;3394764,16777215],fade_colors:[I;65535],has_twinkle:true}]}}}}
summon firework_rocket 57 65 30 {LifeTime:35,FireworksItem:{id:"minecraft:firework_rocket",count:1,components:{"minecraft:fireworks":{explosions:[{shape:"large_ball",colors:[I;3394764,16777215],fade_colors:[I;65535],has_twinkle:true}]}}}}
give @a[tag=br_in5] nether_star[custom_name={text:"Herz des Wardens",color:"aqua",italic:false}]
tellraw @a[tag=br_in5] {"text":"In der Mitte der Arena öffnet sich der Weg nach Hause.","color":"aqua"}
setblock 57 64 27 crying_obsidian
setblock 57 66 27 light[level=15]
