scoreboard objectives add br dummy
scoreboard objectives add start trigger
scoreboard objectives add br_tode deathCount
scoreboard objectives add br_rx dummy
scoreboard objectives add br_ry dummy
scoreboard objectives add br_rz dummy
scoreboard objectives add br_rd dummy
scoreboard objectives add br_nah dummy
scoreboard objectives add br_cd dummy
gamerule keep_inventory true
execute unless score #gebaut br matches 1 run function br:bau/start
