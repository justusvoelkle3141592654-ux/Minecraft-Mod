execute if score #wauf br matches 1.. run function br:warden_auf
execute if score #wsp br matches 1 if score #sieg br matches 0 unless entity @e[type=warden,tag=br_warden,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] run function br:warden_tot
execute if score #sieg br matches 1 as @a[x=57,y=65,z=27,distance=..1.6] run function br:heimweg_start
execute if score #sieg br matches 1 run particle minecraft:end_rod 57 66 27 0.2 1.5 0.2 0.02 6 force
execute if score #wsp br matches 0 if score #t br matches 0 as @a[tag=br_in5] at @s run playsound minecraft:entity.warden.heartbeat hostile @s ~ ~ ~ 1 1
