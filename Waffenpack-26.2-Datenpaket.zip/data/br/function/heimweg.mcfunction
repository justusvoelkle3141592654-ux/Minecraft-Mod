execute store result storage br:tmp x int 1 run scoreboard players get @s br_rx
execute store result storage br:tmp y int 1 run scoreboard players get @s br_ry
execute store result storage br:tmp z int 1 run scoreboard players get @s br_rz
execute if score @s br_rd matches 1 run return run function br:heimweg_ne with storage br:tmp
execute if score @s br_rd matches 2 run return run function br:heimweg_end with storage br:tmp
function br:heimweg_ow with storage br:tmp
