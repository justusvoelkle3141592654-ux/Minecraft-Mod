execute if score #t2 br matches 5 run setblock -66 70 -42 structure_block[mode=load]
execute if score #t2 br matches 5 run setblock -66 69 -42 air
execute if score #t2 br matches 8 run setblock -66 70 -42 structure_block[mode=corner]
execute if score #t2 br matches 8 run setblock -66 69 -42 light[level=15]
execute if score #t2 br matches 42 run setblock -110 70 -46 structure_block[mode=load]
execute if score #t2 br matches 42 run setblock -110 69 -46 air
execute if score #t2 br matches 45 run setblock -110 70 -46 structure_block[mode=corner]
execute if score #t2 br matches 45 run setblock -110 69 -46 light[level=15]
execute if score #t2 br matches 79 run setblock -86 70 -54 structure_block[mode=load]
execute if score #t2 br matches 79 run setblock -86 69 -54 air
execute if score #t2 br matches 82 run setblock -86 70 -54 structure_block[mode=corner]
execute if score #t2 br matches 82 run setblock -86 69 -54 light[level=15]
execute if score #t2 br matches 116 run setblock -74 70 -66 structure_block[mode=load]
execute if score #t2 br matches 116 run setblock -74 69 -66 air
execute if score #t2 br matches 119 run setblock -74 70 -66 structure_block[mode=corner]
execute if score #t2 br matches 119 run setblock -74 69 -66 light[level=15]
execute if score #t2 br matches 153 run setblock -74 70 -22 structure_block[mode=load]
execute if score #t2 br matches 153 run setblock -74 69 -22 air
execute if score #t2 br matches 156 run setblock -74 70 -22 structure_block[mode=corner]
execute if score #t2 br matches 156 run setblock -74 69 -22 light[level=15]
execute if score #t2 br matches 190 run setblock -102 70 -38 structure_block[mode=load]
execute if score #t2 br matches 190 run setblock -102 69 -38 air
execute if score #t2 br matches 193 run setblock -102 70 -38 structure_block[mode=corner]
execute if score #t2 br matches 193 run setblock -102 69 -38 light[level=15]
execute if score #t2 br matches 227 run setblock -78 70 -62 structure_block[mode=load]
execute if score #t2 br matches 227 run setblock -78 69 -62 air
execute if score #t2 br matches 230 run setblock -78 70 -62 structure_block[mode=corner]
execute if score #t2 br matches 230 run setblock -78 69 -62 light[level=15]
execute if score #t2 br matches 264 run setblock -7 72 -65 smooth_stone
execute if score #t2 br matches 264 run setblock -7 71 -65 air
execute if score #t2 br matches 267 run setblock -7 72 -65 structure_block[mode=corner]
execute if score #t2 br matches 267 run setblock -7 71 -65 light[level=15]
execute if score #t2 br matches 21 run setblock 5 72 -53 smooth_stone
execute if score #t2 br matches 21 run setblock 5 71 -53 air
execute if score #t2 br matches 24 run setblock 5 72 -53 structure_block[mode=corner]
execute if score #t2 br matches 24 run setblock 5 71 -53 light[level=15]
execute if score #t2 br matches 58 run setblock -19 72 -71 smooth_stone
execute if score #t2 br matches 58 run setblock -19 71 -71 air
execute if score #t2 br matches 61 run setblock -19 72 -71 structure_block[mode=corner]
execute if score #t2 br matches 61 run setblock -19 71 -71 light[level=15]
execute if score #t2 br matches 95 run setblock -37 72 -47 smooth_stone
execute if score #t2 br matches 95 run setblock -37 71 -47 air
execute if score #t2 br matches 98 run setblock -37 72 -47 structure_block[mode=corner]
execute if score #t2 br matches 98 run setblock -37 71 -47 light[level=15]
execute if score #t2 br matches 132 run setblock -25 72 -71 smooth_stone
execute if score #t2 br matches 132 run setblock -25 71 -71 air
execute if score #t2 br matches 135 run setblock -25 72 -71 structure_block[mode=corner]
execute if score #t2 br matches 135 run setblock -25 71 -71 light[level=15]
execute if score #t2 br matches 169 run setblock -13 72 -53 smooth_stone
execute if score #t2 br matches 169 run setblock -13 71 -53 air
execute if score #t2 br matches 172 run setblock -13 72 -53 structure_block[mode=corner]
execute if score #t2 br matches 172 run setblock -13 71 -53 light[level=15]
execute if score #t2 br matches 206 run setblock -1 72 -59 smooth_stone
execute if score #t2 br matches 206 run setblock -1 71 -59 air
execute if score #t2 br matches 209 run setblock -1 72 -59 structure_block[mode=corner]
execute if score #t2 br matches 209 run setblock -1 71 -59 light[level=15]
execute if score #t2 br matches 243 run setblock -13 72 -23 smooth_stone
execute if score #t2 br matches 243 run setblock -13 71 -23 air
execute if score #t2 br matches 246 run setblock -13 72 -23 structure_block[mode=corner]
execute if score #t2 br matches 246 run setblock -13 71 -23 light[level=15]
execute if score #t2 br matches 280 run setblock -90 68 12 test_block[mode=start]
execute if score #t2 br matches 280 run setblock -90 67 12 air
execute if score #t2 br matches 283 run setblock -90 68 12 structure_block[mode=corner]
execute if score #t2 br matches 283 run setblock -90 67 12 light[level=15]
execute if score #t2 br matches 37 run setblock -78 68 60 test_block[mode=start]
execute if score #t2 br matches 37 run setblock -78 67 60 air
execute if score #t2 br matches 40 run setblock -78 68 60 structure_block[mode=corner]
execute if score #t2 br matches 40 run setblock -78 67 60 light[level=15]
execute if score #t2 br matches 74 run setblock -114 68 48 test_block[mode=start]
execute if score #t2 br matches 74 run setblock -114 67 48 air
execute if score #t2 br matches 77 run setblock -114 68 48 structure_block[mode=corner]
execute if score #t2 br matches 77 run setblock -114 67 48 light[level=15]
execute if score #t2 br matches 111 run setblock -102 68 48 test_block[mode=start]
execute if score #t2 br matches 111 run setblock -102 67 48 air
execute if score #t2 br matches 114 run setblock -102 68 48 structure_block[mode=corner]
execute if score #t2 br matches 114 run setblock -102 67 48 light[level=15]
execute if score #t2 br matches 148 run setblock -78 68 48 test_block[mode=start]
execute if score #t2 br matches 148 run setblock -78 67 48 air
execute if score #t2 br matches 151 run setblock -78 68 48 structure_block[mode=corner]
execute if score #t2 br matches 151 run setblock -78 67 48 light[level=15]
execute if score #t2 br matches 185 run setblock 17 69 13 structure_block[mode=load]
execute if score #t2 br matches 185 run setblock 17 68 13 air
execute if score #t2 br matches 188 run setblock 17 69 13 structure_block[mode=corner]
execute if score #t2 br matches 188 run setblock 17 68 13 light[level=15]
execute if score #t2 br matches 222 run setblock -13 69 49 structure_block[mode=load]
execute if score #t2 br matches 222 run setblock -13 68 49 air
execute if score #t2 br matches 225 run setblock -13 69 49 structure_block[mode=corner]
execute if score #t2 br matches 225 run setblock -13 68 49 light[level=15]
execute if score #t2 br matches 259 run setblock -7 69 43 structure_block[mode=load]
execute if score #t2 br matches 259 run setblock -7 68 43 air
execute if score #t2 br matches 262 run setblock -7 69 43 structure_block[mode=corner]
execute if score #t2 br matches 262 run setblock -7 68 43 light[level=15]
execute if score #t2 br matches 16 run setblock -25 69 13 structure_block[mode=load]
execute if score #t2 br matches 16 run setblock -25 68 13 air
execute if score #t2 br matches 19 run setblock -25 69 13 structure_block[mode=corner]
execute if score #t2 br matches 19 run setblock -25 68 13 light[level=15]
execute if score #t2 br matches 53 run setblock 11 69 43 structure_block[mode=load]
execute if score #t2 br matches 53 run setblock 11 68 43 air
execute if score #t2 br matches 56 run setblock 11 69 43 structure_block[mode=corner]
execute if score #t2 br matches 56 run setblock 11 68 43 light[level=15]
execute if score #t2 br matches 90 run setblock 11 69 13 structure_block[mode=load]
execute if score #t2 br matches 90 run setblock 11 68 13 air
execute if score #t2 br matches 93 run setblock 11 69 13 structure_block[mode=corner]
execute if score #t2 br matches 93 run setblock 11 68 13 light[level=15]
execute if score #t2 br matches 120 as @a[tag=br_in0] at @s run playsound minecraft:block.portal.ambient ambient @s ~ ~ ~ 0.25 2
execute if score #t2 br matches 200 as @a[tag=br_in1] at @s run playsound minecraft:ambient.cave ambient @s ~ ~ ~ 0.8 0.7
execute if score #t2 br matches 0 as @a[tag=br_in2] at @s run playsound minecraft:block.fire.extinguish ambient @s ~ ~2 ~3 0.4 0.5
execute if score #t2 br matches 90 as @a[tag=br_in3] at @s run playsound minecraft:entity.witch.ambient ambient @s ~6 ~ ~ 0.6 1.4
execute if score #t2 br matches 210 as @a[tag=br_in3] at @s run playsound minecraft:entity.firework_rocket.twinkle_far ambient @s ~ ~ ~-6 0.6 0.8
execute if score #t2 br matches 60 as @a[tag=br_in4] at @s run playsound minecraft:block.note_block.bell ambient @s ~5 ~ ~ 0.5 1.2
execute if score #t2 br matches 64 as @a[tag=br_in4] at @s run playsound minecraft:block.note_block.bell ambient @s ~5 ~ ~ 0.5 1.2
execute if score #t2 br matches 160 as @a[tag=br_in4] at @s run playsound minecraft:block.note_block.hat ambient @s ~ ~ ~4 0.4 1.6
execute as @a[tag=br_in2] at @s run particle minecraft:cloud ~ ~2.6 ~ 4 0.1 4 0.005 1
execute as @a[tag=br_in0] at @s run particle minecraft:white_ash ~ ~1 ~ 4 2 4 0 4
execute as @a[tag=br_in5] at @s run particle minecraft:sculk_soul ~ ~1 ~ 6 3 6 0.01 1
execute if score #lv br matches 2 if score #t4 br matches 0 as @e[type=marker,tag=br_dg0] at @s run particle minecraft:cloud ~ ~ ~ 0.15 1 0.15 0.06 40 force
execute if score #lv br matches 2 if score #t4 br matches 0 as @e[type=marker,tag=br_dg0] at @s run playsound minecraft:block.fire.extinguish block @a ~ ~ ~ 1 0.6
execute if score #lv br matches 2 if score #t4 br matches 0 as @e[type=marker,tag=br_dg0] at @s run execute as @a[distance=..1.2] run damage @s 3 minecraft:hot_floor
execute if score #lv br matches 2 if score #t4 br matches 20 as @e[type=marker,tag=br_dg1] at @s run particle minecraft:cloud ~ ~ ~ 0.15 1 0.15 0.06 40 force
execute if score #lv br matches 2 if score #t4 br matches 20 as @e[type=marker,tag=br_dg1] at @s run playsound minecraft:block.fire.extinguish block @a ~ ~ ~ 1 0.6
execute if score #lv br matches 2 if score #t4 br matches 20 as @e[type=marker,tag=br_dg1] at @s run execute as @a[distance=..1.2] run damage @s 3 minecraft:hot_floor
execute if score #lv br matches 2 if score #t4 br matches 40 as @e[type=marker,tag=br_dg2] at @s run particle minecraft:cloud ~ ~ ~ 0.15 1 0.15 0.06 40 force
execute if score #lv br matches 2 if score #t4 br matches 40 as @e[type=marker,tag=br_dg2] at @s run playsound minecraft:block.fire.extinguish block @a ~ ~ ~ 1 0.6
execute if score #lv br matches 2 if score #t4 br matches 40 as @e[type=marker,tag=br_dg2] at @s run execute as @a[distance=..1.2] run damage @s 3 minecraft:hot_floor
