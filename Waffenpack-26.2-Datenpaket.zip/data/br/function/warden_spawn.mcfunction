scoreboard players set #wauf br 0
execute unless score #wl br matches 1.. run scoreboard players set #wl br 3
summon warden 57 65 27 {Tags:["br_mob","br_warden"],PersistenceRequired:1b,CustomName:"Warden",attributes:[{id:"minecraft:max_health",base:1000},{id:"minecraft:knockback_resistance",base:1}],Health:1000.0f,Brain:{memories:{"minecraft:dig_cooldown":{value:{},ttl:2147483647L}}}}
execute as @e[type=warden,tag=br_warden,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] at @s run damage @s 0.1 minecraft:player_attack by @p[tag=br_in5]
scoreboard players set #wsp br 1
title @a[tag=br_in5] times 10 80 25
title @a[tag=br_in5] subtitle {"text":"Er sieht dich nicht. Er hört dich.","color":"gray","italic":true}
title @a[tag=br_in5] title {"text":"DER WARDEN","color":"dark_aqua","bold":true}
