execute if score #t br matches 0 run item replace entity @e[tag=br_smiler,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:smiler_a"]
execute if score #t br matches 8 run item replace entity @e[tag=br_smiler,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:smiler_b"]
execute if score #t br matches 0 run item replace entity @e[tag=br_hound,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:hound_a"]
execute if score #t br matches 8 run item replace entity @e[tag=br_hound,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:hound_b"]
execute if score #t br matches 0 run item replace entity @e[tag=br_hautdieb,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:hautdieb_a"]
execute if score #t br matches 8 run item replace entity @e[tag=br_hautdieb,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:hautdieb_b"]
execute if score #t br matches 0 run item replace entity @e[tag=br_partygaenger,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:partygaenger_a"]
execute if score #t br matches 8 run item replace entity @e[tag=br_partygaenger,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:partygaenger_b"]
execute if score #t br matches 0 run item replace entity @e[tag=br_faceling,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:faceling_a"]
execute if score #t br matches 8 run item replace entity @e[tag=br_faceling,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] armor.head with diamond_hoe[item_model="waffenpack:faceling_b"]
execute if score #t2 br matches 40 as @e[tag=br_smiler,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] at @s run playsound minecraft:entity.vex.ambient hostile @a ~ ~ ~ 1.2 0.5
execute if score #t2 br matches 90 as @e[tag=br_hound,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] at @s run playsound minecraft:entity.wolf.growl hostile @a ~ ~ ~ 1.2 0.5
execute if score #t2 br matches 150 as @e[tag=br_hautdieb,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] at @s run playsound minecraft:entity.villager.no hostile @a ~ ~ ~ 1.2 0.5
execute if score #t2 br matches 180 as @e[tag=br_partygaenger,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] at @s run playsound minecraft:entity.witch.celebrate hostile @a ~ ~ ~ 1.2 1.6
execute if score #t2 br matches 250 as @e[tag=br_faceling,x=-124,y=60,z=-84,dx=220,dy=30,dz=159] at @s run playsound minecraft:entity.villager.ambient hostile @a ~ ~ ~ 1.2 0.4
execute if score #t3 br matches 1 run function br:nachschub
