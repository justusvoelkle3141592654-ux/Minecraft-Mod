gamemode adventure @s
tag @s add br_adv
