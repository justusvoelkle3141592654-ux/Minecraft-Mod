scoreboard players set @s br_tode 0
execute at @s if dimension br:backrooms run effect give @s resistance 5 4 true
execute at @s if dimension br:backrooms run effect give @s regeneration 5 2 true
