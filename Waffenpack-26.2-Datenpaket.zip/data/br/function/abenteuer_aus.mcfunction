gamemode survival @s
tag @s remove br_adv
