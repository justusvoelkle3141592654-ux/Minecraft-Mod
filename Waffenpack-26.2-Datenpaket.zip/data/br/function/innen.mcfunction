scoreboard players add #t br 1
execute if score #t br matches 16.. run scoreboard players set #t br 0
scoreboard players add #t2 br 1
execute if score #t2 br matches 300.. run scoreboard players set #t2 br 0
scoreboard players add #t3 br 1
execute if score #t3 br matches 120.. run scoreboard players set #t3 br 0
scoreboard players add #t4 br 1
execute if score #t4 br matches 60.. run scoreboard players set #t4 br 0
scoreboard players set #lv br -1
tag @a remove br_in0
tag @a[x=-120,y=64,z=-80,dx=60,dy=6,dz=60] add br_in0
execute if entity @a[tag=br_in0] run scoreboard players set #lv br 0
execute if score #f0 br matches 0 if entity @a[tag=br_in0] run function br:level/0/betreten
tag @a remove br_in1
tag @a[x=-40,y=64,z=-80,dx=60,dy=8,dz=60] add br_in1
execute if entity @a[tag=br_in1] run scoreboard players set #lv br 1
execute if score #f1 br matches 0 if entity @a[tag=br_in1] run function br:level/1/betreten
tag @a remove br_in2
tag @a[x=40,y=64,z=-80,dx=51,dy=5,dz=51] add br_in2
execute if entity @a[tag=br_in2] run scoreboard players set #lv br 2
execute if score #f2 br matches 0 if entity @a[tag=br_in2] run function br:level/2/betreten
tag @a remove br_in3
tag @a[x=-120,y=64,z=10,dx=60,dy=6,dz=60] add br_in3
execute if entity @a[tag=br_in3] run scoreboard players set #lv br 3
execute if score #f3 br matches 0 if entity @a[tag=br_in3] run function br:level/3/betreten
tag @a remove br_in4
tag @a[x=-40,y=64,z=10,dx=60,dy=5,dz=60] add br_in4
execute if entity @a[tag=br_in4] run scoreboard players set #lv br 4
execute if score #f4 br matches 0 if entity @a[tag=br_in4] run function br:level/4/betreten
tag @a remove br_in5
tag @a[x=40,y=64,z=10,dx=34,dy=13,dz=34] add br_in5
execute if entity @a[tag=br_in5] run scoreboard players set #lv br 5
execute if score #f5 br matches 0 if entity @a[tag=br_in5] run function br:level/5/betreten
function br:raetsel
function br:atmo
function br:monster
function br:warden
