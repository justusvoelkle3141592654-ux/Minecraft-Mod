title @a[tag=br_in5] times 10 80 25
title @a[tag=br_in5] subtitle {"text":"Der Warden wird nur noch wütender …","color":"gray","italic":true}
title @a[tag=br_in5] title {"text":"ER LEBT NOCH","color":"dark_aqua","bold":true}
particle minecraft:block{block_state:"minecraft:sculk"} 57 65 27 1.2 0.3 1.2 0.2 80 force
scoreboard players set #wauf br 60
scoreboard players set #wsp br 0
