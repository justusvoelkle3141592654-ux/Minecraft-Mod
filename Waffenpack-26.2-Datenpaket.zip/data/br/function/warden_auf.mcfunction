scoreboard players add #wauf br 1
particle minecraft:block{block_state:"minecraft:sculk"} 57 65 27 0.9 0.1 0.9 0.15 14 force
particle minecraft:sculk_soul 57 65 27 0.6 0.4 0.6 0.02 3 force
execute if score #wauf br matches 2 run playsound minecraft:entity.warden.emerge hostile @a[tag=br_in5] 57 65 27 3 1
execute if score #wauf br matches 40 run playsound minecraft:entity.warden.roar hostile @a[tag=br_in5] 57 65 27 3 0.8
execute if score #wauf br matches 100.. run function br:warden_spawn
