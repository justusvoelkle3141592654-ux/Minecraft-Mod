execute if entity @s[tag=wp_pb] run function wp:wirkung/rakete
execute if entity @s[tag=wp_ps] run function wp:wirkung/schatten
execute if entity @s[tag=wp_pv] run function wp:wirkung/vernichtung
execute if entity @s[tag=wp_pp] run particle minecraft:smoke ~ ~ ~ 0.1 0.1 0.1 0.02 8 force
execute on passengers run kill @s
kill @s
