execute if entity @s[tag=wp_sb] run function wp:wirkung/rakete
execute if entity @s[tag=wp_ss] run function wp:wirkung/schatten
execute if entity @s[tag=wp_sv] run function wp:wirkung/vernichtung
execute if entity @s[tag=wp_sw,scores={wp_art=1}] run function wp:wirkung/w1
execute if entity @s[tag=wp_sw,scores={wp_art=2}] run function wp:wirkung/w2
execute if entity @s[tag=wp_sw,scores={wp_art=3}] run function wp:wirkung/w3
execute if entity @s[tag=wp_sw,scores={wp_art=4}] run function wp:wirkung/w4
execute if entity @s[tag=wp_sw,scores={wp_art=5}] run function wp:wirkung/w5
execute if entity @s[tag=wp_sw,scores={wp_art=6}] run function wp:wirkung/w6
execute if entity @s[tag=wp_sw,scores={wp_art=7}] run function wp:wirkung/w7
execute if entity @s[tag=wp_sw,scores={wp_art=8}] run function wp:wirkung/w8
execute if entity @s[tag=wp_sw,scores={wp_art=9}] run function wp:wirkung/w9
execute if entity @s[tag=wp_sw,scores={wp_art=10}] run function wp:wirkung/w10
kill @s
