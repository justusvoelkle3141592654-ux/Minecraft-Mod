scoreboard objectives add wp_rute minecraft.used:minecraft.carrot_on_a_stick
scoreboard objectives add wp_t dummy
scoreboard objectives add wp_alter dummy
scoreboard objectives add wp_art dummy
scoreboard objectives add wp_mg dummy
function br:laden
