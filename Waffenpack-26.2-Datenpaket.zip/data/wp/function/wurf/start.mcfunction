tag @s add wp_proj
execute store result score @s wp_art run data get entity @s Item.components."minecraft:custom_data".wt
summon item_display ~ ~ ~ {teleport_duration:1,Tags:["wp_sys","wp_sensor","wp_neu","wp_sw"]}
scoreboard players operation @e[type=item_display,tag=wp_neu,limit=1,sort=nearest] wp_art = @s wp_art
ride @e[type=item_display,tag=wp_neu,limit=1,sort=nearest] mount @s
tag @e[type=item_display,tag=wp_neu] remove wp_neu
playsound minecraft:entity.snowball.throw player @a ~ ~ ~ 1 0.6
execute if score @s wp_art matches 1 on origin run function wp:items/granate_1
execute if score @s wp_art matches 2 on origin run function wp:items/granate_2
execute if score @s wp_art matches 3 on origin run function wp:items/granate_3
execute if score @s wp_art matches 4 on origin run function wp:items/granate_4
execute if score @s wp_art matches 5 on origin run function wp:items/granate_5
execute if score @s wp_art matches 6 on origin run function wp:items/granate_6
execute if score @s wp_art matches 7 on origin run function wp:items/granate_7
execute if score @s wp_art matches 8 on origin run function wp:items/granate_8
execute if score @s wp_art matches 9 on origin run function wp:items/granate_9
execute if score @s wp_art matches 10 on origin run function wp:items/granate_10
