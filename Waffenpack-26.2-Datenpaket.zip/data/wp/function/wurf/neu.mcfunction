execute as @e[type=snowball,tag=!wp_alt] if data entity @s Item.components."minecraft:custom_data".wt at @s run function wp:wurf/start
tag @e[type=snowball,tag=!wp_alt] add wp_alt
