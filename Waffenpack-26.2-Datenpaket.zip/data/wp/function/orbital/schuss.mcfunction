playsound minecraft:block.beacon.activate player @a ~ ~ ~ 1 1.8
playsound minecraft:entity.firework_rocket.launch player @a ~ ~ ~ 1 1.6
scoreboard players set #schritt wp_t 0
function wp:orbital/strahl
