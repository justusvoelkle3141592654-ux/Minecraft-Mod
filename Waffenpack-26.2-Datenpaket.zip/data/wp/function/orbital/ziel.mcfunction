execute align xyz positioned ~0.5 ~ ~0.5 run summon marker ~ ~ ~ {Tags:["wp_sys","wp_fx","wp_orb"]}
title @s actionbar {"text":"ORBITALSCHLAG IN 2 SEKUNDEN","color":"red","italic":false,"bold":true}
