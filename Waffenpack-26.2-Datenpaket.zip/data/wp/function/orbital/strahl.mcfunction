scoreboard players add #schritt wp_t 1
execute if score #schritt wp_t matches 3.. run particle minecraft:end_rod ~ ~ ~ 0 0 0 0 1 force
execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[dx=0,dy=0,dz=0,type=!#wp:kein_ziel,tag=!wp_sys] positioned ~0.5 ~0.5 ~0.5 run return run function wp:orbital/ziel
execute unless block ~ ~ ~ #wp:durchlaessig positioned ^ ^ ^-1 run return run function wp:orbital/ziel
execute if score #schritt wp_t matches ..200 positioned ^ ^ ^1 run function wp:orbital/strahl
