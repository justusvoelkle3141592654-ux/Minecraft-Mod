execute as @e[distance=..12,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] run damage @s 60 minecraft:explosion
particle minecraft:explosion_emitter ~ ~ ~ 2.5 2.5 2.5 0 3 force
particle minecraft:explosion ~ ~ ~ 5 1 5 0 30 force
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 5 0.8
