execute if dimension br:backrooms run function wp:boom/sicher_7
execute unless dimension br:backrooms run summon tnt ~ ~ ~ {fuse:0,explosion_power:7.0f,Tags:["wp_tx"]}
