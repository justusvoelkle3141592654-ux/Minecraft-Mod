execute if dimension br:backrooms run function wp:boom/sicher_3
execute unless dimension br:backrooms run summon tnt ~ ~ ~ {fuse:0,explosion_power:3.0f,Tags:["wp_tx"]}
