execute as @e[distance=..5,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] run damage @s 18 minecraft:explosion
particle minecraft:explosion_emitter ~ ~ ~ 0.8 0.8 0.8 0 1 force
particle minecraft:explosion ~ ~ ~ 1 1 1 0 9 force
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 2 0.8
