execute as @e[distance=..9,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] run damage @s 42 minecraft:explosion
particle minecraft:explosion_emitter ~ ~ ~ 1.8 1.8 1.8 0 2 force
particle minecraft:explosion ~ ~ ~ 3 1 3 0 21 force
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 3 0.8
