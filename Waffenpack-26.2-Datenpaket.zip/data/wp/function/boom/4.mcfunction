execute if dimension br:backrooms run function wp:boom/sicher_4
execute unless dimension br:backrooms run summon tnt ~ ~ ~ {fuse:0,explosion_power:4.0f,Tags:["wp_tx"]}
