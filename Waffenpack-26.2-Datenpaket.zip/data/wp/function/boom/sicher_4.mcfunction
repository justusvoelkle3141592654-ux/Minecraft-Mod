execute as @e[distance=..6,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] run damage @s 24 minecraft:explosion
particle minecraft:explosion_emitter ~ ~ ~ 1.0 1.0 1.0 0 1 force
particle minecraft:explosion ~ ~ ~ 2 1 2 0 12 force
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 2 0.8
