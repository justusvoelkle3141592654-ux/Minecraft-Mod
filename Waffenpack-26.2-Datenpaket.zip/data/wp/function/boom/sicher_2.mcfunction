execute as @e[distance=..4,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] run damage @s 12 minecraft:explosion
particle minecraft:explosion_emitter ~ ~ ~ 0.5 0.5 0.5 0 1 force
particle minecraft:explosion ~ ~ ~ 1 1 1 0 6 force
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 2 0.8
