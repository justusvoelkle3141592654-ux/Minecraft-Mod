execute as @a[tag=!wp_hat] at @s run function wp:items/erstausstattung
function wp:halten
function wp:pfeil/neu
function wp:wurf/neu
execute as @a[scores={wp_rute=1..}] at @s run function wp:rute
scoreboard players reset @a wp_rute
function wp:fahrzeug
function wp:schatten/lenken_alle
function wp:fx/tick
function wp:lampe/tick
function wp:sondertnt
function br:tick
