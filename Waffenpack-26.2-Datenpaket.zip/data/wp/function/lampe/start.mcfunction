execute if block ~ ~ ~ #wp:luft run function wp:lampe/setzen_schwach
scoreboard players set #schritt wp_t 0
function wp:lampe/strahl
