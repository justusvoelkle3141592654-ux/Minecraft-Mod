execute if block ~ ~ ~ #wp:luft run summon marker ~ ~ ~ {Tags:["wp_sys","wp_licht"]}
execute if block ~ ~ ~ #wp:luft run setblock ~ ~ ~ light[level=15]
