execute as @e[type=marker,tag=wp_licht] at @s if block ~ ~ ~ light run setblock ~ ~ ~ air
kill @e[type=marker,tag=wp_licht]
execute as @a[tag=wp_h9] at @s anchored eyes positioned ^ ^ ^ run function wp:lampe/start
