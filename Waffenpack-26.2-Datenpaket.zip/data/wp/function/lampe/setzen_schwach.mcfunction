summon marker ~ ~ ~ {Tags:["wp_sys","wp_licht"]}
setblock ~ ~ ~ light[level=9]
