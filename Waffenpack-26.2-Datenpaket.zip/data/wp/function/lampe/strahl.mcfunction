scoreboard players add #schritt wp_t 1
execute unless block ^ ^ ^0.5 #wp:durchlaessig run return run function wp:lampe/setzen
execute if score #schritt wp_t matches 24.. run return run function wp:lampe/setzen
execute positioned ^ ^ ^0.5 run function wp:lampe/strahl
