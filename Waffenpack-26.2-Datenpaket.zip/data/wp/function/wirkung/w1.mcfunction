function wp:boom/4
