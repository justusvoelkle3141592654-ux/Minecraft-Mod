function wp:boom/10
particle minecraft:explosion_emitter ~ ~ ~ 4 2 4 0 10 force
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 8 0.5
