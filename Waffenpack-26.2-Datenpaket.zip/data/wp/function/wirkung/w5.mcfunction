function wp:boom/2
summon lightning_bolt ~0 ~ ~0
summon lightning_bolt ~4 ~ ~0
summon lightning_bolt ~-4 ~ ~0
summon lightning_bolt ~0 ~ ~4
summon lightning_bolt ~0 ~ ~-4
