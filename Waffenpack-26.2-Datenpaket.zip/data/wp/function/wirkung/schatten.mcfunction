execute as @e[distance=..4,type=!#wp:kein_ziel,tag=!wp_sys,type=!player,limit=4,sort=nearest] at @s run summon evoker_fangs ~ ~ ~
effect give @e[distance=..4,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] wither 6 2
effect give @e[distance=..4,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] blindness 4 0
effect give @e[distance=..4,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] slowness 4 2
particle minecraft:dragon_breath ~ ~ ~ 1.2 0.8 1.2 0.02 70 force
particle minecraft:reverse_portal ~ ~ ~ 1 1 1 0.2 60 force
playsound minecraft:entity.evoker_fangs.attack player @a ~ ~ ~ 1 0.7
playsound minecraft:entity.wither.hurt player @a ~ ~ ~ 0.6 1.5
