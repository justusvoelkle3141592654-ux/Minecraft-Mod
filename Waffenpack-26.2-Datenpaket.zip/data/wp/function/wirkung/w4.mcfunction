function wp:boom/3
particle minecraft:lava ~ ~ ~ 2 1 2 0 40 force
particle minecraft:flame ~ ~1 ~ 2 1 2 0.05 80 force
execute as @e[distance=..6,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] run data merge entity @s {Fire:200s}
execute unless dimension br:backrooms run summon small_fireball ~3 ~4 ~0 {Motion:[0.0d,-1.0d,0.0d],acceleration_power:0.1d}
execute unless dimension br:backrooms run summon small_fireball ~-3 ~4 ~0 {Motion:[0.0d,-1.0d,0.0d],acceleration_power:0.1d}
execute unless dimension br:backrooms run summon small_fireball ~0 ~4 ~3 {Motion:[0.0d,-1.0d,0.0d],acceleration_power:0.1d}
execute unless dimension br:backrooms run summon small_fireball ~0 ~4 ~-3 {Motion:[0.0d,-1.0d,0.0d],acceleration_power:0.1d}
execute unless dimension br:backrooms run summon small_fireball ~2 ~4 ~2 {Motion:[0.0d,-1.0d,0.0d],acceleration_power:0.1d}
execute unless dimension br:backrooms run summon small_fireball ~-2 ~4 ~2 {Motion:[0.0d,-1.0d,0.0d],acceleration_power:0.1d}
execute unless dimension br:backrooms run summon small_fireball ~2 ~4 ~-2 {Motion:[0.0d,-1.0d,0.0d],acceleration_power:0.1d}
execute unless dimension br:backrooms run summon small_fireball ~-2 ~4 ~-2 {Motion:[0.0d,-1.0d,0.0d],acceleration_power:0.1d}
