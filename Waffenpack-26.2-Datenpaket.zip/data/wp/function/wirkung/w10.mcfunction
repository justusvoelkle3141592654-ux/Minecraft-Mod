execute unless dimension br:backrooms run summon marker ~ ~ ~ {Tags:["wp_sys","wp_fx","wp_wl"]}
execute if dimension br:backrooms run tellraw @a[distance=..30] {"text":"Der Weltlöscher wirkt in den Backrooms nicht.","color":"gray","italic":true}
