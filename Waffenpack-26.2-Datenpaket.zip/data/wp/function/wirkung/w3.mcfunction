function wp:boom/3
execute unless dimension br:backrooms run summon tnt ~ ~0.5 ~ {fuse:30,explosion_power:3.0f,Motion:[0.45d,0.55d,0.00d],Tags:["wp_tx"]}
execute if dimension br:backrooms positioned ~4.0 ~ ~0.0 run function wp:boom/sicher_3
execute unless dimension br:backrooms run summon tnt ~ ~0.5 ~ {fuse:30,explosion_power:3.0f,Motion:[-0.45d,0.55d,0.00d],Tags:["wp_tx"]}
execute if dimension br:backrooms positioned ~-4.0 ~ ~0.0 run function wp:boom/sicher_3
execute unless dimension br:backrooms run summon tnt ~ ~0.5 ~ {fuse:30,explosion_power:3.0f,Motion:[0.00d,0.55d,0.45d],Tags:["wp_tx"]}
execute if dimension br:backrooms positioned ~0.0 ~ ~4.0 run function wp:boom/sicher_3
execute unless dimension br:backrooms run summon tnt ~ ~0.5 ~ {fuse:30,explosion_power:3.0f,Motion:[0.00d,0.55d,-0.45d],Tags:["wp_tx"]}
execute if dimension br:backrooms positioned ~0.0 ~ ~-4.0 run function wp:boom/sicher_3
execute unless dimension br:backrooms run summon tnt ~ ~0.5 ~ {fuse:30,explosion_power:3.0f,Motion:[0.32d,0.55d,0.32d],Tags:["wp_tx"]}
execute if dimension br:backrooms positioned ~2.8 ~ ~2.8 run function wp:boom/sicher_3
execute unless dimension br:backrooms run summon tnt ~ ~0.5 ~ {fuse:30,explosion_power:3.0f,Motion:[-0.32d,0.55d,0.32d],Tags:["wp_tx"]}
execute if dimension br:backrooms positioned ~-2.8 ~ ~2.8 run function wp:boom/sicher_3
execute unless dimension br:backrooms run summon tnt ~ ~0.5 ~ {fuse:30,explosion_power:3.0f,Motion:[0.32d,0.55d,-0.32d],Tags:["wp_tx"]}
execute if dimension br:backrooms positioned ~2.8 ~ ~-2.8 run function wp:boom/sicher_3
execute unless dimension br:backrooms run summon tnt ~ ~0.5 ~ {fuse:30,explosion_power:3.0f,Motion:[-0.32d,0.55d,-0.32d],Tags:["wp_tx"]}
execute if dimension br:backrooms positioned ~-2.8 ~ ~-2.8 run function wp:boom/sicher_3
