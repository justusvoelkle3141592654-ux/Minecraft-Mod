effect give @e[distance=..10,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] levitation 3 6 true
particle minecraft:portal ~ ~1 ~ 3 2 3 1 200 force
particle minecraft:witch ~ ~1 ~ 3 2 3 0.1 60 force
playsound minecraft:entity.shulker.shoot block @a ~ ~ ~ 2 0.5
playsound minecraft:entity.illusioner.cast_spell block @a ~ ~ ~ 2 0.7
