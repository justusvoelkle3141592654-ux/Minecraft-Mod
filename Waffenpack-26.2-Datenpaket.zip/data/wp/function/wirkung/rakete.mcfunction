function wp:boom/4
particle minecraft:flame ~ ~ ~ 1 1 1 0.1 40 force
