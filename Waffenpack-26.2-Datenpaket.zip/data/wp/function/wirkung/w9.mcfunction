function wp:wirkung/vernichtung
