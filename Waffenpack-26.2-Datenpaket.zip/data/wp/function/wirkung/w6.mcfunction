effect give @e[distance=..8,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] slowness 10 6 true
effect give @e[distance=..8,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] weakness 10 2 true
execute as @e[distance=..8,type=!#wp:kein_ziel,tag=!wp_sys,type=!player] run data merge entity @s {TicksFrozen:300}
particle minecraft:snowflake ~ ~1 ~ 4 2 4 0.05 300 force
particle minecraft:block{block_state:"minecraft:ice"} ~ ~1 ~ 3 1 3 0.1 150 force
playsound minecraft:block.glass.break block @a ~ ~ ~ 2 0.6
playsound minecraft:entity.player.hurt_freeze block @a ~ ~ ~ 2 0.8
execute unless dimension br:backrooms run fill ~-6 ~-3 ~-6 ~6 ~2 ~6 ice replace water
execute unless dimension br:backrooms run fill ~-6 ~-3 ~-6 ~6 ~2 ~6 obsidian replace lava
execute unless dimension br:backrooms run fill ~-5 ~-2 ~-5 ~5 ~ ~5 packed_ice replace #minecraft:dirt
execute unless dimension br:backrooms run fill ~-5 ~-2 ~-5 ~5 ~ ~5 packed_ice replace #minecraft:base_stone_overworld
execute unless dimension br:backrooms run fill ~-5 ~-2 ~-5 ~5 ~ ~5 packed_ice replace #minecraft:sand
execute unless dimension br:backrooms run fill ~-5 ~-1 ~-5 ~5 ~2 ~5 snow replace #minecraft:replaceable
