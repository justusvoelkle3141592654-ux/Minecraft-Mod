tag @a remove wp_h1
tag @a remove wp_h2
tag @a remove wp_h3
tag @a remove wp_h4
tag @a remove wp_h5
tag @a remove wp_h6
tag @a remove wp_h9
execute as @a if items entity @s weapon.mainhand *[custom_data~{wp:1}] run tag @s add wp_h1
execute as @a if items entity @s weapon.mainhand *[custom_data~{wp:2}] run tag @s add wp_h2
execute as @a if items entity @s weapon.mainhand *[custom_data~{wp:3}] run tag @s add wp_h3
execute as @a if items entity @s weapon.mainhand *[custom_data~{wp:4}] run tag @s add wp_h4
execute as @a if items entity @s weapon.mainhand *[custom_data~{wp:5}] run tag @s add wp_h5
execute as @a if items entity @s weapon.mainhand *[custom_data~{wp:6}] run tag @s add wp_h6
execute as @a if items entity @s weapon.mainhand *[custom_data~{wp:9}] run tag @s add wp_h9
