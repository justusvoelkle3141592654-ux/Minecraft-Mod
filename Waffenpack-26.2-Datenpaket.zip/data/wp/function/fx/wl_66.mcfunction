fill ~-16 52 ~-16 ~15 55 ~15 air
fill ~-16 52 ~16 ~15 55 ~47 air
fill ~16 52 ~-16 ~47 55 ~15 air
fill ~-48 52 ~-16 ~-17 55 ~15 air
fill ~-16 52 ~-48 ~15 55 ~-17 air
fill ~16 52 ~16 ~47 55 ~47 air
fill ~-48 52 ~16 ~-17 55 ~47 air
fill ~16 52 ~-48 ~47 55 ~-17 air
fill ~-48 52 ~-48 ~-17 55 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
