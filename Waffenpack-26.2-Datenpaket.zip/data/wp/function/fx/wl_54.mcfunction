fill ~-16 100 ~-16 ~15 103 ~15 air
fill ~-16 100 ~16 ~15 103 ~47 air
fill ~16 100 ~-16 ~47 103 ~15 air
fill ~-48 100 ~-16 ~-17 103 ~15 air
fill ~-16 100 ~-48 ~15 103 ~-17 air
fill ~16 100 ~16 ~47 103 ~47 air
fill ~-48 100 ~16 ~-17 103 ~47 air
fill ~16 100 ~-48 ~47 103 ~-17 air
fill ~-48 100 ~-48 ~-17 103 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
