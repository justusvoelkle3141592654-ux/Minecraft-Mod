fill ~-16 124 ~-16 ~15 127 ~15 air
fill ~-16 124 ~16 ~15 127 ~47 air
fill ~16 124 ~-16 ~47 127 ~15 air
fill ~-48 124 ~-16 ~-17 127 ~15 air
fill ~-16 124 ~-48 ~15 127 ~-17 air
fill ~16 124 ~16 ~47 127 ~47 air
fill ~-48 124 ~16 ~-17 127 ~47 air
fill ~16 124 ~-48 ~47 127 ~-17 air
fill ~-48 124 ~-48 ~-17 127 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
