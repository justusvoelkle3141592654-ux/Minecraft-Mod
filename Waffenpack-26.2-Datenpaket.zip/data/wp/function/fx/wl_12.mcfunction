fill ~-16 268 ~-16 ~15 271 ~15 air
fill ~-16 268 ~16 ~15 271 ~47 air
fill ~16 268 ~-16 ~47 271 ~15 air
fill ~-48 268 ~-16 ~-17 271 ~15 air
fill ~-16 268 ~-48 ~15 271 ~-17 air
fill ~16 268 ~16 ~47 271 ~47 air
fill ~-48 268 ~16 ~-17 271 ~47 air
fill ~16 268 ~-48 ~47 271 ~-17 air
fill ~-48 268 ~-48 ~-17 271 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
