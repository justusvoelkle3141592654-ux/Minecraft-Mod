fill ~-16 -44 ~-16 ~15 -41 ~15 air
fill ~-16 -44 ~16 ~15 -41 ~47 air
fill ~16 -44 ~-16 ~47 -41 ~15 air
fill ~-48 -44 ~-16 ~-17 -41 ~15 air
fill ~-16 -44 ~-48 ~15 -41 ~-17 air
fill ~16 -44 ~16 ~47 -41 ~47 air
fill ~-48 -44 ~16 ~-17 -41 ~47 air
fill ~16 -44 ~-48 ~47 -41 ~-17 air
fill ~-48 -44 ~-48 ~-17 -41 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
