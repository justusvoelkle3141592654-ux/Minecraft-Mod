fill ~-16 148 ~-16 ~15 151 ~15 air
fill ~-16 148 ~16 ~15 151 ~47 air
fill ~16 148 ~-16 ~47 151 ~15 air
fill ~-48 148 ~-16 ~-17 151 ~15 air
fill ~-16 148 ~-48 ~15 151 ~-17 air
fill ~16 148 ~16 ~47 151 ~47 air
fill ~-48 148 ~16 ~-17 151 ~47 air
fill ~16 148 ~-48 ~47 151 ~-17 air
fill ~-48 148 ~-48 ~-17 151 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
