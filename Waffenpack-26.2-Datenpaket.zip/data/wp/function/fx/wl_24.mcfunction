fill ~-16 220 ~-16 ~15 223 ~15 air
fill ~-16 220 ~16 ~15 223 ~47 air
fill ~16 220 ~-16 ~47 223 ~15 air
fill ~-48 220 ~-16 ~-17 223 ~15 air
fill ~-16 220 ~-48 ~15 223 ~-17 air
fill ~16 220 ~16 ~47 223 ~47 air
fill ~-48 220 ~16 ~-17 223 ~47 air
fill ~16 220 ~-48 ~47 223 ~-17 air
fill ~-48 220 ~-48 ~-17 223 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
