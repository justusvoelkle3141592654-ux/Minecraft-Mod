scoreboard players add @e[type=marker,tag=wp_fx] wp_t 1
execute as @e[type=marker,tag=wp_orb,scores={wp_t=1..1}] at @s run playsound minecraft:block.end_portal.spawn block @a ~ ~ ~ 4 1.6
execute as @e[type=marker,tag=wp_orb,scores={wp_t=1..40}] at @s run particle minecraft:end_rod ~ ~15 ~ 0.05 15 0.05 0 25 force
execute as @e[type=marker,tag=wp_orb,scores={wp_t=1..40}] at @s run particle minecraft:dust{color:[1.0,0.1,0.1],scale:2.0} ~ ~0.3 ~ 3 0 3 0 25 force
execute as @e[type=marker,tag=wp_orb,scores={wp_t=20..20}] at @s run playsound minecraft:entity.evoker.prepare_summon block @a ~ ~ ~ 3 0.6
execute as @e[type=marker,tag=wp_orb,scores={wp_t=38..38}] at @s run playsound minecraft:entity.lightning_bolt.thunder block @a ~ ~ ~ 6 1.4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run particle minecraft:firework ~ ~25 ~ 3 3 3 0.2 200 force
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~0 ~30 ~0 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~0 ~ ~0 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~3 ~30 ~0 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~3 ~ ~0 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~-3 ~30 ~0 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~-3 ~ ~0 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~0 ~30 ~3 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~0 ~ ~3 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~0 ~30 ~-3 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~0 ~ ~-3 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~5 ~30 ~5 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~5 ~ ~5 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~-5 ~30 ~5 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~-5 ~ ~5 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~5 ~30 ~-5 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~5 ~ ~-5 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~-5 ~30 ~-5 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~-5 ~ ~-5 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~7 ~30 ~0 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~7 ~ ~0 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~-7 ~30 ~0 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~-7 ~ ~0 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~0 ~30 ~7 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~0 ~ ~7 run function wp:boom/sicher_4
execute as @e[type=marker,tag=wp_orb,scores={wp_t=40..40}] at @s run execute unless dimension br:backrooms run summon tnt ~0 ~30 ~-7 {fuse:52,explosion_power:4.0f,Tags:["wp_tx"]}
execute as @e[type=marker,tag=wp_orb,scores={wp_t=70..70}] at @s run execute if dimension br:backrooms positioned ~0 ~ ~-7 run function wp:boom/sicher_4
kill @e[type=marker,tag=wp_orb,scores={wp_t=120..}]
execute as @e[type=marker,tag=wp_met,scores={wp_t=1..1}] at @s run summon item_display ~24 ~60 ~ {Tags:["wp_sys","wp_ms"],teleport_duration:2,item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:meteor"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[5f,5f,5f]},brightness:{sky:15,block:15}}
execute as @e[type=marker,tag=wp_met,scores={wp_t=1..1}] at @s run playsound minecraft:entity.ender_dragon.growl block @a ~ ~ ~ 8 0.5
execute as @e[type=marker,tag=wp_met,scores={wp_t=1..1}] at @s run title @a[distance=..80] actionbar {"text":"METEOR IM ANFLUG!","color":"gold","italic":false,"bold":true}
execute as @e[type=marker,tag=wp_met,scores={wp_t=10..10}] at @s run playsound minecraft:entity.blaze.shoot block @a ~ ~ ~ 6 0.5
execute as @e[type=marker,tag=wp_met,scores={wp_t=25..25}] at @s run playsound minecraft:entity.blaze.shoot block @a ~ ~ ~ 6 0.5
execute as @e[type=item_display,tag=wp_ms] at @s run tp @s ~-0.6 ~-1.5 ~ ~10 ~
execute as @e[type=item_display,tag=wp_ms] at @s run particle minecraft:flame ~ ~ ~ 1.2 1.2 1.2 0.05 25 force
execute as @e[type=item_display,tag=wp_ms] at @s run particle minecraft:lava ~ ~ ~ 1 1 1 0 4 force
execute as @e[type=item_display,tag=wp_ms] at @s run particle minecraft:large_smoke ~0.6 ~1.5 ~ 1 1 1 0.02 12 force
execute as @e[type=marker,tag=wp_met,scores={wp_t=41..41}] at @s run kill @e[type=item_display,tag=wp_ms,distance=..12]
execute as @e[type=marker,tag=wp_met,scores={wp_t=41..41}] at @s run function wp:boom/7
execute as @e[type=marker,tag=wp_met,scores={wp_t=41..41}] at @s run particle minecraft:explosion_emitter ~ ~ ~ 3 2 3 0 14 force
execute as @e[type=marker,tag=wp_met,scores={wp_t=41..41}] at @s run particle minecraft:lava ~ ~ ~ 3 1 3 0 60 force
execute as @e[type=marker,tag=wp_met,scores={wp_t=41..41}] at @s run playsound minecraft:entity.lightning_bolt.thunder block @a ~ ~ ~ 10 0.6
execute as @e[type=marker,tag=wp_met,scores={wp_t=43..43}] at @s run execute unless dimension br:backrooms run fill ~-4 ~-4 ~-4 ~4 ~-1 ~4 magma_block replace #minecraft:dirt
execute as @e[type=marker,tag=wp_met,scores={wp_t=43..43}] at @s run execute unless dimension br:backrooms run fill ~-4 ~-4 ~-4 ~4 ~-1 ~4 magma_block replace #minecraft:base_stone_overworld
execute as @e[type=marker,tag=wp_met,scores={wp_t=43..43}] at @s run execute unless dimension br:backrooms run fill ~-4 ~-4 ~-4 ~4 ~-1 ~4 magma_block replace #minecraft:sand
execute as @e[type=marker,tag=wp_met,scores={wp_t=43..43}] at @s run execute unless dimension br:backrooms run fill ~-4 ~-4 ~-4 ~4 ~-1 ~4 magma_block replace minecraft:gravel
execute as @e[type=marker,tag=wp_met,scores={wp_t=43..43}] at @s run execute unless dimension br:backrooms run summon small_fireball ~2 ~3 ~0 {Motion:[0.0d,-1.0d,0.0d]}
execute as @e[type=marker,tag=wp_met,scores={wp_t=43..43}] at @s run execute unless dimension br:backrooms run summon small_fireball ~-2 ~3 ~0 {Motion:[0.0d,-1.0d,0.0d]}
execute as @e[type=marker,tag=wp_met,scores={wp_t=43..43}] at @s run execute unless dimension br:backrooms run summon small_fireball ~0 ~3 ~2 {Motion:[0.0d,-1.0d,0.0d]}
execute as @e[type=marker,tag=wp_met,scores={wp_t=43..43}] at @s run execute unless dimension br:backrooms run summon small_fireball ~0 ~3 ~-2 {Motion:[0.0d,-1.0d,0.0d]}
kill @e[type=marker,tag=wp_met,scores={wp_t=50..}]
execute as @e[type=marker,tag=wp_vn,scores={wp_t=1..1}] at @s run execute store result score #anz wp_t if entity @e[distance=..1000,type=!player,tag=!wp_sys,tag=!br_sys]
execute as @e[type=marker,tag=wp_vn,scores={wp_t=1..1}] at @s run execute as @e[distance=..1000,type=!player,tag=!wp_sys,tag=!br_sys] at @s run particle minecraft:cloud ~ ~1 ~ 0.3 0.5 0.3 0.05 6 force
execute as @e[type=marker,tag=wp_vn,scores={wp_t=1..1}] at @s run kill @e[distance=..1000,type=!player,tag=!wp_sys,tag=!br_sys]
execute as @e[type=marker,tag=wp_vn,scores={wp_t=2..2}] at @s run kill @e[distance=..1000,type=item]
execute as @e[type=marker,tag=wp_vn,scores={wp_t=2..2}] at @s run kill @e[distance=..1000,type=experience_orb]
execute as @e[type=marker,tag=wp_vn,scores={wp_t=1..1}] at @s run particle minecraft:explosion_emitter ~ ~ ~ 4 4 4 0 40 force
execute as @e[type=marker,tag=wp_vn,scores={wp_t=1..1}] at @s run particle minecraft:end_rod ~ ~1 ~ 1 1 1 1.5 400 force
execute as @e[type=marker,tag=wp_vn,scores={wp_t=1..1}] at @s run playsound minecraft:entity.wither.death master @a ~ ~ ~ 100 0.5
execute as @e[type=marker,tag=wp_vn,scores={wp_t=1..1}] at @s run title @a[distance=..1000] times 5 60 20
execute as @e[type=marker,tag=wp_vn,scores={wp_t=1..1}] at @s run title @a[distance=..1000] subtitle [{"score":{"name":"#anz","objective":"wp_t"},"color":"red"},{"text":" Ziele im Umkreis von 1000 Blöcken","color":"gray","italic":false}]
execute as @e[type=marker,tag=wp_vn,scores={wp_t=1..1}] at @s run title @a[distance=..1000] title {"text":"AUSGELÖSCHT","color":"dark_red","italic":false,"bold":true}
kill @e[type=marker,tag=wp_vn,scores={wp_t=3..}]
execute as @e[type=marker,tag=wp_wl,scores={wp_t=1..1}] at @s run title @a[distance=..150] times 5 60 20
execute as @e[type=marker,tag=wp_wl,scores={wp_t=1..1}] at @s run title @a[distance=..150] subtitle {"text":"Alles im Umkreis von 48 Blöcken verschwindet","color":"gray","italic":false}
execute as @e[type=marker,tag=wp_wl,scores={wp_t=1..1}] at @s run title @a[distance=..150] title {"text":"WELTLÖSCHER","color":"white","italic":false,"bold":true}
execute as @e[type=marker,tag=wp_wl,scores={wp_t=1..1}] at @s run playsound minecraft:entity.wither.spawn master @a ~ ~ ~ 10 0.5
execute as @e[type=marker,tag=wp_wl,scores={wp_t=2..2}] at @s run function wp:fx/wl_0
execute as @e[type=marker,tag=wp_wl,scores={wp_t=3..3}] at @s run function wp:fx/wl_1
execute as @e[type=marker,tag=wp_wl,scores={wp_t=4..4}] at @s run function wp:fx/wl_2
execute as @e[type=marker,tag=wp_wl,scores={wp_t=5..5}] at @s run function wp:fx/wl_3
execute as @e[type=marker,tag=wp_wl,scores={wp_t=6..6}] at @s run function wp:fx/wl_4
execute as @e[type=marker,tag=wp_wl,scores={wp_t=7..7}] at @s run function wp:fx/wl_5
execute as @e[type=marker,tag=wp_wl,scores={wp_t=8..8}] at @s run function wp:fx/wl_6
execute as @e[type=marker,tag=wp_wl,scores={wp_t=9..9}] at @s run function wp:fx/wl_7
execute as @e[type=marker,tag=wp_wl,scores={wp_t=10..10}] at @s run function wp:fx/wl_8
execute as @e[type=marker,tag=wp_wl,scores={wp_t=11..11}] at @s run function wp:fx/wl_9
execute as @e[type=marker,tag=wp_wl,scores={wp_t=12..12}] at @s run function wp:fx/wl_10
execute as @e[type=marker,tag=wp_wl,scores={wp_t=13..13}] at @s run function wp:fx/wl_11
execute as @e[type=marker,tag=wp_wl,scores={wp_t=14..14}] at @s run function wp:fx/wl_12
execute as @e[type=marker,tag=wp_wl,scores={wp_t=15..15}] at @s run function wp:fx/wl_13
execute as @e[type=marker,tag=wp_wl,scores={wp_t=16..16}] at @s run function wp:fx/wl_14
execute as @e[type=marker,tag=wp_wl,scores={wp_t=17..17}] at @s run function wp:fx/wl_15
execute as @e[type=marker,tag=wp_wl,scores={wp_t=18..18}] at @s run function wp:fx/wl_16
execute as @e[type=marker,tag=wp_wl,scores={wp_t=19..19}] at @s run function wp:fx/wl_17
execute as @e[type=marker,tag=wp_wl,scores={wp_t=20..20}] at @s run function wp:fx/wl_18
execute as @e[type=marker,tag=wp_wl,scores={wp_t=21..21}] at @s run function wp:fx/wl_19
execute as @e[type=marker,tag=wp_wl,scores={wp_t=22..22}] at @s run function wp:fx/wl_20
execute as @e[type=marker,tag=wp_wl,scores={wp_t=23..23}] at @s run function wp:fx/wl_21
execute as @e[type=marker,tag=wp_wl,scores={wp_t=24..24}] at @s run function wp:fx/wl_22
execute as @e[type=marker,tag=wp_wl,scores={wp_t=25..25}] at @s run function wp:fx/wl_23
execute as @e[type=marker,tag=wp_wl,scores={wp_t=26..26}] at @s run function wp:fx/wl_24
execute as @e[type=marker,tag=wp_wl,scores={wp_t=27..27}] at @s run function wp:fx/wl_25
execute as @e[type=marker,tag=wp_wl,scores={wp_t=28..28}] at @s run function wp:fx/wl_26
execute as @e[type=marker,tag=wp_wl,scores={wp_t=29..29}] at @s run function wp:fx/wl_27
execute as @e[type=marker,tag=wp_wl,scores={wp_t=30..30}] at @s run function wp:fx/wl_28
execute as @e[type=marker,tag=wp_wl,scores={wp_t=31..31}] at @s run function wp:fx/wl_29
execute as @e[type=marker,tag=wp_wl,scores={wp_t=32..32}] at @s run function wp:fx/wl_30
execute as @e[type=marker,tag=wp_wl,scores={wp_t=33..33}] at @s run function wp:fx/wl_31
execute as @e[type=marker,tag=wp_wl,scores={wp_t=34..34}] at @s run function wp:fx/wl_32
execute as @e[type=marker,tag=wp_wl,scores={wp_t=35..35}] at @s run function wp:fx/wl_33
execute as @e[type=marker,tag=wp_wl,scores={wp_t=36..36}] at @s run function wp:fx/wl_34
execute as @e[type=marker,tag=wp_wl,scores={wp_t=37..37}] at @s run function wp:fx/wl_35
execute as @e[type=marker,tag=wp_wl,scores={wp_t=38..38}] at @s run function wp:fx/wl_36
execute as @e[type=marker,tag=wp_wl,scores={wp_t=39..39}] at @s run function wp:fx/wl_37
execute as @e[type=marker,tag=wp_wl,scores={wp_t=40..40}] at @s run function wp:fx/wl_38
execute as @e[type=marker,tag=wp_wl,scores={wp_t=41..41}] at @s run function wp:fx/wl_39
execute as @e[type=marker,tag=wp_wl,scores={wp_t=42..42}] at @s run function wp:fx/wl_40
execute as @e[type=marker,tag=wp_wl,scores={wp_t=43..43}] at @s run function wp:fx/wl_41
execute as @e[type=marker,tag=wp_wl,scores={wp_t=44..44}] at @s run function wp:fx/wl_42
execute as @e[type=marker,tag=wp_wl,scores={wp_t=45..45}] at @s run function wp:fx/wl_43
execute as @e[type=marker,tag=wp_wl,scores={wp_t=46..46}] at @s run function wp:fx/wl_44
execute as @e[type=marker,tag=wp_wl,scores={wp_t=47..47}] at @s run function wp:fx/wl_45
execute as @e[type=marker,tag=wp_wl,scores={wp_t=48..48}] at @s run function wp:fx/wl_46
execute as @e[type=marker,tag=wp_wl,scores={wp_t=49..49}] at @s run function wp:fx/wl_47
execute as @e[type=marker,tag=wp_wl,scores={wp_t=50..50}] at @s run function wp:fx/wl_48
execute as @e[type=marker,tag=wp_wl,scores={wp_t=51..51}] at @s run function wp:fx/wl_49
execute as @e[type=marker,tag=wp_wl,scores={wp_t=52..52}] at @s run function wp:fx/wl_50
execute as @e[type=marker,tag=wp_wl,scores={wp_t=53..53}] at @s run function wp:fx/wl_51
execute as @e[type=marker,tag=wp_wl,scores={wp_t=54..54}] at @s run function wp:fx/wl_52
execute as @e[type=marker,tag=wp_wl,scores={wp_t=55..55}] at @s run function wp:fx/wl_53
execute as @e[type=marker,tag=wp_wl,scores={wp_t=56..56}] at @s run function wp:fx/wl_54
execute as @e[type=marker,tag=wp_wl,scores={wp_t=57..57}] at @s run function wp:fx/wl_55
execute as @e[type=marker,tag=wp_wl,scores={wp_t=58..58}] at @s run function wp:fx/wl_56
execute as @e[type=marker,tag=wp_wl,scores={wp_t=59..59}] at @s run function wp:fx/wl_57
execute as @e[type=marker,tag=wp_wl,scores={wp_t=60..60}] at @s run function wp:fx/wl_58
execute as @e[type=marker,tag=wp_wl,scores={wp_t=61..61}] at @s run function wp:fx/wl_59
execute as @e[type=marker,tag=wp_wl,scores={wp_t=62..62}] at @s run function wp:fx/wl_60
execute as @e[type=marker,tag=wp_wl,scores={wp_t=63..63}] at @s run function wp:fx/wl_61
execute as @e[type=marker,tag=wp_wl,scores={wp_t=64..64}] at @s run function wp:fx/wl_62
execute as @e[type=marker,tag=wp_wl,scores={wp_t=65..65}] at @s run function wp:fx/wl_63
execute as @e[type=marker,tag=wp_wl,scores={wp_t=66..66}] at @s run function wp:fx/wl_64
execute as @e[type=marker,tag=wp_wl,scores={wp_t=67..67}] at @s run function wp:fx/wl_65
execute as @e[type=marker,tag=wp_wl,scores={wp_t=68..68}] at @s run function wp:fx/wl_66
execute as @e[type=marker,tag=wp_wl,scores={wp_t=69..69}] at @s run function wp:fx/wl_67
execute as @e[type=marker,tag=wp_wl,scores={wp_t=70..70}] at @s run function wp:fx/wl_68
execute as @e[type=marker,tag=wp_wl,scores={wp_t=71..71}] at @s run function wp:fx/wl_69
execute as @e[type=marker,tag=wp_wl,scores={wp_t=72..72}] at @s run function wp:fx/wl_70
execute as @e[type=marker,tag=wp_wl,scores={wp_t=73..73}] at @s run function wp:fx/wl_71
execute as @e[type=marker,tag=wp_wl,scores={wp_t=74..74}] at @s run function wp:fx/wl_72
execute as @e[type=marker,tag=wp_wl,scores={wp_t=75..75}] at @s run function wp:fx/wl_73
execute as @e[type=marker,tag=wp_wl,scores={wp_t=76..76}] at @s run function wp:fx/wl_74
execute as @e[type=marker,tag=wp_wl,scores={wp_t=77..77}] at @s run function wp:fx/wl_75
execute as @e[type=marker,tag=wp_wl,scores={wp_t=78..78}] at @s run function wp:fx/wl_76
execute as @e[type=marker,tag=wp_wl,scores={wp_t=79..79}] at @s run function wp:fx/wl_77
execute as @e[type=marker,tag=wp_wl,scores={wp_t=80..80}] at @s run function wp:fx/wl_78
execute as @e[type=marker,tag=wp_wl,scores={wp_t=81..81}] at @s run function wp:fx/wl_79
execute as @e[type=marker,tag=wp_wl,scores={wp_t=82..82}] at @s run function wp:fx/wl_80
execute as @e[type=marker,tag=wp_wl,scores={wp_t=83..83}] at @s run function wp:fx/wl_81
execute as @e[type=marker,tag=wp_wl,scores={wp_t=84..84}] at @s run function wp:fx/wl_82
execute as @e[type=marker,tag=wp_wl,scores={wp_t=85..85}] at @s run function wp:fx/wl_83
execute as @e[type=marker,tag=wp_wl,scores={wp_t=86..86}] at @s run function wp:fx/wl_84
execute as @e[type=marker,tag=wp_wl,scores={wp_t=87..87}] at @s run function wp:fx/wl_85
execute as @e[type=marker,tag=wp_wl,scores={wp_t=88..88}] at @s run function wp:fx/wl_86
execute as @e[type=marker,tag=wp_wl,scores={wp_t=89..89}] at @s run function wp:fx/wl_87
execute as @e[type=marker,tag=wp_wl,scores={wp_t=90..90}] at @s run function wp:fx/wl_88
execute as @e[type=marker,tag=wp_wl,scores={wp_t=91..91}] at @s run function wp:fx/wl_89
execute as @e[type=marker,tag=wp_wl,scores={wp_t=92..92}] at @s run function wp:fx/wl_90
execute as @e[type=marker,tag=wp_wl,scores={wp_t=93..93}] at @s run function wp:fx/wl_91
execute as @e[type=marker,tag=wp_wl,scores={wp_t=94..94}] at @s run function wp:fx/wl_92
execute as @e[type=marker,tag=wp_wl,scores={wp_t=95..95}] at @s run function wp:fx/wl_93
execute as @e[type=marker,tag=wp_wl,scores={wp_t=96..96}] at @s run function wp:fx/wl_94
execute as @e[type=marker,tag=wp_wl] at @s run particle minecraft:explosion ~ ~ ~ 20 10 20 0.1 30 force
kill @e[type=marker,tag=wp_wl,scores={wp_t=99..}]
