fill ~-16 316 ~-16 ~15 319 ~15 air
fill ~-16 316 ~16 ~15 319 ~47 air
fill ~16 316 ~-16 ~47 319 ~15 air
fill ~-48 316 ~-16 ~-17 319 ~15 air
fill ~-16 316 ~-48 ~15 319 ~-17 air
fill ~16 316 ~16 ~47 319 ~47 air
fill ~-48 316 ~16 ~-17 319 ~47 air
fill ~16 316 ~-48 ~47 319 ~-17 air
fill ~-48 316 ~-48 ~-17 319 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
