fill ~-16 4 ~-16 ~15 7 ~15 air
fill ~-16 4 ~16 ~15 7 ~47 air
fill ~16 4 ~-16 ~47 7 ~15 air
fill ~-48 4 ~-16 ~-17 7 ~15 air
fill ~-16 4 ~-48 ~15 7 ~-17 air
fill ~16 4 ~16 ~47 7 ~47 air
fill ~-48 4 ~16 ~-17 7 ~47 air
fill ~16 4 ~-48 ~47 7 ~-17 air
fill ~-48 4 ~-48 ~-17 7 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
