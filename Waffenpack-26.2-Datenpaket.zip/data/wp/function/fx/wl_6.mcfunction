fill ~-16 292 ~-16 ~15 295 ~15 air
fill ~-16 292 ~16 ~15 295 ~47 air
fill ~16 292 ~-16 ~47 295 ~15 air
fill ~-48 292 ~-16 ~-17 295 ~15 air
fill ~-16 292 ~-48 ~15 295 ~-17 air
fill ~16 292 ~16 ~47 295 ~47 air
fill ~-48 292 ~16 ~-17 295 ~47 air
fill ~16 292 ~-48 ~47 295 ~-17 air
fill ~-48 292 ~-48 ~-17 295 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
