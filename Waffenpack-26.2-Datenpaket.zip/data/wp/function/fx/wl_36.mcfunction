fill ~-16 172 ~-16 ~15 175 ~15 air
fill ~-16 172 ~16 ~15 175 ~47 air
fill ~16 172 ~-16 ~47 175 ~15 air
fill ~-48 172 ~-16 ~-17 175 ~15 air
fill ~-16 172 ~-48 ~15 175 ~-17 air
fill ~16 172 ~16 ~47 175 ~47 air
fill ~-48 172 ~16 ~-17 175 ~47 air
fill ~16 172 ~-48 ~47 175 ~-17 air
fill ~-48 172 ~-48 ~-17 175 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
