fill ~-16 76 ~-16 ~15 79 ~15 air
fill ~-16 76 ~16 ~15 79 ~47 air
fill ~16 76 ~-16 ~47 79 ~15 air
fill ~-48 76 ~-16 ~-17 79 ~15 air
fill ~-16 76 ~-48 ~15 79 ~-17 air
fill ~16 76 ~16 ~47 79 ~47 air
fill ~-48 76 ~16 ~-17 79 ~47 air
fill ~16 76 ~-48 ~47 79 ~-17 air
fill ~-48 76 ~-48 ~-17 79 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
