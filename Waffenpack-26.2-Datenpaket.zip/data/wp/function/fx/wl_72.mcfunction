fill ~-16 28 ~-16 ~15 31 ~15 air
fill ~-16 28 ~16 ~15 31 ~47 air
fill ~16 28 ~-16 ~47 31 ~15 air
fill ~-48 28 ~-16 ~-17 31 ~15 air
fill ~-16 28 ~-48 ~15 31 ~-17 air
fill ~16 28 ~16 ~47 31 ~47 air
fill ~-48 28 ~16 ~-17 31 ~47 air
fill ~16 28 ~-48 ~47 31 ~-17 air
fill ~-48 28 ~-48 ~-17 31 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
