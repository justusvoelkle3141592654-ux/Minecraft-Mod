fill ~-16 244 ~-16 ~15 247 ~15 air
fill ~-16 244 ~16 ~15 247 ~47 air
fill ~16 244 ~-16 ~47 247 ~15 air
fill ~-48 244 ~-16 ~-17 247 ~15 air
fill ~-16 244 ~-48 ~15 247 ~-17 air
fill ~16 244 ~16 ~47 247 ~47 air
fill ~-48 244 ~16 ~-17 247 ~47 air
fill ~16 244 ~-48 ~47 247 ~-17 air
fill ~-48 244 ~-48 ~-17 247 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
