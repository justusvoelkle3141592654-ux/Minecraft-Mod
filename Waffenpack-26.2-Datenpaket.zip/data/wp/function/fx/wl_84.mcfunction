fill ~-16 -20 ~-16 ~15 -17 ~15 air
fill ~-16 -20 ~16 ~15 -17 ~47 air
fill ~16 -20 ~-16 ~47 -17 ~15 air
fill ~-48 -20 ~-16 ~-17 -17 ~15 air
fill ~-16 -20 ~-48 ~15 -17 ~-17 air
fill ~16 -20 ~16 ~47 -17 ~47 air
fill ~-48 -20 ~16 ~-17 -17 ~47 air
fill ~16 -20 ~-48 ~47 -17 ~-17 air
fill ~-48 -20 ~-48 ~-17 -17 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
