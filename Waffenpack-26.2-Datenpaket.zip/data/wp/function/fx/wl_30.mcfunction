fill ~-16 196 ~-16 ~15 199 ~15 air
fill ~-16 196 ~16 ~15 199 ~47 air
fill ~16 196 ~-16 ~47 199 ~15 air
fill ~-48 196 ~-16 ~-17 199 ~15 air
fill ~-16 196 ~-48 ~15 199 ~-17 air
fill ~16 196 ~16 ~47 199 ~47 air
fill ~-48 196 ~16 ~-17 199 ~47 air
fill ~16 196 ~-48 ~47 199 ~-17 air
fill ~-48 196 ~-48 ~-17 199 ~-17 air
playsound minecraft:entity.generic.explode block @a ~ ~ ~ 4 0.5
