scoreboard players add @e[tag=wp_proj] wp_alter 1
execute as @e[type=item_display,tag=wp_dreh] store result entity @s Rotation[0] float -0.01 on vehicle run data get entity @s Rotation[0] 100
execute as @e[type=item_display,tag=wp_dreh] store result entity @s Rotation[1] float -0.01 on vehicle run data get entity @s Rotation[1] 100
execute as @e[type=arrow,tag=wp_proj] if data entity @s {inGround:1b} at @s run function wp:einschlag/pfeil
execute as @e[type=item_display,tag=wp_sensor] at @s unless predicate wp:hat_fahrzeug run function wp:einschlag/sensor
execute as @e[type=arrow,tag=wp_pp] at @s run particle minecraft:crit ~ ~ ~ 0 0 0 0 1 force
execute as @e[type=arrow,tag=wp_pb,scores={wp_alter=3..}] at @s run particle minecraft:flame ~ ~ ~ 0.1 0.1 0.1 0.01 4 force
execute as @e[type=arrow,tag=wp_pb,scores={wp_alter=3..}] at @s run particle minecraft:smoke ~ ~ ~ 0.15 0.15 0.15 0.01 3 force
execute as @e[type=arrow,tag=wp_ps,scores={wp_alter=2..}] at @s run particle minecraft:dragon_breath ~ ~ ~ 0.05 0.05 0.05 0.01 3 force
execute as @e[type=arrow,tag=wp_ps,scores={wp_alter=2..}] at @s run particle minecraft:portal ~ ~ ~ 0.2 0.2 0.2 0.6 4 force
execute as @e[type=arrow,tag=wp_pv,scores={wp_alter=2..}] at @s run particle minecraft:end_rod ~ ~ ~ 0.05 0.05 0.05 0.01 2 force
execute as @e[type=arrow,tag=wp_pv,scores={wp_alter=2..}] at @s run particle minecraft:dust{color:[1.0,0.1,0.1],scale:1.5} ~ ~ ~ 0.1 0.1 0.1 0 3 force
execute as @e[type=snowball,tag=wp_proj,scores={wp_alter=2..}] at @s run particle minecraft:flame ~ ~ ~ 0 0 0 0 1 force
execute as @e[type=snowball,tag=wp_proj,scores={wp_alter=2..}] at @s run particle minecraft:smoke ~ ~ ~ 0 0 0 0 1 force
execute as @e[tag=wp_proj,scores={wp_alter=200..}] run function wp:einschlag/weg
