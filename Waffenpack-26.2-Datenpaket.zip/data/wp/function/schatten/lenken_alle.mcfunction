execute as @e[type=arrow,tag=wp_ps] at @s if entity @e[type=#wp:feinde,distance=..12,tag=!wp_sys] unless data entity @s {inGround:1b} run function wp:schatten/lenken
