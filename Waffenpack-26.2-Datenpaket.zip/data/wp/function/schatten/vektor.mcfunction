data modify storage wp:tmp v set from entity @s Pos
kill @s
