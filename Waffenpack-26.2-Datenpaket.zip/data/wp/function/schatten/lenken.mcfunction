execute facing entity @e[type=#wp:feinde,distance=..12,tag=!wp_sys,sort=nearest,limit=1] eyes positioned 0.0 0.0 0.0 positioned ^ ^ ^2.2 summon marker run function wp:schatten/vektor
data modify entity @s Motion set from storage wp:tmp v
