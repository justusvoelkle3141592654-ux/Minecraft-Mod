playsound minecraft:entity.firework_rocket.blast player @a ~ ~ ~ 0.9 1.9
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 0.15 2
particle minecraft:flame ^-0.45 ^-0.3 ^1.6 0.02 0.02 0.02 0.01 2
particle minecraft:smoke ^-0.45 ^-0.3 ^1.8 0.03 0.03 0.03 0.01 2
scoreboard players set #schritt wp_t 0
function wp:mg/strahl
