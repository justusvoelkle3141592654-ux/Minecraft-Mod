particle minecraft:smoke ^ ^ ^-0.3 0.05 0.05 0.05 0.02 4 force
particle minecraft:crit ^ ^ ^-0.3 0.05 0.05 0.05 0.2 4 force
playsound minecraft:block.stone.hit block @a ~ ~ ~ 0.4 1.5
