scoreboard players add #schritt wp_t 1
execute if score #schritt wp_t matches 5.. run particle minecraft:dust{color:[1.0,0.85,0.35],scale:0.6} ~ ~ ~ 0 0 0 0 1 force
execute positioned ~-0.5 ~-0.5 ~-0.5 if entity @e[dx=0,dy=0,dz=0,type=!#wp:kein_ziel,tag=!wp_sys] positioned ~0.5 ~0.5 ~0.5 run return run function wp:mg/treffer
execute unless block ~ ~ ~ #wp:durchlaessig run return run function wp:mg/block
execute if score #schritt wp_t matches ..120 positioned ^ ^ ^0.5 run function wp:mg/strahl
