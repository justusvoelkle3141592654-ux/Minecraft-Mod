advancement revoke @s only wp:minigun
scoreboard players add @s wp_mg 1
execute if score @s wp_mg matches 2.. at @s anchored eyes positioned ^ ^ ^ run function wp:mg/schuss
execute if score @s wp_mg matches 2.. run scoreboard players set @s wp_mg 0
