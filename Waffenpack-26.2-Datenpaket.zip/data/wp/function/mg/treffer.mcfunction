execute positioned ~-0.5 ~-0.5 ~-0.5 run damage @e[dx=0,dy=0,dz=0,type=!#wp:kein_ziel,tag=!wp_sys,limit=1] 10 minecraft:arrow by @s
particle minecraft:crit ~ ~ ~ 0.2 0.2 0.2 0.3 8 force
particle minecraft:damage_indicator ~ ~ ~ 0.1 0.1 0.1 0.1 2 force
playsound minecraft:entity.arrow.hit_player player @a ~ ~ ~ 0.4 1.6
