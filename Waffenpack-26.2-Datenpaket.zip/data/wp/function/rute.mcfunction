execute if entity @s[tag=wp_h4] anchored eyes positioned ^ ^ ^ run function wp:orbital/schuss
