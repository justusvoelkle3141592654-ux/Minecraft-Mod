function wp:items/alle
tag @s add wp_hat
tellraw @s [{"text":"Willkommen! ","color":"gold","italic":false,"bold":true},{"text":"Alle Waffen liegen im Inventar. ","color":"white","italic":false},{"text":"Backrooms: ","color":"white","italic":false},{"text":"[KLICK HIER]","color":"yellow","bold":true,"click_event":{"action":"run_command","command":"/trigger start"},"hover_event":{"action":"show_text","value":"Backrooms betreten"}},{"text":" oder tippe ","color":"white","italic":false},{"text":"/trigger start","color":"yellow","italic":false}]
