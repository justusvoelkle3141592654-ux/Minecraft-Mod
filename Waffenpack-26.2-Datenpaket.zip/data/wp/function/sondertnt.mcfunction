execute as @e[type=tnt,tag=!wp_tx] at @s run particle minecraft:firework ~ ~1 ~ 0.05 0.05 0.05 0.03 1
execute as @e[type=tnt,tag=!wp_tx] if data entity @s {fuse:1s} at @s run summon tnt ~3 ~ ~0 {fuse:1,Tags:["wp_tx"]}
execute as @e[type=tnt,tag=!wp_tx] if data entity @s {fuse:1s} at @s run summon tnt ~-3 ~ ~0 {fuse:1,Tags:["wp_tx"]}
execute as @e[type=tnt,tag=!wp_tx] if data entity @s {fuse:1s} at @s run summon tnt ~0 ~ ~3 {fuse:1,Tags:["wp_tx"]}
execute as @e[type=tnt,tag=!wp_tx] if data entity @s {fuse:1s} at @s run summon tnt ~0 ~ ~-3 {fuse:1,Tags:["wp_tx"]}
execute as @e[type=tnt,tag=!wp_tx] if data entity @s {fuse:1s} at @s run playsound minecraft:entity.lightning_bolt.thunder block @a ~ ~ ~ 3 0.8
