execute as @e[type=arrow,tag=!wp_alt] at @s on origin if items entity @s weapon.mainhand *[custom_data~{wp:1}] as @e[type=arrow,tag=!wp_alt,limit=1,sort=nearest] run function wp:pfeil/neu_p
execute as @e[type=arrow,tag=!wp_alt] at @s on origin if items entity @s weapon.mainhand *[custom_data~{wp:2}] as @e[type=arrow,tag=!wp_alt,limit=1,sort=nearest] run function wp:pfeil/neu_b
execute as @e[type=arrow,tag=!wp_alt] at @s on origin if items entity @s weapon.mainhand *[custom_data~{wp:5}] as @e[type=arrow,tag=!wp_alt,limit=1,sort=nearest] run function wp:pfeil/neu_s
execute as @e[type=arrow,tag=!wp_alt] at @s on origin if items entity @s weapon.mainhand *[custom_data~{wp:6}] as @e[type=arrow,tag=!wp_alt,limit=1,sort=nearest] run function wp:pfeil/neu_v
execute as @e[type=arrow,tag=!wp_alt] at @s on origin if items entity @s weapon.mainhand *[custom_data~{wp:3}] run kill @e[type=arrow,tag=!wp_alt,limit=1,sort=nearest]
tag @e[type=arrow,tag=!wp_alt] add wp_alt
