tag @s add wp_proj
tag @s add wp_ps
data merge entity @s {damage:60.0d,pickup:0b}
summon item_display ~ ~ ~ {teleport_duration:1,Tags:["wp_sys","wp_sensor","wp_dreh","wp_neu","wp_ss"]}
ride @e[type=item_display,tag=wp_neu,limit=1,sort=nearest] mount @s
tag @e[type=item_display,tag=wp_neu] remove wp_neu
playsound minecraft:entity.wither.shoot player @a ~ ~ ~ 0.6 1.6
execute on origin at @s anchored eyes positioned ^ ^ ^2.5 run particle minecraft:reverse_portal ~ ~ ~ 0.2 0.2 0.2 0.05 20
