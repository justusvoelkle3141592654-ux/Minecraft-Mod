tag @s add wp_proj
tag @s add wp_pp
data merge entity @s {damage:2048.0d,pickup:0b}
summon item_display ~ ~ ~ {item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:kugel"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.70f,0.70f,0.70f]},teleport_duration:1,Tags:["wp_sys","wp_sensor","wp_dreh","wp_neu","wp_sp"]}
ride @e[type=item_display,tag=wp_neu,limit=1,sort=nearest] mount @s
tag @e[type=item_display,tag=wp_neu] remove wp_neu
playsound minecraft:entity.generic.explode player @a ~ ~ ~ 0.6 2
playsound minecraft:block.anvil.land player @a ~ ~ ~ 0.25 2
execute on origin at @s anchored eyes positioned ^-0.4 ^-0.25 ^2.2 run particle minecraft:flame ~ ~ ~ 0.03 0.03 0.03 0.02 4
execute on origin at @s anchored eyes positioned ^-0.4 ^-0.25 ^2.4 run particle minecraft:smoke ~ ~ ~ 0.03 0.03 0.03 0.01 3
