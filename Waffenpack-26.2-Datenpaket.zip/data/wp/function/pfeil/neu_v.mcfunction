tag @s add wp_proj
tag @s add wp_pv
data merge entity @s {pickup:0b}
summon item_display ~ ~ ~ {teleport_duration:1,Tags:["wp_sys","wp_sensor","wp_dreh","wp_neu","wp_sv"]}
ride @e[type=item_display,tag=wp_neu,limit=1,sort=nearest] mount @s
tag @e[type=item_display,tag=wp_neu] remove wp_neu
playsound minecraft:entity.ender_dragon.shoot player @a ~ ~ ~ 1 0.6
