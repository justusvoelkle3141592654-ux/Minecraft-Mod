tag @s add wp_proj
tag @s add wp_pb
data merge entity @s {damage:2048.0d,pickup:0b}
summon item_display ~ ~ ~ {item:{id:"minecraft:stick",count:1,components:{"minecraft:item_model":"waffenpack:rakete"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.00f,1.00f,1.00f]},teleport_duration:1,Tags:["wp_sys","wp_sensor","wp_dreh","wp_neu","wp_sb"]}
ride @e[type=item_display,tag=wp_neu,limit=1,sort=nearest] mount @s
tag @e[type=item_display,tag=wp_neu] remove wp_neu
playsound minecraft:entity.firework_rocket.launch player @a ~ ~ ~ 2 0.5
playsound minecraft:entity.blaze.shoot player @a ~ ~ ~ 1 0.6
execute on origin at @s anchored eyes positioned ^ ^ ^-1.5 run particle minecraft:large_smoke ~ ~ ~ 0.2 0.2 0.2 0.02 8
